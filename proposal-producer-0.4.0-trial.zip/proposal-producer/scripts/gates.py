"""Deterministic release boundary; evidence assertions remain reviewer's responsibility."""
from pathlib import Path
import contracts

def technical_conclusion(work,project,state,candidate_digest,filehash,mechanical_issues):
    if mechanical_issues:return 'blocked'
    if not (work/'checks.json').is_file():return 'pending'
    ids=set(contracts.load(contracts.ROOT/'contracts/presentation-quality.json')['technical_check_ids'])
    known=set(contracts.checklist()['checks'])
    issues=evidence_issues(work,project,state,candidate_digest,filehash)
    relevant=[v for v in issues if v.split(':',1)[0] in ids or v.split(':',1)[0] not in known]
    return 'blocked' if relevant else 'passed'

def evidence_issues(work, project, state, candidate_digest, filehash):
    path=work/'checks.json'; issues=[]
    if not path.is_file(): return ['缺 checks.json 的逐项检查证据']
    data=contracts.validate(contracts.load(path),'check-records.schema.json')
    if data['candidate_digest']!=candidate_digest: issues.append('检查清单候选指纹已失效')
    items=data['items']; ids=[v['id'] for v in items]
    if len(ids)!=len(set(ids)): issues.append('检查 ID 重复')
    records={v['id']:v for v in items}; rules=contracts.policy()
    for ident in contracts.applicable(project):
        record=records.get(ident)
        if not record: issues.append(ident+': 未登记检查'); continue
        status=record['status']
        if status in ['fail','pending']: issues.append(ident+': '+status); continue
        if record['reviewer']==state['producer']: issues.append(ident+': 需独立检查者')
        if status=='not_applicable':
            if not record['reason'] or ident in rules['workflow']['nonwaivable_checks']: issues.append(ident+': 不适用理由不足或不可豁免')
            if ident=='S13' and not project['draft_mode']: issues.append('S13: 对客 SOW 需要适用的标准法务条款')
        if not record['evidence']: issues.append(ident+': 缺证据文件')
        for entry in record['evidence']:
            file=Path(entry['path'])
            if not file.is_absolute(): file=work/file
            if not file.is_file() or filehash(file)!=entry['sha256']: issues.append(ident+': 证据不存在或哈希变化')
        if status=='pass':
            for metric,spec in rules.get('measurement_checks',{}).get(ident,{}).items():
                value=record.get('measurements',{}).get(metric)
                if value is None:
                    if not record.get('measurement_exemptions',{}).get(metric): issues.append(ident+': 缺测量 '+metric)
                    continue
                limit=project.get('threshold_overrides',{}).get(metric,rules['visual'][metric])
                if (spec=='min' and value<limit) or (spec=='max' and value>limit): issues.append(ident+': '+metric+' 超过阈值')
    return issues

def receipt_issues(work, project, state, candidate_digest, filehash):
    path=work/'release.json'
    if not path.is_file(): return ['缺本地放行记录']
    data=contracts.validate(contracts.load(path),'release.schema.json')
    issues=[]
    if data['candidate_digest']!=candidate_digest: issues.append('放行后候选变化')
    if data['policy_digest']!=contracts.fingerprint(): issues.append('放行规则变化')
    checks=work/'checks.json'
    if not checks.is_file() or data['checks_sha256']!=filehash(checks): issues.append('放行后检查记录变化')
    quality=work/'quality-review.json'
    if not quality.is_file() or data['quality_review_sha256']!=filehash(quality):issues.append('放行后质量评审变化')
    if set(data['files'])!=set(project['outputs']): issues.append('放行文件角色与交付选择不符')
    for role,record in data['files'].items():
        file=Path(record['path'])
        if not file.is_file() or filehash(file)!=record['sha256']: issues.append(role+': 已放行文件不存在或变化')
        if record['sha256']!=state.get('files',{}).get(role,{}).get('sha256'): issues.append(role+': 放行文件与已登记候选不符')
    return issues
