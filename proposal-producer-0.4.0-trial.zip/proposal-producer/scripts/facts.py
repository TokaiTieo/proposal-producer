"""Shared deterministic facts and checks against extracted, actual artifact content.

These checks establish literal consistency and references, never business truth,
approval, or presentation quality. Producers can use expected()/fact_texts() to
write the same source values into each selected artifact.
"""
from datetime import date
from decimal import Decimal
import re
import contracts


def rules():
    return contracts.fact_policy()


def enabled(project):
    return (project.get('schema') == 4
            or any(project.get(key) for key in rules()['source_fact_fields'])
            or (project.get('pricing') or {}).get('mode') == 'fixed_inclusive_total')


def project_issues(project):
    """Check shared sources and ID references before comparing the artifacts."""
    if not enabled(project):
        return []
    issues = []
    shared = project.get('shared_facts') or {}
    for key in ['date', 'version']:
        if not shared.get(key):
            issues.append('shared_facts.' + key + ': 共用事实待补')
    if shared.get('date'):
        try:
            date.fromisoformat(shared['date'])
        except (ValueError, TypeError):
            issues.append('shared_facts.date: 无效的 ISO 日期')
    q = project.get('pricing') or {}
    if q.get('mode') == 'fixed_inclusive_total':
        for key in rules()['fixed_total_requirements']:
            if not project.get(key):
                issues.append(key + ': 固定总包价的共用数据待补')
        if q.get('period_months') != shared.get('period_months'):
            issues.append('pricing.period_months 与 shared_facts.period_months 不一致')

    def index(items, key, label):
        result = {}
        for item in items:
            ident = item.get(key)
            if not ident or ident in result:
                issues.append(label + ': ID 缺失或重复 ' + str(ident))
            result[ident] = item
        return result

    requirements = index(project.get('requirements', []), 'id', 'requirements')
    packages = index(project.get('work_packages', []), 'id', 'work_packages')
    sections = index(project.get('sow_sections', []), 'anchor', 'sow_sections')
    for ident, package in packages.items():
        if package.get('sow_anchor') not in sections:
            issues.append('work_packages.' + str(ident) + ': 引用不存在的 SOW 章节 ' + str(package.get('sow_anchor')))
    for ident, requirement in requirements.items():
        if requirement.get('priority') not in rules()['requirement_priorities']:
            issues.append('requirements.' + str(ident) + ': 未知优先级')
        ids = requirement.get('work_package_ids', [])
        if not ids or len(ids) != len(set(ids)):
            issues.append('requirements.' + str(ident) + ': 工作包映射为空或重复')
        for package_id in ids:
            if package_id not in packages:
                issues.append('requirements.' + str(ident) + ': 引用不存在的工作包 ' + str(package_id))
    deliveries=index(project.get('deliverable_details',[]),'id','deliverable_details')
    milestones=index(project.get('milestones',[]),'id','milestones')
    for ident,item in deliveries.items():
        if item['work_package_id'] not in packages:issues.append('deliverable_details.'+ident+': 工作包不存在')
    for ident,item in milestones.items():
        for ref in item['dependency_ids']:
            if ref not in milestones:issues.append('milestones.'+ident+': 前置里程碑不存在 '+ref)
        for ref in item['deliverable_ids']:
            if ref not in deliveries:issues.append('milestones.'+ident+': 交付物不存在 '+ref)
    return issues


def expected(project, calculation=None):
    """Return literal fact lines, requirement rows and stable section headings.

The amount is taken from the deterministic calculation, or directly from a
declared fixed total. Nothing is inferred from prose, tax rates or years.
"""
    if not enabled(project):
        return {'facts': [], 'mappings': [], 'sections': [],'milestones':[]}
    policy = rules()
    shared = project.get('shared_facts') or {}
    result = {'facts': [], 'mappings': [], 'sections': [],'milestones':[]}
    for key in ['date', 'version', 'period_months']:
        if shared.get(key) is not None:
            result['facts'].append({'id': key, 'text': policy['fact_formats'][key].format(**shared)})
    pricing = project.get('pricing') or {}
    calculated = (calculation or {}).get('pricing') or {}
    total = calculated.get('total')
    if total is None and pricing.get('mode') == 'fixed_inclusive_total':
        total = pricing.get('inclusive_total')
    if total is not None and pricing.get('currency'):
        amount = Decimal(str(total))
        grouped = format(amount, ',.2f').removesuffix('.00')
        result['facts'].append({'id': 'inclusive_total', 'text': policy['fact_formats']['inclusive_total'].format(currency=pricing['currency'], total_grouped=grouped)})
    packages = {item['id']: item for item in project.get('work_packages', [])}
    for requirement in project.get('requirements', []):
        for package_id in requirement.get('work_package_ids', []):
            package = packages.get(package_id)
            if package is None:
                continue  # project_issues reports the invalid reference.
            data = {'requirement_id': requirement['id'], 'priority': requirement['priority'], 'work_package_id': package_id, 'sow_anchor': package['sow_anchor']}
            result['mappings'].append({**data, 'text': policy['mapping_format'].format(**data)})
    for section in project.get('sow_sections', []):
        result['sections'].append({**section, 'text': policy['section_format'].format(**section)})
    for milestone in project.get('milestones',[]):
        fields={**milestone,'deliverable_ids':','.join(milestone['deliverable_ids'])}
        result['milestones'].append({**milestone,'text':policy['milestone_format'].format(**fields)})
    return result


def fact_texts(project, calculation=None):
    return [item['text'] for item in expected(project, calculation)['facts']]


def normalize(value):
    return re.sub(r'\s+', '', str(value)).replace(',', '').replace('，', '')


def _lines(info):
    blocks = info.get('blocks') or [info.get('text', '')]
    return [line.strip() for block in blocks for line in str(block).splitlines() if line.strip()]


def check(project, artifacts, calculation=None):
    """Compare shared facts with real extracted files from proposal.inspect().

    Mapping rows must be contiguous, in a paragraph or an actual table row;
    merely scattering IDs around a document does not satisfy the comparison.
    DOCX stable section anchors must also be present in actual heading styles.
    """
    if not enabled(project):
        return {'status': 'not_applicable', 'issues': [], 'fact_comparisons': 0, 'mapping_comparisons': 0, 'section_comparisons': 0}
    issues = project_issues(project)
    values = expected(project, calculation)
    counts = {'fact_comparisons': 0, 'mapping_comparisons': 0, 'section_comparisons': 0}
    for role in project['outputs']:
        if role not in artifacts:
            issues.append(role + ': 共用事实核对缺实际成品')
            continue
        info = artifacts[role]
        lines = _lines(info)
        normalized = [normalize(line) for line in lines]
        # PDF extraction can wrap a line. Match each expected value in the
        # extracted text too, while retaining line checks for contradictions.
        text = normalize(info.get('text', ''))
        for fact in values['facts']:
            counts['fact_comparisons'] += 1
            wanted = normalize(fact['text'])
            if not any(wanted in line for line in normalized) and wanted not in text:
                issues.append(role + ': 共用事实不一致或缺失 ' + fact['id'] + ' = ' + fact['text'])
            prefix = normalize(rules()['fact_prefixes'][fact['id']])
            for raw, line in zip(lines, normalized):
                if line.startswith(prefix) and not line.startswith(wanted):
                    issues.append(role + ': 共用事实存在冲突 ' + fact['id'] + ' = ' + raw)
        mapping_roles=project.get('mapping_required_roles',rules().get('mapping_required_roles',project['outputs']))
        for mapping in values['mappings'] if role in mapping_roles else []:
            counts['mapping_comparisons'] += 1
            wanted=normalize(mapping['text'])
            if not any(v==wanted or v.startswith(wanted+'|') for v in normalized):
                issues.append(role + ': 需求到工作包／章节映射不一致或缺失 ' + mapping['text'])
        wanted_rows = {normalize(item['text']) for item in values['mappings']}
        requirement_ids = {item['id'] for item in project.get('requirements', [])}
        for raw, line in zip(lines, normalized):
            if '|' in raw and raw.split('|', 1)[0].strip() in requirement_ids and not any(line==w or line.startswith(w+'|') for w in wanted_rows):
                issues.append(role + ': 需求映射存在冲突 ' + raw)
        if role in rules()['sow_roles']:
            heading_lines = [normalize(item) for item in info.get('headings', [])] if role == 'sow_docx' else normalized
            for section in values['sections']:
                counts['section_comparisons'] += 1
                if normalize(section['text']) not in heading_lines:
                    issues.append(role + ': SOW 稳定章节锚点不一致或缺失 ' + section['text'])
            for item in values['milestones']:
                if normalize(item['text']) not in normalized:issues.append(role+': 里程碑与共同字段不一致 '+item['id'])
    return {'status': 'blocked' if issues else 'passed', 'issues': issues, **counts, 'expected': values,
            'scope': 'literal artifact consistency and references only; no business truth, approval or visual-quality conclusion'}
