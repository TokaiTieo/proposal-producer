"""Synthetic regressions for authoring and judgment records; no real artifact-pair evaluation."""
import copy
import json
from pathlib import Path
import unittest
import test_contracts as common
import contracts
import presentation
import proposal as api

class PresentationBehavior(unittest.TestCase):
    setUp=common.ReleaseBoundary.setUp
    tearDown=common.ReleaseBoundary.tearDown
    cli=common.ReleaseBoundary.cli
    hook=common.ReleaseBoundary.hook
    def edit_plan(self,change):
        plan=api.load(self.work/'presentation-plan.json');change(plan);api.save(self.work/'presentation-plan.json',plan)
        calibration=api.load(self.work/'calibration.json');calibration['plan_sha256']=api.filehash(self.work/'presentation-plan.json');api.save(self.work/'calibration.json',calibration)
    def edit_quality(self,change):
        value=api.load(self.work/'quality-review.json');change(value);api.save(self.work/'quality-review.json',value)
    def criterion_gap(self,ident):
        def change(value):
            item=next(v for v in value['criteria'] if v['criterion_id']==ident)
            item.update(result='gap',reason='Synthetic reviewer found the declared shortcoming',defects=['Synthetic negative example'])
        self.edit_quality(change)
    def test_each_page_requires_decision_question(self):
        value=api.load(self.work/'presentation-plan.json');del value['pages'][0]['decision_question']
        with self.assertRaises(ValueError):contracts.validate(value,'presentation-plan.schema.json')
    def test_reference_analysis_is_a_production_input(self):
        self.edit_plan(lambda p:p['reference_strategy'].update(status='pending'))
        output=self.cli('production-check',code=2)
        self.assertTrue(any('参考页分析' in s for s in output['issues']))
    def test_actual_reference_change_invalidates_inputs(self):
        (self.work/'SYNTHETIC-reference.txt').write_text('Changed synthetic reference')
        self.assertFalse(self.cli('status')['production_current'])
        self.cli('production-check',code=2)
    def test_unavailable_reference_does_not_hide_selected_reference(self):
        self.edit_plan(lambda p:p['reference_strategy'].update(status='unavailable',reason='Fixture reason'))
        self.assertTrue(any('已有选用参考' in s for s in self.cli('production-check',code=2)['issues']))
    def test_source_case_needs_source_evidence(self):
        self.edit_plan(lambda p:p['scenarios'][0].update(status='source_case'))
        self.assertTrue(any('来源案例' in s for s in self.cli('production-check',code=2)['issues']))
    def test_scenario_needs_an_actual_action_chain(self):
        self.edit_plan(lambda p:p['scenarios'][0].update(ai_actions=[],human_actions=[]))
        self.assertTrue(any('场景链条' in s for s in self.cli('production-check',code=2)['issues']))
    def test_mechanism_list_without_relations_is_incomplete(self):
        self.edit_plan(lambda p:p['pages'][0].update(relations=[]))
        self.assertTrue(any('缺作用关系' in s for s in self.cli('production-check',code=2)['issues']))
    def test_mechanism_uses_known_business_object(self):
        self.edit_plan(lambda p:p['mechanisms'][0]['relations'][0].update(business_object_id='UNRELATED-OBJECT'))
        self.assertTrue(any('UNRELATED-OBJECT' in s for s in self.cli('production-check',code=2)['issues']))
    def test_page_relation_points_to_actual_content(self):
        self.edit_plan(lambda p:p['pages'][0]['relations'][0].update(semantic_ref='INVENTED'))
        self.assertTrue(any('未关联底稿内容' in s for s in self.cli('production-check',code=2)['issues']))
    def test_offer_needs_deliverable_consideration(self):
        self.edit_plan(lambda p:p['applicability']['commercial'].update(applicable=True,reason=None))
        self.assertTrue(any('工作包' in s for s in self.cli('production-check',code=2)['issues']))
    def test_fee_mapping_cannot_point_to_unrelated_package(self):
        project=api.load(self.work/'project.json');project['business']['offer']={'amount':'10000','currency':'CNY'};api.save(self.work/'project.json',project)
        def change(p):
            p['work_packages'].append({'work_package_id':'W2','description':'Unrelated work'})
            p['fee_value_mappings']=[{'fee_id':'Q1','project_pointer':'/business/offer/amount','work_package_ids':['W2'],'deliverable_ids':['D1'],'coverage_period':'本次试点','included_scope':['约定工作'],'separate_budget_items':[],'value_ids':['VA1']}]
        self.edit_plan(change)
        self.assertTrue(any('对价断开' in s for s in self.cli('production-check',code=2)['issues']))
    def test_registration_requires_internal_calibration(self):
        state=api.load(self.work/'state.json');del state['production'];api.save(self.work/'state.json',state)
        self.cli('register','--role','pptx','--file',str(self.ppt),code=2)
    def test_unresolved_calibration_blocks_full_production(self):
        value=api.load(self.work/'calibration.json');value['pages'][0]['result']='gap';api.save(self.work/'calibration.json',value)
        self.cli('production-check',code=2)
        self.cli('register','--role','pptx','--file',str(self.ppt),code=2)
    def test_missing_key_page_calibration_is_detected(self):
        def change(p):
            page=copy.deepcopy(p['pages'][0]);page['page_id']='P2';p['pages'].append(page)
        self.edit_plan(change)
        self.assertTrue(any('P2' in s for s in self.cli('production-check',code=2)['issues']))
    def test_internal_visual_refinement_keeps_content_approval(self):
        value=api.load(self.work/'calibration.json');value['pages'][0]['reason']='Synthetic visual refinement';api.save(self.work/'calibration.json',value)
        self.cli('production-check')
        status=self.cli('status');self.assertTrue(status['confirmed_current']);self.assertFalse(status['review_current'])
        history=api.load(self.work/'state.json')['history'];self.assertEqual(sum(v['command']=='approve' for v in history),1)
    def test_technical_pass_does_not_cover_value_argument_gap(self):
        self.criterion_gap('PQ03')
        report=self.cli('check');self.assertEqual(report['mechanical_checks'],'passed');self.assertEqual(report['quality_conclusions']['technical'],'passed');self.assertEqual(report['quality_conclusions']['business_argument'],'gap')
        self.cli('release',code=2)
    def test_technical_pass_does_not_cover_presentation_gap(self):
        self.criterion_gap('PQ05')
        report=self.cli('check');self.assertEqual(report['quality_conclusions']['technical'],'passed');self.assertEqual(report['quality_conclusions']['presentation_quality'],'gap')
        self.cli('release',code=2)
    def test_flattened_render_does_not_match_planned_relations(self):
        self.edit_quality(lambda q:q['page_reviews'][0].update(observed_relation_ids=[]))
        report=self.cli('check');self.assertEqual(report['quality_conclusions']['presentation_quality'],'gap')
        self.cli('release',code=2)
    def test_page_must_answer_its_decision_question(self):
        self.edit_quality(lambda q:q['page_reviews'][0].update(decision_question_answered=False))
        self.assertEqual(self.cli('check')['quality_conclusions']['presentation_quality'],'gap')
        self.cli('release',code=2)
    def test_local_draft_flag_does_not_reduce_quality_target(self):
        self.assertTrue(api.load(self.work/'project.json')['draft_mode'])
        self.criterion_gap('PQ05');report=self.cli('release',code=2)
        self.assertEqual(report['quality']['quality_target'],'client_presentation')
    def test_missing_final_page_review_is_not_evaluated(self):
        self.edit_quality(lambda q:q.update(page_reviews=[]))
        self.assertEqual(self.cli('check')['quality_conclusions']['presentation_quality'],'not_evaluated')
        self.cli('release',code=2)
    def test_quality_report_binds_actual_candidate(self):
        self.edit_quality(lambda q:q.update(candidate_digest='0'*64))
        self.assertEqual(self.cli('check')['quality_conclusions']['business_argument'],'not_evaluated')
        self.cli('release',code=2)
    def test_quality_report_change_invalidates_release_hook(self):
        self.cli('release');self.edit_quality(lambda q:q['criteria'][0].update(reason='Changed synthetic review'))
        self.assertEqual(json.loads(self.hook().stdout)['decision'],'block')
    def test_quality_criterion_cannot_be_waived_by_reviewer(self):
        self.edit_quality(lambda q:next(v for v in q['criteria'] if v['criterion_id']=='PQ03').update(applicable=False,result='not_applicable'))
        self.cli('release',code=2)
    def test_quality_reviewer_is_the_independent_checker(self):
        self.edit_quality(lambda q:q.update(reviewer='FIXTURE-PRODUCER'))
        self.cli('release',code=2)
    def test_explicit_review_draft_keeps_actual_quality_gap(self):
        p=api.load(self.work/'project.json');p['quality_target']='review_draft';api.save(self.work/'project.json',p)
        self.cli('packet');self.cli('approve','--actor','FIXTURE-USER','--evidence','SYNTHETIC DRAFT SELECTION')
        self.cli('review','--reviewer','FIXTURE-REVIEWER','--report',str(self.work/'review.txt'),'--result','pass')
        checks=api.load(self.work/'checks.json');p,s=api.context(self.work);checks['candidate_digest']=api.candidate(self.work,p,s);api.save(self.work/'checks.json',checks)
        from presentation_fixtures import fill_quality
        fill_quality(self.work,api,'FIXTURE-REVIEWER');self.criterion_gap('PQ05')
        receipt=self.cli('release');self.assertEqual(receipt['quality_target'],'review_draft');self.assertEqual(receipt['quality_conclusions']['presentation_quality'],'gap')
    def test_actual_paired_artifact_evaluation_remains_empty(self):
        value=contracts.load(contracts.ROOT/'evals/presentation-cases.json')
        self.assertIsNone(value['paired_artifact_evaluation']);self.assertEqual(value['actual_runs'],[]);self.assertEqual({c['id'] for c in value['cases']},{'T%02d'%i for i in range(1,11)})

if __name__=='__main__':unittest.main(verbosity=2)
