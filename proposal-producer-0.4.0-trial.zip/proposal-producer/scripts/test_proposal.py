"""Regression cases for arithmetic and version-bound evidence; fixtures are synthetic."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('proposal.py')
spec = importlib.util.spec_from_file_location('proposal', SCRIPT)
api = importlib.util.module_from_spec(spec); spec.loader.exec_module(api)

def pricing(**updates):
    value = {'kind': 'quote', 'pricing': {'currency': 'CNY', 'tax_rate': '0.06', 'tax_included': False, 'items': [
        {'id': 'Q1', 'quantity': '2', 'unit_price': '3000', 'selected': True, 'unit': '项', 'period': '一次性'},
        {'id': 'Q2', 'quantity': '1', 'unit_price': '1000', 'selected': True, 'unit': '年', 'period': '首年'},
        {'id': 'Q3', 'quantity': None, 'unit_price': None, 'selected': False}], 'payment_percentages': ['40', '60']}}
    value['pricing'].update(updates); return value

class Arithmetic(unittest.TestCase):
    def test_exclusive_tax_and_unselected_unknown(self):
        r = api.calculate(pricing()); self.assertEqual(r['issues'], [])
        self.assertEqual(r['pricing']['total'], '7420.00'); self.assertEqual(r['pricing']['tax'], '420.00')
        self.assertEqual(r['pricing']['payment_amounts'], ['2968.00', '4452.00'])
        self.assertIsNone(r['pricing']['rows'][2]['amount'])

    def test_inclusive_tax(self):
        p = pricing(tax_included=True); p['pricing']['items'][0]['unit_price'] = '3210'; p['pricing']['items'][1]['unit_price'] = '1000'
        r = api.calculate(p); self.assertEqual(r['pricing']['total'], '7420.00'); self.assertEqual(r['pricing']['subtotal_ex_tax'], '7000.00')

    def test_payment_rounding_reconciles(self):
        p = pricing(tax_rate='0', payment_percentages=['33.33', '33.33', '33.34']); p['pricing']['items'] = [{'id':'Q1','quantity':'1','unit_price':'0.05','selected':True,'unit':'项','period':'本期'}]
        r = api.calculate(p); self.assertEqual(sum(api.D(x) for x in r['pricing']['payment_amounts']), api.D('.05'))

    def test_selected_missing_not_zero(self):
        p = pricing(); p['pricing']['items'][0]['unit_price'] = '{{单价}}'
        r = api.calculate(p); self.assertTrue(r['issues']); self.assertIsNone(r['pricing'])

    def test_non_finite_rejected(self):
        p = pricing(); p['pricing']['items'][0]['unit_price'] = 'NaN'
        self.assertTrue(api.calculate(p)['issues'])

    def test_payment_percentage_error(self): self.assertTrue(api.calculate(pricing(payment_percentages=['20','20']))['issues'])

    def test_delayed_time_value_is_not_roi(self):
        p = pricing(); p['returns'] = {'model':'time_value','owner':'TEST TEAM','hourly_basis':'内部成本','basis_source':'TEST','cost_basis':'quote_total','hours_per_month':'200','improvement':'.5','hourly_value':'100','evaluation_start_month':1,'evaluation_months':12,'benefit_start_month':4,'comparison_cost':'7420'}
        r = api.calculate(p); self.assertEqual(r['issues'], []); self.assertEqual(r['returns']['effective_months'], 9)
        self.assertEqual(r['returns']['time_value'], '90000.00'); self.assertIsNone(r['returns']['financial_roi']); self.assertIsNone(r['returns']['cash_payback'])

    def test_return_cost_mismatch(self):
        p = pricing(); p['returns'] = {'model':'time_value','owner':'TEST','hourly_basis':'内部','basis_source':'TEST','cost_basis':'quote_total','hours_per_month':'1','improvement':'.5','hourly_value':'100','evaluation_start_month':1,'evaluation_months':12,'benefit_start_month':1,'comparison_cost':'1'}
        self.assertIn('不一致', api.calculate(p)['issues'][0])

class EvidenceState(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.work = Path(self.tmp.name)
        self.runcli('init', '--producer', 'TEST-PRODUCER', '--kind', 'product')
        p = api.load(self.work/'project.json'); self.initial_outputs = p['outputs'][:]
        p.update(audience='TEST', decision='TEST', outline=['TEST'], scope=['TEST'], outputs=['pptx'])
        api.save(self.work/'project.json', p)
        from presentation_fixtures import prepare_inputs
        prepare_inputs(self.work,api);self.runcli('production-check')

    def tearDown(self): self.tmp.cleanup()

    def runcli(self, command, *args, code=0):
        r = subprocess.run([sys.executable,str(SCRIPT),command,'--workdir',str(self.work),*args], capture_output=True,text=True)
        self.assertEqual(r.returncode,code,r.stdout+r.stderr)
        return json.loads(r.stdout or r.stderr)

    def test_init_no_overwrite_and_product_route(self):
        self.assertEqual(self.initial_outputs, ['pptx', 'ppt_pdf'])
        self.runcli('init','--producer','ANOTHER',code=2)
        self.assertEqual(api.load(self.work/'state.json')['producer'],'TEST-PRODUCER')

    def test_approval_requires_packet_and_key_changes_invalidate(self):
        self.runcli('approve','--actor','TEST ONLY','--evidence','TEST FIXTURE',code=2)
        self.runcli('packet'); self.runcli('approve','--actor','TEST ONLY','--evidence','TEST FIXTURE')
        self.assertTrue(self.runcli('status')['confirmed_current'])
        p = api.load(self.work/'project.json'); p['scope'].append('NEW SCOPE'); api.save(self.work/'project.json',p)
        self.assertFalse(self.runcli('status')['confirmed_current'])

    def test_packet_tampering_rejected(self):
        packet = self.runcli('packet'); Path(packet['path']).write_text('CHANGED TEST FIXTURE')
        self.runcli('approve','--actor','TEST ONLY','--evidence','TEST FIXTURE',code=2)

    def test_review_identity_and_candidate_binding(self):
        from pptx import Presentation
        ppt = self.work/'test.pptx'; deck = Presentation(); slide = deck.slides.add_slide(deck.slide_layouts[0]); slide.shapes.title.text='TEST ONLY'; deck.save(ppt)
        self.runcli('register','--role','pptx','--file',str(ppt))
        report = self.work/'review.md'; report.write_text('TEST FIXTURE ONLY: not a real independent review')
        self.runcli('review','--reviewer','TEST-PRODUCER','--report',str(report),'--result','pass',code=2)
        self.runcli('review','--reviewer','TEST-REVIEWER','--report',str(report),'--result','pass')
        self.assertTrue(self.runcli('status')['review_current'])
        original = ppt.read_bytes(); ppt.write_bytes(original + b'CHANGED TEST FILE')
        self.assertFalse(self.runcli('status')['review_current'])
        self.assertTrue(any('文件变化' in item for item in self.runcli('check',code=2)['issues']))
        ppt.write_bytes(original)
        self.assertTrue(self.runcli('status')['review_current'])
        (self.work/'content-base.md').write_text('CHANGED TEST CONTENT')
        self.assertFalse(self.runcli('status')['review_current'])

    def test_no_review_blocks_and_does_not_claim_sop_pass(self):
        r = self.runcli('check',code=2); self.assertEqual(r['mechanical_checks'],'blocked')
        self.assertIn('独立复核未通过或未登记',r['issues']); self.assertIn('仍须',r['sop_release'])

if __name__ == '__main__': unittest.main(verbosity=2)
