"""Synthetic actual-file mutations; mocks are limited to font/tool environment discovery.

These tests prove adapter invariants, not aesthetic quality, GUI editing or human review.
"""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from PIL import Image
from pptx import Presentation
import contracts
import proposal as api
import presentation
import render_adapter as render
import test_contracts as common
from presentation_fixtures import example_plan

ROOT=Path(__file__).resolve().parents[1]

class NativeVisual(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name)
        self.project=contracts.load(ROOT/'assets/project.json')
        self.project.update(schema=3,kind='product',outputs=['pptx','ppt_pdf'],shared_facts={'date':'2026-10-26','version':'synthetic-v4','period_months':None})
        self.plan=example_plan();self.plan['pages'][0]['visual']={'composition':'workflow','layout_reason':'Synthetic test','icon_ids':{'O1':'person'},'asset_ids':[],'calibration_focus':['relations']}
        self.profile=contracts.load(ROOT/'assets/visual-profile.json');self.profile['language']='en'
        self.route=contracts.load(ROOT/'assets/render-policy.json')
        self.write_inputs()
        fonts={r:{'requested':None,'actual_family':'Arial','file':None,'available':True} for r in ['title','body']}
        self.fontpatch=patch.object(render,'font_map',return_value=(fonts,{}));self.fontpatch.start()
    def tearDown(self):self.fontpatch.stop();self.tmp.cleanup()
    def write_inputs(self):
        for name,value in [('project.json',self.project),('presentation-plan.json',self.plan),('visual-profile.json',self.profile),('render-policy.json',self.route)]:api.save(self.work/name,value)
        api.save(self.work/'state.json',{'producer':'SYNTHETIC-PRODUCER'})
    def build(self,name='candidate'):
        self.write_inputs();report=render.build(self.work,self.project,self.plan,self.work/name,calibration=True)
        return self.work/name/'render-manifest.json',report
    def mutate(self,fn):
        manifest,report=self.build();ppt=Path(report['source_files']['pptx']['path']);deck=Presentation(ppt);fn(deck,report);deck.save(ppt)
        report['source_files']['pptx']=render.proof(ppt);api.save(manifest,report)
        return render.verify(self.work,self.project,manifest)
    def test_native_shapes_and_connected_relations_exist_in_real_file(self):
        manifest,report=self.build();contracts.validate(report,'render-manifest.schema.json')
        self.assertEqual(render.verify(self.work,self.project,manifest)['issues'],[])
        self.assertTrue(report['pages'][0]['objects'][0]['icon_shape_ids'])
        self.assertEqual(report['pages'][0]['relations'][0]['from_site'],6)
    def test_deleted_relation_caught_after_source_hash_rebound(self):
        def delete(deck,report):
            ident=report['pages'][0]['relations'][0]['shape_id'];shape=next(s for s in deck.slides[0].shapes if s.shape_id==ident);shape._element.getparent().remove(shape._element)
        self.assertTrue(any('关系线缺失' in v for v in self.mutate(delete)['issues']))
    def test_wrong_connector_endpoint_caught(self):
        def change(deck,report):
            ident=report['pages'][0]['relations'][0]['shape_id'];shape=next(s for s in deck.slides[0].shapes if s.shape_id==ident);shape._element.xpath('.//a:endCxn')[0].set('id','999')
        self.assertTrue(any('连线端点' in v for v in self.mutate(change)['issues']))
    def test_changed_ellipse_port_caught(self):
        def change(deck,report):
            ident=report['pages'][0]['relations'][0]['shape_id'];shape=next(s for s in deck.slides[0].shapes if s.shape_id==ident);shape._element.xpath('.//a:stCxn')[0].set('idx','3')
        self.assertTrue(any('端口' in v for v in self.mutate(change)['issues']))
    def test_manifest_endpoint_cannot_swap_planned_object(self):
        manifest,report=self.build();report['pages'][0]['relations'][0]['from_shape_id']=report['pages'][0]['objects'][2]['shape_id'];api.save(manifest,report)
        self.assertTrue(any('计划对象' in v for v in render.verify(self.work,self.project,manifest)['issues']))
    def test_literal_text_change_is_detected(self):
        def change(deck,report):
            next(s for s in deck.slides[0].shapes if s.name=='headline').text='Changed content'
        self.assertTrue(any('实际文字' in v for v in self.mutate(change)['issues']))
    def test_native_edit_save_and_reopen(self):
        manifest,report=self.build();ppt=Path(report['source_files']['pptx']['path']);deck=Presentation(ppt)
        deck.slides[0].shapes[0].text='Editable synthetic heading';edited=self.work/'edited.pptx';deck.save(edited)
        self.assertIn('Editable synthetic heading',Presentation(edited).slides[0].shapes[0].text)
    def test_failed_candidate_is_retained(self):
        self.route['default_mode']='full_image';self.write_inputs()
        with self.assertRaises(ValueError):render.build(self.work,self.project,self.plan,self.work/'failed',True)
        self.assertTrue((self.work/'failed/failure.json').is_file())
    def test_existing_candidate_never_overwritten(self):
        manifest,report=self.build();before=manifest.read_bytes()
        with self.assertRaises(ValueError):self.build()
        self.assertEqual(before,manifest.read_bytes())
    def test_table_body_regions_are_separate(self):
        self.plan['pages'][0]['copy']={'headline':'Synthetic table','body':['Next decision'], 'table':{'columns':['A','B'],'rows':[['One','Two']]}}
        manifest,report=self.build();deck=Presentation(report['source_files']['pptx']['path']);body=next(v for v in deck.slides[0].shapes if v.name=='body')
        labels=[v for v in deck.slides[0].shapes if v.name.startswith('label:')]
        self.assertTrue(all(v.top+v.height<body.top for v in labels))
        self.assertEqual(render.verify(self.work,self.project,manifest)['issues'],[])
    def test_missing_optional_tools_are_reported(self):
        with patch.object(render,'tool',return_value=None):
            result=render.doctor(self.work,self.project)
        self.assertFalse(result['pdf_export']);self.assertFalse(result['page_render']);self.assertEqual(result['image_provider']['status'],'not_configured')
    def test_doctor_works_before_initialization(self):
        import subprocess,sys
        result=subprocess.run([sys.executable,str(ROOT/'scripts/proposal.py'),'doctor','--workdir',str(self.work/'new-task')],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('tools',json.loads(result.stdout))
    def test_swapped_object_labels_are_detected(self):
        def swap(deck,report):
            a,b=report['pages'][0]['objects'][:2];shapes={s.shape_id:s for s in deck.slides[0].shapes};sa,sb=shapes[a['label_shape_id']],shapes[b['label_shape_id']];sa.text,sb.text=sb.text,sa.text
        self.assertTrue(any('对象标签' in s for s in self.mutate(swap)['issues']))
    def test_actual_image_dimensions_and_source_identity(self):
        image=self.work/'scene.png';Image.new('RGB',(960,540),'#DDDDDD').save(image)
        self.plan['visual_assets']=[{'asset_id':'SCENE','source':render.proof(image),'identity':'illustrative_diagram','source_description':'Synthetic image','rights':'Original synthetic test','purpose':'Explain the proposed scene'}]
        self.route['default_mode']='hybrid';self.plan['pages'][0]['visual']['asset_ids']=['SCENE']
        manifest,report=self.build();entry=report['pages'][0]['assets'][0]
        self.assertEqual(entry['dimensions'],[960,540]);self.assertEqual(entry['identity'],'illustrative_diagram')
    def full_image(self):
        image=self.work/'full.png';Image.new('RGB',(1280,720),'white').save(image)
        self.route.update(default_mode='full_image',editable_text=False,editable_relations=False,full_image_choice={'actor':'SYNTHETIC-USER','evidence':'Synthetic route protocol selection','page_ids':['P1']})
        self.plan['visual_assets']=[{'asset_id':'FULL','source':render.proof(image),'identity':'illustrative_diagram','source_description':'Synthetic full-page fixture','rights':'Original synthetic test','purpose':'Test full-image protocol'}]
        page=self.plan['pages'][0];page['visual']['background_asset_id']='FULL';page['visual']['image_regions']={v[k]:[.1,.1,.3,.2] for group,k in [('objects','object_id'),('relations','relation_id')] for v in page[group]}
        manifest,report=self.build();page=report['pages'][0];page['render']=render.proof(image);api.save(manifest,report)
        return manifest,report
    def test_full_image_needs_explicit_choice_and_editing_declaration(self):
        self.route['default_mode']='full_image';self.assertEqual(len(render.mode_issues(self.plan,self.route)),2)
    def test_full_image_without_actual_transcription_stays_pending(self):
        manifest,report=self.full_image();self.assertTrue(any('字面核对' in v for v in render.verify(self.work,self.project,manifest)['issues']))
    def test_missing_ocr_returns_actionable_gap(self):
        manifest,_=self.full_image()
        with patch.object(render,'tool',return_value=None):
            with self.assertRaisesRegex(ValueError,'独立检查者'):render.audit_images(self.work,self.project,manifest)
    def test_manual_audit_same_producer_and_missing_literal_both_block(self):
        manifest,report=self.full_image();page=report['pages'][0];trans=self.work/'transcription.json'
        api.save(trans,{'pages':[{'page_id':'P1','transcription':'Synthetic wrong words','render_sha256':page['render']['sha256']}]})
        result=render.audit_images(self.work,self.project,manifest,trans,'SYNTHETIC-PRODUCER')
        self.assertTrue(any('独立检查者' in v for v in result['issues']));self.assertTrue(any('冻结内容' in v for v in result['issues']))
    def test_transcription_stale_render_hash_rejected(self):
        manifest,report=self.full_image();trans=self.work/'transcription.json';api.save(trans,{'pages':[{'page_id':'P1','transcription':'x','render_sha256':'0'*64}]})
        with self.assertRaisesRegex(ValueError,'当前实际画面'):render.audit_images(self.work,self.project,manifest,trans,'SYNTHETIC-CHECKER')
    def test_task_profile_changes_invalidate_real_candidate(self):
        manifest,_=self.build();self.profile['brand']='Other synthetic task';api.save(self.work/'visual-profile.json',self.profile)
        self.assertTrue(any('视觉配置' in v for v in render.verify(self.work,self.project,manifest)['issues']))
    def test_sow_fonts_and_title_border_follow_task_profile(self):
        from docx import Document
        from docx.oxml.ns import qn
        self.profile['palette']={'background':'#FFFFFF','text':'#202020','primary':'#6B4B22','accent':'#6B4B22','muted':'#666666','surface':'#EEEEEE'}
        fonts={r:{'actual_family':'Arial'} for r in ['title','body']}
        file=self.work/'sow.docx';render.build_sow(self.project,self.plan,file,self.profile,fonts,api.calculate(self.project))
        doc=Document(file);border=doc.styles['Title'].element.xpath('.//w:pBdr/*')[0]
        self.assertEqual(border.get(qn('w:color')),'6B4B22');self.assertIsNone(border.get(qn('w:themeColor')))
        self.assertTrue(all(run.font.name=='Arial' for paragraph in doc.paragraphs for run in paragraph.runs))
    def test_catalog_resource_integrity(self):
        for item in render.catalog()['assets']:self.assertTrue(render.resource(item['id']).is_file())
        with self.assertRaises(ValueError):render.resource('../../outside')
    def test_partial_positions_preserve_other_objects(self):
        page=self.plan['pages'][0];page['visual']['positions']={'O1':[.1,.3,.2,.1]}
        result=render.layout(page,13.333333,7.5);self.assertEqual(len(result),3);self.assertAlmostEqual(result['O1'][0],1.3333333)

class ReviewSemantics(unittest.TestCase):
    setUp=common.ReleaseBoundary.setUp
    tearDown=common.ReleaseBoundary.tearDown
    cli=common.ReleaseBoundary.cli
    def change(self,key,value):
        review=api.load(self.work/'quality-review.json');next(v for v in review['criteria'] if v['criterion_id']=='PQ05')[key]=value;api.save(self.work/'quality-review.json',review)
    def test_nontarget_followup_keeps_positive_result(self):
        self.change('followups',[{'description':'Synthetic later extension','affects_target':False,'reason':'Outside current scope'}])
        self.assertEqual(self.cli('check')['quality_conclusions']['presentation_quality'],'acceptable')
    def test_target_gap_cannot_hide_as_followup_or_limitation(self):
        for key in ['followups','limitations']:
            with self.subTest(key=key):
                self.change(key,[{'description':'Synthetic target shortcoming','affects_target':True,'reason':'Prevents the decision question being answered'}])
                self.assertNotEqual(self.cli('check')['quality_conclusions']['presentation_quality'],'acceptable')
                self.change(key,[])
    def test_resolved_defect_needs_resolution_evidence(self):
        self.change('target_defects',[{'issue_id':'DEF1','description':'Synthetic repaired defect','status':'resolved','resolution_evidence':[]}])
        self.assertTrue(any('修复证据' in v for v in self.cli('check')['quality']['issues']))

if __name__=='__main__':unittest.main(verbosity=2)
