"""Authoring inputs, internal calibration and evidence-bound quality conclusions."""
import hashlib
import json
from pathlib import Path
import contracts

def rules(): return contracts.validate(contracts.load(contracts.ROOT/'contracts/presentation-quality.json'),'presentation-quality.schema.json')
def digest(data): return hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def resolve(work,path):
    path=Path(path); return (path if path.is_absolute() else work/path).resolve()
def plan_path(work,project): return resolve(work,project.get('presentation_plan') or 'presentation-plan.json')
def read_inputs(work,project):
    path=plan_path(work,project); calibration=work/'calibration.json'
    plan=contracts.validate(contracts.load(path),'presentation-plan.schema.json') if path.is_file() else None
    cal=contracts.validate(contracts.load(calibration),'calibration.schema.json') if calibration.is_file() else None
    return plan,cal
def proofs(data):
    if isinstance(data,dict):
        if set(data)=={'path','sha256'}: yield data
        else:
            for value in data.values(): yield from proofs(value)
    elif isinstance(data,list):
        for value in data: yield from proofs(value)
def proof_issues(work,data,label):
    issues=[]
    for entry in proofs(data):
        path=resolve(work,entry['path'])
        if not entry['sha256'] or not path.is_file() or sha(path)!=entry['sha256']: issues.append(label+': 证据缺失或版本变化 '+entry['path'])
    return issues
def input_manifest(work,project):
    """Bind named inputs, including actual reference and calibration files, without report cycles."""
    work=work.resolve();result={}
    files=[plan_path(work,project),work/'calibration.json']
    for field in ['visual_profile','render_policy']:
        if project.get(field):files.append(resolve(work,project[field]))
    for path in files:
        result[str(path)]=sha(path) if path.is_file() else None
        if path.is_file():
            for entry in proofs(contracts.load(path)):
                file=resolve(work,entry['path']);result[str(file)]=sha(file) if file.is_file() else None
    return result
def input_digest(work,project): return digest(input_manifest(work,project))
def ids(items,key,issues):
    keys=[item[key] for item in items]
    if len(keys)!=len(set(keys)): issues.append(key+': ID 重复')
    return set(keys)
def pointer(data,location):
    if not location.startswith('/'): raise ValueError('项目字段使用 JSON Pointer')
    for key in location[1:].split('/'):
        key=key.replace('~1','/').replace('~0','~')
        data=data[int(key)] if isinstance(data,list) else data[key]
    return data
def applicable(plan,project):
    declared={k:v['applicable'] for k,v in plan['applicability'].items()}
    declared['commercial']=bool(declared['commercial'] or plan['fee_value_mappings'] or project.get('pricing'))
    declared['scenario']=bool(declared['scenario'] or plan['scenarios'])
    declared['mechanism']=bool(declared['mechanism'] or plan['mechanisms'])
    declared.update(always=True,presentation=bool({'pptx','ppt_pdf'}&set(project['outputs'])))
    return {c['id']:declared[c['applicability_key']] for c in rules()['criteria']}

def production_issues(work,project,producer):
    issues=[];plan,cal=read_inputs(work,project)
    if plan is None:return ['缺 presentation-plan.json 制作输入']
    for key,entry in plan['applicability'].items():
        if not entry['applicable'] and not entry['reason']:issues.append(key+': 补适用性理由')
    known={}
    for name,key in [('references','reference_id'),('evidence_sources','evidence_id'),('claims','claim_id'),('scenarios','scenario_id'),('business_objects','object_id'),('mechanisms','mechanism_id'),('values','value_id'),('work_packages','work_package_id'),('deliverables','deliverable_id'),('fee_value_mappings','fee_id'),('pages','page_id')]:
        known[name]=ids(plan[name],key,issues)
    def refs(values,group,label):
        missing=set(values)-known[group]
        if missing:issues.append(label+': 引用不存在 '+','.join(sorted(missing)))
    strategy=plan['reference_strategy']
    if strategy['status']=='pending':issues.append('参考页分析尚未完成')
    if strategy['status']=='unavailable':
        if not strategy['reason']:issues.append('参考页不可用：补说明')
        if plan['references']:issues.append('已有选用参考页，应采用 selected 状态')
    if strategy['status']=='selected' and not plan['references']:issues.append('未登记选用的参考页及表达方法')
    issues+=proof_issues(work,plan,'制作输入')
    for claim in plan['claims']:
        refs(claim['evidence_ids'],'evidence_sources',claim['claim_id'])
        if claim['kind']=='source_fact' and not claim['evidence_ids']:issues.append(claim['claim_id']+': 来源事实缺依据')
        if claim['kind']=='assumption' and not claim['validation']:issues.append(claim['claim_id']+': 假设缺验证方式')
    for scenario in plan['scenarios']:
        refs(scenario['deliverable_ids'],'deliverables',scenario['scenario_id'])
        refs(scenario['source_refs'],'evidence_sources',scenario['scenario_id'])
        if not all(scenario[k] for k in ['actors','inputs','deliverable_ids']) or not (scenario['ai_actions'] or scenario['human_actions']):issues.append(scenario['scenario_id']+': 场景链条未填写完整')
        if scenario['status']=='source_case' and not scenario['source_refs']:issues.append(scenario['scenario_id']+': 来源案例缺原件依据')
    for item in plan['business_objects']:refs(item['scenario_ids'],'scenarios',item['object_id'])
    for mechanism in plan['mechanisms']:
        refs(mechanism['scenario_ids'],'scenarios',mechanism['mechanism_id'])
        nodes=ids(mechanism['nodes'],'node_id',issues);ids(mechanism['relations'],'relation_id',issues)
        for relation in mechanism['relations']:
            if relation['from'] not in nodes or relation['to'] not in nodes:issues.append(mechanism['mechanism_id']+': 关系端点不存在')
            refs([relation['business_object_id']],'business_objects',mechanism['mechanism_id'])
    if not plan['values']:issues.append('补受益对象、价值机制及其对本次决定的意义')
    for value in plan['values']:
        refs(value['mechanism_ids'],'mechanisms',value['value_id']);refs(value['evidence_ids'],'evidence_sources',value['value_id'])
        if value['basis_kind'] in ['evidence','mixed'] and not value['evidence_ids']:issues.append(value['value_id']+': 价值依据缺来源')
    for delivery in plan['deliverables']:refs([delivery['work_package_id']],'work_packages',delivery['deliverable_id'])
    source_packages={v['id']:v for v in project.get('work_packages',[])}
    if source_packages:
        for item in plan['work_packages']:
            if item['work_package_id'] not in source_packages:issues.append(item['work_package_id']+': 页计划工作包与共用底稿不一致')
    source_deliveries={v['id']:v for v in project.get('deliverable_details',[])}
    if source_deliveries:
        for item in plan['deliverables']:
            source=source_deliveries.get(item['deliverable_id'])
            if not source or item['work_package_id']!=source['work_package_id']:issues.append(item['deliverable_id']+': 页计划成果与共用底稿工作包不一致')
    for fee in plan['fee_value_mappings']:
        for name,group in [('work_package_ids','work_packages'),('deliverable_ids','deliverables'),('value_ids','values')]:refs(fee[name],group,fee['fee_id'])
        try:pointer(project,fee['project_pointer'])
        except (ValueError,KeyError,IndexError,TypeError):issues.append(fee['fee_id']+': 费用来源字段不存在')
        delivery_packages={d['work_package_id'] for d in plan['deliverables'] if d['deliverable_id'] in fee['deliverable_ids']}
        if not delivery_packages <= set(fee['work_package_ids']):issues.append(fee['fee_id']+': 工作包与交付对价断开')
    if project.get('schema')==4 and plan['fee_value_mappings'] and not project.get('pricing'):issues.append('费用映射需对应类型化 pricing 输入，按实际金额核算')
    needed=applicable(plan,project)
    if needed['PQ01'] and not plan['scenarios']:issues.append('本任务需具体业务场景')
    if needed['PQ02'] and not plan['mechanisms']:issues.append('本任务需业务对象与机制关系')
    if needed['PQ04'] and not plan['fee_value_mappings']:issues.append('有商业报价：补费用—工作包—成果—期间—价值映射')
    if not plan['pages']:issues.append('缺逐页决策问题与结论')
    semantic_ids=set().union(*known.values())
    semantic_ids.update(m['mechanism_id']+'/'+r['relation_id'] for m in plan['mechanisms'] for r in m['relations'])
    semantic_ids.update(m['mechanism_id']+'/'+n['node_id'] for m in plan['mechanisms'] for n in m['nodes'])
    for page in plan['pages']:
        ident=page['page_id']
        for name,group in [('claim_ids','claims'),('evidence_ids','evidence_sources'),('reference_page_ids','references'),('scenario_ids','scenarios'),('mechanism_ids','mechanisms'),('value_ids','values'),('fee_ids','fee_value_mappings')]:refs(page[name],group,ident)
        nodes=ids(page['objects'],'object_id',issues);ids(page['relations'],'relation_id',issues)
        for item in page['objects']+page['relations']:
            if item['semantic_ref'] not in semantic_ids:issues.append(ident+': 对象或关系未关联底稿内容 '+item['semantic_ref'])
        for relation in page['relations']:
            if relation['from'] not in nodes or relation['to'] not in nodes:issues.append(ident+': 页面关系端点不存在')
        for role,field in [('scenario','scenario_ids'),('mechanism','mechanism_ids'),('value','value_ids'),('commercial','fee_ids')]:
            if role in page['explanation_roles'] and not page[field]:issues.append(ident+': '+role+' 未关联实际内容')
        if 'mechanism' in page['explanation_roles'] and not page['relations']:issues.append(ident+': 机制页只有对象，缺作用关系')
        if page['key_page'] and strategy['status']=='selected' and not page['reference_page_ids']:issues.append(ident+': 关键页未采用已分析的参考方法')
        visual=page.get('visual',{})
        assets={v['asset_id'] for v in plan.get('visual_assets',[])}
        used=set(visual.get('asset_ids',[]))|({visual['background_asset_id']} if visual.get('background_asset_id') else set())
        if used-assets:issues.append(ident+': 视觉素材未登记 '+','.join(sorted(used-assets)))
        if set(visual.get('positions',{}))-nodes:issues.append(ident+': 视觉位置引用未知对象')
        if visual.get('icon_ids'):
            from render_adapter import resource
            for object_id,icon_id in visual['icon_ids'].items():
                if object_id not in nodes:issues.append(ident+': 图标引用未知对象')
                try:resource(icon_id)
                except ValueError as exc:issues.append(str(exc))
        if project.get('schema')==4:
            sections={v['anchor'] for v in project.get('sow_sections',[])}
            available=sections|known['deliverables']
            for ref in page['sow_detail_refs']:
                if ref not in available:issues.append(ident+': SOW 引用未指向实际稳定锚点 '+ref)
    assets=[v['asset_id'] for v in plan.get('visual_assets',[])]
    if len(assets)!=len(set(assets)):issues.append('视觉素材 ID 重复')
    key_pages={p['page_id']:p for p in plan['pages'] if p['key_page']}
    if not key_pages:issues.append('选择用于内部校准的关键解释页')
    # The current task chooses key pages; there is no universal page-role quota.
    if cal is None:return issues+['缺关键页内部校准记录']
    if project.get('schema')==4:
        proof=cal.get('render_manifest')
        if not proof:issues.append('关键页校准缺实际渲染清单')
        else:
            from render_adapter import verify
            check=verify(work,project,proof['path']);issues+=check['issues']
            if Path(resolve(work,proof['path'])).is_file():
                manifest=contracts.load(resolve(work,proof['path']));rendered={v['page_id']:v.get('render') for v in manifest['pages']}
                for record in cal['pages']:
                    if not rendered.get(record['page_id']) or record['render']['sha256']!=rendered[record['page_id']]['sha256']:issues.append(record['page_id']+': 校准未使用实际导出画面')
    if cal['plan_sha256']!=sha(plan_path(work,project)):issues.append('校准对应的页计划已变化')
    if cal['producer']!=producer:issues.append('内部校准制作身份不符')
    issues+=proof_issues(work,cal,'关键页校准')
    ids(cal['pages'],'page_id',issues);records={r['page_id']:r for r in cal['pages']}
    for ident,page in key_pages.items():
        record=records.get(ident)
        if not record:issues.append(ident+': 关键页尚未渲染并校准');continue
        if record['result'] not in rules()['calibration']['passing_results']:issues.append(ident+': 校准仍有缺口')
        if set(record['reference_page_ids'])!=set(page['reference_page_ids']):issues.append(ident+': 校准参考页不对应')
        if project.get('schema')==4:
            for focus in page.get('visual',{}).get('calibration_focus',[]):
                if not record.get('visual_observations',{}).get(focus):issues.append(ident+': 校准缺选定视觉重点 '+focus)
        for field,source,key in [('observed_object_ids','objects','object_id'),('observed_relation_ids','relations','relation_id')]:
            if not {r[key] for r in page[source]} <= set(record[field]):issues.append(ident+': 校准未保留计划对象或关系')
    return issues

def production_record(work,project,state):
    issues=production_issues(work,project,state['producer'])
    if issues:return {'status':'blocked','issues':issues}
    return {'status':'ready','issues':[],'input_digest':input_digest(work,project),'plan_sha256':sha(plan_path(work,project)),'calibration_sha256':sha(work/'calibration.json')}
def registration_issues(work,project,state):
    record=state.get('production')
    if not record:return ['先完成关键页内部校准并运行 production-check']
    if record['input_digest']!=input_digest(work,project):return ['制作输入或校准变化，重新运行 production-check']
    return production_issues(work,project,state['producer'])

def review_starter(work,project,reviewer,candidate_digest):
    plan,_=read_inputs(work,project)
    if plan is None:raise ValueError('先编制 presentation-plan.json')
    return {'schema':1,'candidate_digest':candidate_digest,'quality_target':project.get('quality_target','client_presentation'),'reviewer':reviewer,'criteria':[{'criterion_id':c['id'],'applicable':applicable(plan,project)[c['id']],'result':'not_evaluated','page_refs':[],'reference_page_refs':[],'reason':'待实际评审','defects':[],'target_defects':[],'followups':[],'limitations':[],'evidence':[]} for c in rules()['criteria']],'page_reviews':[]}

def quality_summary(work,project,state,candidate_digest,source_pages=None):
    """Separate recorded business/presentation judgments from mechanical pass/fail."""
    result={'quality_target':project.get('quality_target','client_presentation'),'business_argument':'not_evaluated','presentation_quality':'not_evaluated','target_met':False,'issues':[]}
    issues=result['issues'];path=work/'quality-review.json';plan,_=read_inputs(work,project)
    if plan is None or not path.is_file():issues.append('缺最终候选的论证与展示质量评审');return result
    review=contracts.validate(contracts.load(path),'quality-review.schema.json')
    result['criterion_results']=[{'criterion_id':v['criterion_id'],'result':v['result'],'page_refs':v['page_refs'],'reason':v['reason'],'defects':v['defects']} for v in review['criteria']]
    if review['candidate_digest']!=candidate_digest:issues.append('质量评审候选版本已失效')
    if review['quality_target']!=result['quality_target']:issues.append('质量目标与本任务不符')
    if review['reviewer']==state['producer'] or review['reviewer']!=state.get('review',{}).get('reviewer'):issues.append('质量评审应由本次独立检查者完成')
    issues+=proof_issues(work,review,'质量评审')
    base_invalid=bool(issues)
    criteria=rules()['criteria'];ids(review['criteria'],'criterion_id',issues)
    records={v['criterion_id']:v for v in review['criteria']};expected=applicable(plan,project)
    groups={k:[] for k in ['business_argument','presentation_quality']};positive=rules()['aggregation']['positive'];page_ids={p['page_id'] for p in plan['pages']};reference_ids={r['reference_id'] for r in plan['references']}
    for criterion in criteria:
        before=len(issues)
        ident=criterion['id'];record=records.get(ident)
        if not record:issues.append(ident+': 缺质量结论');groups[criterion['group']].append('not_evaluated');continue
        if record['applicable']!=expected[ident]:issues.append(ident+': 适用性与制作输入不符')
        if set(record['page_refs'])-page_ids or set(record['reference_page_refs'])-reference_ids:issues.append(ident+': 评审页面或参考页引用不存在')
        if not expected[ident]:
            if record['result']!='not_applicable':issues.append(ident+': 登记实际不适用结论及理由')
            continue
        groups[criterion['group']].append(record['result'])
        if record['result']=='not_applicable':issues.append(ident+': 适用质量维度不可豁免')
        if record['result'] in positive and (not record['page_refs'] or not record['evidence']):issues.append(ident+': 通过结论缺具体页面或证据')
        if record['result'] in positive and record['defects']:issues.append(ident+': 未解决缺陷与通过结论冲突')
        target_open=any(v['status']=='open' for v in record.get('target_defects',[]))
        target_open=target_open or any(v['affects_target'] for key in ['followups','limitations'] for v in record.get(key,[]))
        if target_open:
            groups[criterion['group']].append('gap')
            if record['result'] in positive:issues.append(ident+': 目标缺陷尚未解决')
        for defect in record.get('target_defects',[]):
            if defect['status']=='resolved' and not defect['resolution_evidence']:issues.append(ident+': 缺陷关闭缺实际修复证据')
        if record['result']=='gap' and not record['defects'] and not target_open:issues.append(ident+': 缺口结论需具体缺陷')
        if len(issues)>before:groups[criterion['group']].append('not_evaluated')
    page_records={r['page_id']:r for r in review['page_reviews']};ids(review['page_reviews'],'page_id',issues)
    if set(page_records)-page_ids:issues.append('成品评审包含未知页')
    for page in plan['pages']:
        before=len(issues)
        record=page_records.get(page['page_id'])
        if not record:groups['presentation_quality'].append('not_evaluated');continue
        groups['presentation_quality'].append(record['result'])
        if record['result'] in positive:
            if project.get('schema')==4:
                from render_adapter import path as render_path
                manifest_file=render_path(work,project.get('render_manifest') or 'render-manifest.json')
                if not manifest_file.is_file():issues.append(page['page_id']+': 质量复核缺实际渲染清单')
                else:
                    manifest=contracts.load(manifest_file);rendered=next((v.get('render') for v in manifest['pages'] if v['page_id']==page['page_id']),None)
                    if not rendered or record['render']['sha256']!=rendered['sha256']:issues.append(page['page_id']+': 复核画面与成品实际导出不符')
                selected=page.get('visual',{}).get('calibration_focus',[])
                if any(not record.get('visual_observations',{}).get(key) for key in selected):issues.append(page['page_id']+': 缺选定视觉重点的实际评价')
            if not record['decision_question_answered']:issues.append(page['page_id']+': 没有回答计划中的决策问题')
            if page['reference_page_ids'] and not record['reference_method_observed']:issues.append(page['page_id']+': 未记录参考方法在成品中的效果')
            for field,source,key in [('observed_object_ids','objects','object_id'),('observed_relation_ids','relations','relation_id')]:
                if not {r[key] for r in page[source]} <= set(record[field]):issues.append(page['page_id']+': 成品丢失计划中的对象或关系')
        if len(issues)>before:groups['presentation_quality'].append('gap')
    if source_pages is not None and source_pages!=len(plan['pages']):issues.append('成品页数与逐页解释计划不符');groups['presentation_quality'].append('gap')
    if base_invalid:
        for values in groups.values():values.append('not_evaluated')
    for name,values in groups.items():
        result[name]='gap' if 'gap' in values else 'not_evaluated' if not values or any(v not in positive for v in values) else 'strong' if all(v=='strong' for v in values) else 'acceptable'
    result['target_met']=not issues and all(result[k] in positive for k in groups)
    return result
def release_issues(work,project,state,candidate_digest,source_pages=None):
    issues=registration_issues(work,project,state)
    summary=quality_summary(work,project,state,candidate_digest,source_pages)
    issues+=summary['issues']
    if summary['quality_target']=='client_presentation' and not summary['target_met']:issues.append('展示目标未达到：技术通过不能覆盖论证或展示缺口')
    return issues,summary
