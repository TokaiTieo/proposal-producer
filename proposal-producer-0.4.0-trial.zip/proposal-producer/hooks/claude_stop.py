#!/usr/bin/env python3
"""Claude Code Stop adapter. It checks an existing release; drafts may stop normally."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import contracts
import gates
import proposal
import presentation

def verdict(work, event):
    contracts.validate(event,'hook-input.schema.json')
    if not (work/'release.json').is_file(): return {}
    project,state=proposal.context(work)
    fp=proposal.candidate(work,project,state)
    issues=proposal.check(work,project,state)['issues']
    issues+=gates.evidence_issues(work,project,state,fp,proposal.filehash)
    issues+=presentation.release_issues(work,project,state,fp)[0]
    issues+=gates.receipt_issues(work,project,state,fp,proposal.filehash)
    if issues:
        return {'decision':'block','reason':'本地放行记录已失效。修复并重新 release；保留草案时将旧 release.json 归档。'+'；'.join(issues)}
    return {}

def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--workdir',type=Path,required=True)
    args=parser.parse_args()
    try:
        result=verdict(args.workdir.resolve(),json.load(sys.stdin))
        print(json.dumps(result,ensure_ascii=False))
    except Exception as exc:
        print(str(exc),file=sys.stderr); return 2
    return 0

if __name__=='__main__': sys.exit(main())
