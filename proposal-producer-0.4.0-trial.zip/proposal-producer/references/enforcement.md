# 执行门禁与宿主钩子

`release` 是本地放行入口：先重新读取项目和候选文件，再检查确认、复核及逐项证据，成功后保存当前版本的放行记录。普通制作、排版与草案讨论可以继续，不要求重复批准。

`production-check` 核对参考分析、内容关联与关键页内部校准，状态有效后才能登记全稿。`release` 分别检查技术条件与当前质量目标，放行清单保留论证及展示的实际结论。展示目标的达成依据见 `contracts/presentation-quality.json`；本地存放和合同草案标记不改变该目标。

可为 Claude Code 生成绑定当前工作位置的设置片段：

```sh
PYTHON HELPER hook-config --workdir RUN
```

输出为宿主的 JSON 设置格式；将其合并到该项目的 `.claude/settings.local.json`，保留已有 hooks。首次接入后，在宿主中检查加载结果。Skill 安装和发现不自动改写宿主设置。

钩子读取现有本地放行记录，调用同一门禁检查；记录失效时返回阻止结束的判定。草案没有放行记录时可正常结束。当前任务改回草案时，归档原放行记录，保留历史。它覆盖已绑定工作位置的停止事件；文件发送仍受实际渠道的权限约束。

宿主协议依据 [Claude Code hooks 文档](https://code.claude.com/docs/en/hooks)。本地 JSON Schema 校验与模型生成时的约束解码是两种接入方式；后者需要在 API 请求中指定 Schema，参见 [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs)。本 Skill 提供本地校验及钩子适配器。

CI 运行 Schema 校验、计算与状态回归、放行及钩子协议测试。人工检查证据的真实性、商业判断与画面效果仍由相应检查过程负责。覆盖边界在 `contracts/policy.json` 登记。
