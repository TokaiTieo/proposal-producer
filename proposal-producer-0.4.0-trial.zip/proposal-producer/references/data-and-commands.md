# 数据与命令

先选定本任务可用的 Python 环境，确保 `requirements.txt` 中的组件可用。下文以 `PYTHON`、`HELPER`、`RUN` 分别表示解释器、`scripts/proposal.py` 和用户指定工作位置；具体取值由执行环境提供。

```sh
PYTHON HELPER validate --workdir RUN
PYTHON HELPER init --workdir RUN --producer ACTUAL_INSTANCE_ID
PYTHON HELPER calculate --workdir RUN
PYTHON HELPER production-check --workdir RUN
PYTHON HELPER packet --workdir RUN
PYTHON HELPER approve --workdir RUN --actor ACTUAL_APPROVER --evidence ACTUAL_REPLY_LOCATION
PYTHON HELPER register --workdir RUN --role ROLE --file ACTUAL_FILE
PYTHON HELPER review --workdir RUN --reviewer ACTUAL_REVIEWER --report ACTUAL_REPORT --result RESULT
PYTHON HELPER quality-init --workdir RUN --reviewer ACTUAL_REVIEWER
PYTHON HELPER check --workdir RUN
PYTHON HELPER checks-init --workdir RUN
PYTHON HELPER release --workdir RUN
PYTHON HELPER status --workdir RUN
```

命令、枚举、默认值和退出条件由 `contracts/policy.json` 与脚本定义。`validate` 校验 Schema 本身、契约引用及工作数据。模板结构允许增删表格记录，字段名由对应 Schema 约束。

初始化会创建页计划和内部校准记录。参考分析、页级解释任务和业务内容填入 `presentation-plan.json`；实际渲染、并排比较及内部判断填入 `calibration.json`。运行 `production-check` 后才能登记全稿；制作输入或校准记录变化时重新运行该命令。它记录内部制作状态，沿用既有内容确认。

`packet` 输出与当前项目关键字段绑定的 JSON。取得真实确认后，`approve` 登记确认人及回复位置。`register` 登记实际文件，`review` 登记已完成的独立报告。`checks-init` 创建本次适用项；检查者填写结论、位置和证据哈希，测量值与适用豁免按 Schema 登记。

`check` 检查可自动核对的状态、计算与文件；`release` 同时检查适用项覆盖、证据、测量阈值及当前版本，生成本地放行清单。需要复制交付文件到指定位置时，增加 `--destination`。实际发送由已获授权的宿主渠道完成。

`quality-init` 根据本次内容创建适用质量项，由本次独立检查者填写具体页面、参考方法、实际渲染与结论。`check` 分别输出技术、论证和展示质量；`release` 同时核对本次质量目标。修改质量记录会使旧放行记录失效；修改制作输入或候选文件会使旧质量评审失效。普通视觉修正重新校准与复核，业务确认按原有关键内容判定。

确认绑定项目关键内容；独立复核绑定项目变量、模板数据、候选文件及规则。修订后通过 `status` 判断哪些证据已失效。脚本记录声明的身份和证据文件，身份真实性及语义结论仍由真实检查过程负责。

数值示例位于 `evals/fixtures/project-quote.json`，只用于试验。旧版项目保留原件，根据当前 `schemas/project.schema.json` 补齐迁移字段，再重新生成确认与复核证据。旧版历史报告继续保留为当时版本的记录。

阅读 JSON 模板时可导出临时 Markdown：

```sh
PYTHON HELPER render --workdir RUN --file RUN/content-base.json
```

生成的阅读稿是视图；修改项目数据回到 JSON。

真实旧新稿配对评测当前留空；实际同 brief 成品和评审齐备后再填入。自动回归测试中的合成样例仅验证脚本行为。

## 本地制作与导出

`init` 同时创建 `visual-profile.json` 与 `render-policy.json`。项目使用当前 Schema；初始化中的未知日期、版本和业务字段在起草时保留，制作完整候选前填写共同日期和版本。金额输入参照 `schemas/project.schema.json`，使用 `calculate` 和 `shared-facts` 核对。新项目从空白模板开始，`evals/fixtures/` 是显式调用的试验数据。

```sh
PYTHON HELPER doctor --workdir RUN
PYTHON HELPER shared-facts --workdir RUN
PYTHON ADAPTER build --workdir RUN --calibration --destination KEY_CANDIDATE
PYTHON ADAPTER export --workdir RUN --manifest KEY_CANDIDATE/render-manifest.json
# 查看关键页后填写 calibration.json，沿用有效内容确认。
PYTHON HELPER production-check --workdir RUN
PYTHON HELPER build --workdir RUN --destination FULL_CANDIDATE
PYTHON HELPER export --workdir RUN --file FULL_CANDIDATE/render-manifest.json
PYTHON HELPER render-check --workdir RUN --file FULL_CANDIDATE/render-manifest.json
# 仅整页图像页需要图像文字转写；原生文字直接读取源稿。
PYTHON HELPER audit-images --workdir RUN --file FULL_CANDIDATE/render-manifest.json --report TRANSCRIPTION --reviewer ACTUAL_REVIEWER
```

`ADAPTER` 是同目录下的 `scripts/render_adapter.py`。全稿 `build` 读取当前通过的制作输入；试制可先用适配器的 `--calibration`，它保留为局部候选。每个候选使用新目录，重复导出也使用新位置，旧文件与失败信息保留。

本地渲染清单记录实际源稿和导出文件。完成制作后，仍需用 `register` 登记本次所选文件，再由实际独立检查者完成评审；生成候选和通过 `render-check` 不会代为登记用户批准或质量通过。

`project.data_files` 可登记额外任务 JSON 及其本地 Schema；默认数据文件和可配置路径见 `contracts/fact-policy.json`。仅这些明确登记的输入参与校验与版本绑定，同目录的运行日志和其他 JSON 不会被当成底稿。

`evals/presentation-cases.json` 定义可复用验收用例，真实旧新成品配对记录与自动合成回归分开保存。发布包中不附带客户素材、试用产物或作者的工具缓存。
