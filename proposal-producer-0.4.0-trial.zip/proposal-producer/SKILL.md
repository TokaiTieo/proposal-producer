---
name: proposal-producer
description: 制作或修改商业合作、方案报价及产品立项 Proposal，整理共用底稿，生成所选 PPTX、SOW DOCX、PDF，核对金额、版本和跨文件关系。用户要求实际提案文件或提案模板归纳时使用；单纯讨论想法时不启动文件制作。
---

# Proposal Producer

把当前资料组织为支持受众作出决定的提案。类型、默认交付物、阈值和执行规则从 [执行契约](contracts/policy.json) 读取；项目事实、品牌配置和评测样例分别存放。

先读 [工作方法](references/workflow.md) 和 [数据与命令](references/data-and-commands.md)。读取已有文件与有效授权，集中补充影响本次工作的资料；起草内容沿用占位字段。已有内容确认继续有效，普通视觉调整由制作实例内部完成。模板归纳任务走 [模板建立与更新](references/template-maintenance.md)。

按当前任务加载对应方法：

- 制作 PPT：读 [提案表达](references/presentation-design.md) 和 [视觉制作与渲染](references/visual-production.md)。把参考页的方法转成页计划，选择本任务需要校准的解释内容，实际制作并导出查看。
- 生成 SOW 或 PDF：读 [交付物派生](references/artifacts.md)。日期、版本、金额、范围、成果及里程碑从共用底稿读取，SOW 使用稳定章节锚点。
- 接入宿主门禁：读 [执行集成](references/enforcement.md)。可选治理用途按 [治理说明](references/optional-governance.md) 启用。

先运行契约校验和环境检测，再按 Schema 填写任务数据。内部关键页校准通过后运行 `production-check`，将内容复用到原有确认节点，连续完成全稿。原生、混合与整页图像路线按编辑要求和实际工具选择；整页图像沿用明确的选择依据。

独立检查者查看实际成品，分别评价技术、论证和展示质量。目标缺陷、后续约定与适用限制按实际影响记录。修订后更新受影响页面、派生文件和证据，再运行 `check` 与 `release`，通过已获授权的渠道交付。机械校验覆盖结构、计算、引用和证据，表达效果由实际页面评价判定。
