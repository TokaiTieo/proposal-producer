"""Shared Proposal semantics, instruction handoff and client-artifact projections.

Only observable coverage and source consistency are automated. A reviewer still
compares the original instructions and evaluates the strength of the argument.
"""
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import contracts

ROOT=contracts.ROOT

def active(project):return project.get('schema',0)>=5
def written(project):return project.get('schema',0)>=6
def has_ppt(project):return bool({'pptx','ppt_pdf'} & set(project['outputs']))
def rules():return contracts.validate(contracts.load(ROOT/'contracts/proposal-model.json'),'proposal-model.schema.json')
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def proof(path):return {'path':str(Path(path).resolve()),'sha256':sha(path)}
def save(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def resolve(work,path):
    file=Path(path);return (file if file.is_absolute() else Path(work)/file).resolve()
def normalize(value):return ''.join(str(value).split()).replace(',','').replace('，','')
def pointer(data,location):
    if not location.startswith('/'):raise ValueError('事实引用需 JSON Pointer '+location)
    for key in location[1:].split('/'):
        key=key.replace('~1','/').replace('~0','~');data=data[int(key)] if isinstance(data,list) else data[key]
    return data

def source_value(project,ref):
    if ref.startswith('calc:'):
        from proposal import calculate
        return pointer(calculate(project),ref[5:])
    return pointer(project,ref)

def resolve_text(project,value):
    def replace(match):
        val=source_value(project,match.group(1))
        if val is None:raise ValueError('正式事实待补 '+match.group(1))
        return json.dumps(val,ensure_ascii=False) if isinstance(val,(dict,list)) else str(val)
    return re.sub(rules()['fact_template_pattern'],replace,str(value))

def base(work):return contracts.validate(contracts.load(Path(work)/'content-base.json'),'templates/01-content-base.schema.json')
def story(work):return contracts.validate(contracts.load(Path(work)/'story-map.json'),'templates/06-story-map.schema.json')
def requirements(project):return [copy.deepcopy(v) for v in project.get('request_requirements',[]) if v['status']=='active']
def requirements_digest(project):
    values=requirements(project)
    for value in values:
        if value['source']['evidence']:value['source']['evidence'].pop('path',None)
    return digest({'version':project['request_requirements_version'],'requirements':values})
def business_requirements(project):
    return [v for v in requirements(project) if v['scope'] in rules()['content_confirmation_scopes']]

def handoff_value(project):
    required=requirements(project);sources=[]
    for item in required:
        evidence=item['source']['evidence']
        if evidence and evidence not in sources:sources.append(evidence)
    keys=['kind','audience','decision','scope','outputs','shared_facts','decision_context']+(['presentation_requested','sow_required','document_plan','document_metadata','task_scope'] if written(project) else [])
    if project.get('schema',0)>=7:keys.append('production_chain')
    return {'schema':1,'requirements_version':project['request_requirements_version'],'requirements_digest':requirements_digest(project),'project_context':{k:project.get(k) for k in keys},'requirements':required,'source_manifest':sources}

def handoff(work,project):
    value=handoff_value(project);contracts.validate(value,'handoff.schema.json');save(Path(work)/'handoff.json',value);return value

def request_issues(work,project,check_handoff=True):
    issues=[];all_ids=[v['id'] for v in project.get('request_requirements',[])]
    if len(all_ids)!=len(set(all_ids)):issues.append('任务要求 ID 重复')
    if not requirements(project):issues.append('登记当前有效任务要求及原始指令来源')
    for item in requirements(project):
        if set(item['affected_outputs'])-set(project['outputs']):issues.append(item['id']+': 任务要求引用未选交付物')
        evidence=item['source']['evidence']
        if evidence:
            path=resolve(work,evidence['path'])
            if not path.is_file() or sha(path)!=evidence['sha256']:issues.append(item['id']+': 原始要求证据缺失或变化')
            elif normalize(item['source']['quote']) not in normalize(path.read_text()):issues.append(item['id']+': 原始指令摘录未见于证据')
    ctx=project.get('decision_context') or {}
    if not all(ctx.get(k) for k in ['requested_action','commitment_scope','evidence_expectation']):issues.append('决定范围及对应证据要求待补')
    if set(ctx.get('source_requirement_refs',[]))-{v['id'] for v in requirements(project)}:issues.append('决定范围引用非有效任务要求')
    if check_handoff:
        file=Path(work)/'handoff.json'
        if not file.is_file():issues.append('生成携带有效要求 ID 与版本的 handoff.json')
        elif contracts.validate(contracts.load(file),'handoff.schema.json')!=handoff_value(project):issues.append('交接要求覆盖或版本不一致；重新生成 handoff')
    return issues

def client_language(work):
    if work is None:return 'zh'
    project=contracts.load(Path(work)/'project.json')
    profile=resolve(work,project.get('visual_profile') or 'visual-profile.json')
    language=contracts.load(profile)['language'] if profile.is_file() else 'zh-CN'
    return 'zh' if language.startswith('zh') else 'en'

def unit_texts(project,unit,summary=None,work=None,role=None,location=None):
    if work is not None:
        import client_content
        if client_content.active(project):return client_content.unit_texts(work,project,unit,summary,role,location)
    result=[resolve_text(project,summary or unit['claim'])]
    labels=rules()['client_condition_labels_by_language'][client_language(work)]
    for field in ['assumptions','conditions']:
        result += [labels[field]+': '+resolve_text(project,v) for v in unit[field]]
    if unit['validation']:result.append(labels['validation']+': '+resolve_text(project,unit['validation']))
    return result

def projection_summary(row):
    # A combined summary cannot stand in for several distinct arguments.
    return row['summary_and_conditions'] if len(row['source_refs'])==1 else None

def index(items,key,issues,label):
    values={}
    for item in items:
        ident=item[key]
        if ident in values:issues.append(label+': ID 重复 '+ident)
        values[ident]=item
    return values

def model_issues(work,project,check_handoff=True):
    if not active(project):return []
    issues=request_issues(work,project,check_handoff);content=base(work);chain=story(work)
    if content.get('schema')!=2 or chain.get('schema')!=2:return issues+['新任务使用共同论证模型；旧底稿需显式迁移']
    import client_content
    issues+=client_content.input_issues(work,project)
    units=index(content['semantic_units'],'id',issues,'semantic_units');mods=index(content['modules'],'id',issues,'modules')
    customer_units={k:u for k,u in units.items() if client_content.client_unit(work,project,u)}
    evid=index(content['evidence_sources'],'evidence_id',issues,'evidence_sources');mechanisms=index(content['mechanisms'],'mechanism_id',issues,'mechanisms')
    fields=set();mapped=set()
    for module in mods.values():
        if module['applicability']=='pending':issues.append(module['id']+': 模块适用性待定')
        if module['applicability']=='not_applicable':
            if not module['reason']:issues.append(module['id']+': 不适用理由待补')
            continue
        if not module['unit_refs']:issues.append(module['id']+': 适用模块缺论证单元')
        for ref in module['unit_refs']:
            if ref not in units:issues.append(module['id']+': 论证单元不存在 '+ref)
            else:
                mapped.add(ref)
                if ref in customer_units:fields.update(set(units[ref]['field_refs'])&set(module['field_refs']))
    for field in set(rules()['required_fields'][project['kind']])-fields:issues.append(field+': 本类型的适用商业内容待补')
    for ident,unit in units.items():
        if ident not in mapped:issues.append(ident+': 未关联适用模块')
        if set(unit['mechanism_refs'])-set(mechanisms):issues.append(ident+': 引用不存在的机制')
        if set(unit['evidence_refs'])-set(evid):issues.append(ident+': 引用不存在的依据')
        if unit['kind']=='source_fact' and not unit['evidence_refs']:issues.append(ident+': 来源事实缺依据')
        if unit['kind']=='assumption' and not unit['validation']:issues.append(ident+': 价值假设缺验证安排')
        if unit['kind']=='commitment' and project['decision_context']['commitment_scope']=='binding' and not unit['evidence_refs']:issues.append(ident+': 绑定性结果承诺缺对应支持')
        for ref in unit['fact_refs']:
            try:
                if source_value(project,ref) is None:issues.append(ident+': 正式事实待补 '+ref)
            except (ValueError,KeyError,IndexError,TypeError):issues.append(ident+': 正式事实引用无效 '+ref)
        for text in [unit['claim']]+unit['assumptions']+unit['conditions']+([unit['validation']] if unit['validation'] else []):
            for ref in re.findall(rules()['fact_template_pattern'],text):
                if ref not in unit['fact_refs']:issues.append(ident+': 文稿事实引用未登记 '+ref)
            try:resolve_text(project,text)
            except (ValueError,KeyError,TypeError,IndexError) as exc:issues.append(ident+': '+str(exc))
    # Existing structured scenarios/mechanisms retain their reference semantics.
    scenarios={v['scenario_id'] for v in content['scenarios']};objects={v['object_id'] for v in content['business_objects']};deliveries={v['id'] for v in project.get('deliverable_details',[])};packages={v['id'] for v in project.get('work_packages',[])}
    for scenario in content['scenarios']:
        if not (scenario['ai_actions'] or scenario['human_actions']):issues.append(scenario['scenario_id']+': 场景缺具体动作')
        if set(scenario['deliverable_ids'])-deliveries:issues.append(scenario['scenario_id']+': 场景成果未见于正式底稿')
        if scenario['status']=='source_case' and not scenario['source_refs']:issues.append(scenario['scenario_id']+': 来源案例缺依据')
    for mech in mechanisms.values():
        nodes={n['node_id'] for n in mech['nodes']}
        for rel in mech['relations']:
            if rel['from'] not in nodes or rel['to'] not in nodes or rel['business_object_id'] not in objects:issues.append(mech['mechanism_id']+': 业务对象或关系端点无效')
    for fee in content['fee_value_mappings']:
        if set(fee['work_package_ids'])-packages or set(fee['deliverable_ids'])-deliveries:issues.append(fee['fee_id']+': 费用对价引用未见于正式底稿')
        try:source_value(project,fee['project_pointer'])
        except (ValueError,KeyError,IndexError,TypeError):issues.append(fee['fee_id']+': 费用来源字段无效')
    if project.get('pricing') and not content['fee_value_mappings']:issues.append('有报价：补费用、工作、成果与覆盖期间的映射')
    edge_ids=set();connected=set()
    for edge in chain['connections']:
        if edge['id'] in edge_ids:issues.append('story map 连接 ID 重复')
        edge_ids.add(edge['id']);connected|={edge['from'],edge['to']}
        if edge['from'] not in units or edge['to'] not in units:issues.append(edge['id']+': story map 引用不存在的主张')
        if set(edge['evidence_refs'])-set(evid) or set(edge['assumption_refs'])-set(units):issues.append(edge['id']+': story map 依据或假设引用无效')
    if len(customer_units)>1 and set(customer_units)-connected:issues.append('story map 缺主张间的推导连接 '+','.join(sorted(set(customer_units)-connected)))
    if not chain['decision_unit_refs'] or set(chain['decision_unit_refs'])-set(units):issues.append('story map 未定位本次请求决定')
    rows=project.get('artifact_projection',[]);seen=set()
    for row in rows:
        key=(row['artifact_role'],row['section_or_page'])
        if key in seen:issues.append('客户产物投影定位重复 '+str(key))
        seen.add(key)
        if row['artifact_role'] not in project['outputs']:issues.append('投影指向未选交付物 '+row['artifact_role'])
        if set(row['source_refs'])-set(units):issues.append('投影引用不存在的论证单元 '+row['section_or_page'])
    projected={u for row in rows for u in row['source_refs']}
    missing={u['id'] for u in units.values() if u['required_for_decision']}-projected
    if missing:issues.append('主要论证尚未安排进入客户产物 '+','.join(sorted(missing)))
    for role in project['outputs']:
        if project.get('schema',0)>=7 and role in ['sow_docx','sow_pdf']:
            if not project.get('sow_sections'):issues.append(role+': 缺上游 SOW 工作约定章节')
            continue
        if not any(row['artifact_role']==role for row in rows):issues.append(role+': 缺客户文稿页面或章节安排')
    import presentation
    issues+=presentation.proof_issues(Path(work),content,'共同底稿')
    if written(project):
        import written_proposal
        issues+=written_proposal.plan_issues(work,project)
    return issues

def projection_rows(project,role):
    rows=[r for r in project.get('artifact_projection',[]) if r['artifact_role']==role]
    if not rows and role in ['proposal_docx','sow_docx']:
        pdf='proposal_pdf' if role=='proposal_docx' else 'sow_pdf';rows=[r for r in project['artifact_projection'] if r['artifact_role']==pdf]
    return rows

def materialized_plan(work,project,raw):
    """A derived view for the established renderer, never an authored second model."""
    if not active(project):return raw
    import client_content
    content=base(work);units={u['id']:u for u in content['semantic_units'] if client_content.client_unit(work,project,u)};view=client_content.customer_view(work,project,'presentation_plan',raw);view['_shared_units']=units;view['_workdir']=str(Path(work).resolve())
    view['visual_assets']=copy.deepcopy(project.get('visual_assets',[]))+[v for v in raw.get('visual_assets',[]) if v['asset_id'] not in {a['asset_id'] for a in project.get('visual_assets',[])}]
    view['claims']=[{'claim_id':u['id'],'text':resolve_text(project,u['claim']),'kind':'assumption' if u['kind']=='assumption' else 'source_fact' if u['kind']=='source_fact' else 'proposal','evidence_ids':u['evidence_refs'],'validation':u['validation']} for u in units.values()]
    for key in ['evidence_sources','scenarios','business_objects','mechanisms','values','fee_value_mappings']:view[key]=copy.deepcopy(content[key])
    if not view['values']:
        problem=next((u['claim'] for u in units.values() if 'F05' in u['field_refs']),'')
        view['values']=[{'value_id':u['id'],'beneficiary':project['audience'],'problem':problem,'mechanism_ids':u['mechanism_refs'],'expected_change':resolve_text(project,u['claim']),'basis_kind':'evidence' if u['evidence_refs'] else 'assumption','evidence_ids':u['evidence_refs'],'validation_plan':u['validation'] or '', 'decision_relevance':u['decision_relevance']} for u in units.values() if 'F14' in u['field_refs']]
    view['work_packages']=[{'work_package_id':v['id'],'description':v['title']} for v in project.get('work_packages',[])]
    view['deliverables']=[{'deliverable_id':v['id'],'work_package_id':v['work_package_id'],'name':v['name'],'acceptance':v['acceptance']} for v in project.get('deliverable_details',[])]
    view['applicability']={k:{'applicable':bool(content[key]),'reason':None if content[key] else 'Not part of the current requested decision'} for k,key in [('scenario','scenarios'),('mechanism','mechanisms'),('commercial','fee_value_mappings')]}
    for page in view['pages']:
        page['_model_version']=2
        if page.get('visual',{}).get('time_labels'):page['visual']['time_labels']={k:resolve_text(project,v) for k,v in page['visual']['time_labels'].items()}
        refs=page['source_refs'];source=[units[r] for r in refs if r in units]
        if not source:continue
        page['claim_ids']=refs
        projection=next((r for r in projection_rows(project,'pptx') or projection_rows(project,'ppt_pdf') if r['section_or_page']==page['page_id']),None)
        copy_page=page.setdefault('copy',{})
        if not copy_page.get('headline'):copy_page['headline']=resolve_text(project,projection.get('summary_and_conditions') if projection and projection.get('summary_and_conditions') else source[0]['claim'])
        copy_page['headline']=resolve_text(project,copy_page['headline'])
        # Conditions and validation that matter to the decision remain visible.
        body=list(copy_page.get('body',[]))
        for unit in source:
            for value in unit_texts(project,unit,work=work,role='pptx',location=page['page_id'])[1:]:
                if value not in body:body.append(value)
        if client_content.active(project):
            body+=client_content.located_disclosures(work,project,'pptx',page['page_id'])
            citations=client_content.citations(work,[r for u in source for r in u['evidence_refs']])
            copy_page['source_note']='; '.join(citations)
        copy_page['body']=[resolve_text(project,v) for v in body]
        if copy_page.get('table'):copy_page['table']={k:[[resolve_text(project,v) for v in row] for row in values] if k=='rows' else [resolve_text(project,v) for v in values] for k,values in copy_page['table'].items()}
    return view

def corpus(work,project,state):
    from proposal import inspect
    result={};audits={}
    manifest=resolve(work,project.get('render_manifest') or 'render-manifest.json')
    if has_ppt(project) and manifest.is_file():
        report=contracts.load(manifest)
        if any(p['mode']=='full_image' for p in report['pages']):
            import render_adapter
            if render_adapter.verify(work,project,manifest)['status']=='passed':audits={p['page_id']:p['literal_audit']['transcription'] for p in report['pages'] if p['mode']=='full_image'}
    for role in project['outputs']:
        item=state.get('files',{}).get(role)
        if item and Path(item['path']).is_file():
            result[role]=inspect(Path(item['path']),role)
            if role in ['pptx','ppt_pdf'] and audits:
                result[role]['audited_pages']=audits
                result[role]['text']+='\n'+'\n'.join(audits.values())
    for item in project.get('supplementary_artifacts',[]):
        file=resolve(work,item['source']['path'])
        if item['customer_selected'] and file.is_file() and sha(file)==item['source']['sha256']:
            role='proposal_md' if file.suffix=='.md' else 'proposal_docx' if file.suffix=='.docx' else 'supporting_pdf'
            result['supporting:'+item['id']]=inspect(file,role)
    return result

def actual_location(work,project,role,locator,info,state=None):
    """Use real slide/section content; do not let an internal plan satisfy delivery."""
    if role in ['pptx','ppt_pdf']:
        if locator in info.get('audited_pages',{}):return info['audited_pages'][locator]
        raw=contracts.load(resolve(work,project.get('presentation_plan') or 'presentation-plan.json'));ids=[p['page_id'] for p in raw['pages']]
        if locator not in ids:return ''
        index=ids.index(locator)
        if role=='ppt_pdf':
            from pypdf import PdfReader
            item=(state or {}).get('files',{}).get(role)
            return PdfReader(item['path']).pages[index].extract_text() or '' if item else info['text']
        if state:
            from pptx import Presentation
            item=state.get('files',{}).get(role)
            if item:
                slide=Presentation(item['path']).slides[index]
                return '\n'.join(s.text for s in slide.shapes if s.has_text_frame)+'\n'+'\n'.join(c.text for s in slide.shapes if s.has_table for row in s.table.rows for c in row.cells)
    if info.get('sections'):
        for heading,text in info['sections'].items():
            if re.match(r'^'+re.escape(locator)+r'(?:\s|$)',heading.strip()):return text
    text=info.get('text','');lines=text.splitlines();needle=normalize(locator)
    hits=[i for i,line in enumerate(lines) if normalize(line.lstrip('#').strip()).startswith(needle)]
    if not hits:return ''
    anchors=[r['section_or_page'] for r in project.get('artifact_projection',[]) if r['artifact_role']==role]
    start=hits[-1] if written(project) else hits[0];end=next((i for i in range(start+1,len(lines)) if any(normalize(lines[i].lstrip('#').strip()).startswith(normalize(a)) for a in anchors if a!=locator)),len(lines))
    result='\n'.join(lines[start:end])
    if written(project) and role=='proposal_pdf':
        meta=project.get('document_metadata') or {};header=meta.get('title') or '';version=(project.get('shared_facts') or {}).get('version')
        if version:header+=' | '+str(version)
        result='\n'.join(line for line in result.splitlines() if normalize(line)!=normalize(header) and not re.fullmatch(r'\s*\d{4}-\d{2}-\d{2}\s*\|\s*\d+\s*',line))
    return result

def projection_check(work,project,observed,state=None):
    content=base(work);units={u['id']:u for u in content['semantic_units']};covered=set();details=[];artifact_gaps={};issues=[]
    for row in project.get('artifact_projection',[]):
        role=row['artifact_role'];info=observed.get(role)
        actual=actual_location(work,project,role,row['section_or_page'],info,state) if info else ''
        for ident in row['source_refs']:
            if ident not in units:continue
            unit=units[ident]
            try:values=unit_texts(project,unit,projection_summary(row),work,role,row['section_or_page'])
            except ValueError as exc:issues.append(str(exc));continue
            missing=[v for v in values if normalize(v) not in normalize(actual)]
            if not missing:
                if not written(project) or role in ['proposal_docx','proposal_pdf'] or not {'proposal_docx','proposal_pdf'}&set(project['outputs']):covered.add(ident)
            else:artifact_gaps.setdefault(role,[]).append({'unit_id':ident,'location':row['section_or_page'],'missing':missing,'category':'artifact_summary_omission'})
            details.append({'artifact_role':role,'section_or_page':row['section_or_page'],'source_ref':ident,'present':not missing})
    # Explicitly selected supporting materials can provide part of the argument.
    for role,info in observed.items():
        if role.startswith('supporting:') and not written(project):
            covered|={u['id'] for u in units.values() if all(normalize(v) in normalize(info['text']) for v in unit_texts(project,u,work=work))}
    missing=[u['id'] for u in units.values() if u['required_for_decision'] and u['id'] not in covered]
    if missing:issues.append('生成遗漏：主要论证仅在内部底稿或未进入所选客户产物 '+','.join(missing))
    return {'status':'blocked' if issues else 'passed','issues':issues,'delivered_unit_ids':sorted(covered),'missing_unit_ids':missing,'artifact_gaps':artifact_gaps,'locations':details,'scope':'literal projection coverage; causal validity and evidence strength require the reviewer'}

def migrate(work,project,destination,producer):
    """Explicit new-directory migration; original records and ratings stay untouched."""
    destination=Path(destination).resolve()
    if destination.is_relative_to(Path(work).resolve()):raise ValueError('迁移目标应在原工作目录之外')
    if destination.exists():raise ValueError('迁移目标已存在；选择新目录')
    if project.get('schema',0)>=7:raise ValueError('当前任务已使用 SOW 优先制作链')
    shutil.copytree(work,destination,ignore=shutil.ignore_patterns('__pycache__'))
    legacy=destination/'legacy-records';legacy.mkdir()
    for name in ['project.json','state.json','content-base.json','story-map.json','document-plan.json','quality-review.json','checks.json','release.json','calibration.json','presentation-plan.json']:
        if (destination/name).is_file():shutil.copy2(destination/name,legacy/name)
    new=contracts.load(ROOT/'assets/project.json');new.update(project)
    explicit=[r for r in project.get('request_requirements',[]) if r.get('origin')=='user_instruction' and r.get('scope')=='outputs' and r.get('status')=='active']
    optional={v for r in explicit for v in r.get('affected_outputs',[])}&set(project['outputs'])
    new.update(schema=7,production_chain='production-chain.json',presentation_requested=bool(optional&{'pptx','ppt_pdf'}),sow_required=bool(optional&{'sow_docx','sow_pdf'}),outputs=['proposal_docx','proposal_pdf']+[v for v in project['outputs'] if v in optional and v not in ['proposal_docx','proposal_pdf']],task_scope='complete_proposal',document_plan='document-plan.json',quality_target='client_proposal',request_requirements_version=project.get('request_requirements_version',1),request_requirements=copy.deepcopy(project.get('request_requirements',[])),decision_context=copy.deepcopy(project.get('decision_context') or {'requested_action':project.get('decision'),'commitment_scope':None,'evidence_expectation':None,'source_requirement_refs':[]}),artifact_projection=[])
    prior_plan=contracts.load(work/'presentation-plan.json') if (work/'presentation-plan.json').is_file() else None
    content=contracts.load(ROOT/'assets/templates/01-content-base.json');chain=contracts.load(ROOT/'assets/templates/06-story-map.json')
    if (work/'content-base.json').is_file() and contracts.load(work/'content-base.json').get('schema')==2:content=contracts.load(work/'content-base.json')
    if (work/'story-map.json').is_file() and contracts.load(work/'story-map.json').get('schema')==2:chain=contracts.load(work/'story-map.json')
    if prior_plan:
        if prior_plan.get('schema')==1:
            for key in ['evidence_sources','scenarios','business_objects','mechanisms','values','fee_value_mappings']:content[key]=prior_plan.get(key,[])
        for claim in prior_plan.get('claims',[]):content['semantic_units'].append({'id':claim['claim_id'],'field_refs':['F08'],'claim':claim['text'],'kind':claim['kind'],'mechanism_refs':[],'evidence_refs':claim['evidence_ids'],'fact_refs':[],'assumptions':[],'conditions':[],'validation':claim['validation'],'decision_relevance':project.get('decision') or '待补','required_for_decision':True})
        newplan={key:prior_plan.get(key,[]) for key in ['references','visual_assets','pages']};newplan.update(schema=2,project_label=prior_plan.get('project_label'),reference_strategy=prior_plan.get('reference_strategy',{'status':'pending','reason':None}))
        for page in newplan['pages']:page['source_refs']=page.get('source_refs') or page.get('claim_ids',[])
        save(destination/'presentation-plan.json',newplan)
    if not new['presentation_requested']:new['presentation_plan']=None
    prior_document=resolve(work,project.get('document_plan') or 'document-plan.json')
    shutil.copy2(prior_document if written(project) and prior_document.is_file() else ROOT/'assets/document-plan.json',destination/'document-plan.json')
    shutil.copy2(ROOT/'assets/production-chain.json',destination/'production-chain.json')
    save(destination/'project.json',new);save(destination/'content-base.json',content);save(destination/'story-map.json',chain)
    # Old approvals remain available as original evidence, not silently reissued.
    state={'schema':2,'producer':producer,'created':datetime.now(timezone.utc).isoformat(),'files':{},'history':[]};save(destination/'state.json',state)
    for name in ['quality-review.json','checks.json','release.json','calibration.json','handoff.json','render-manifest.json','proposal-source-manifest.json']:
        if (destination/name).is_file(): (destination/name).unlink()
    if has_ppt(new):shutil.copy2(ROOT/'assets/calibration.json',destination/'calibration.json')
    difference={'from_schema':project['schema'],'to_schema':7,'legacy_records':str(legacy),'prior_outputs':project['outputs'],'current_outputs':new['outputs'],'mapped_unit_ids':[v['id'] for v in content['semantic_units']],'requires_completion':['upstream SOW and business-case-and-proposal application','effective user requirement registry and optional-output evidence','decision commitment scope','module applicability','story connections','written chapter plan and document metadata','artifact projections'],'prior_authorizations':'Original evidence retained. Reuse still-valid authorization at the existing confirmation node; no new user approval node. Old default optional outputs alone are not explicit requests.'}
    save(destination/'migration.json',difference);return difference

def visual_requirements(work,project,manifest=None):
    """Check registered intent against observed objects/assets, across chosen formats."""
    profile=contracts.load(resolve(work,project.get('visual_profile') or 'visual-profile.json'))
    raw=contracts.load(resolve(work,project.get('presentation_plan') or 'presentation-plan.json')) if has_ppt(project) else {'pages':[]}
    pages={p['page_id']:p for p in raw['pages']};issues=[];rows=project.get('requirement_realizations',[])
    active_ids={r['id'] for r in requirements(project)}
    for req in requirements(project):
        if req['scope'] in ['visual','method','editability'] and not any(v['requirement_id']==req['id'] for v in rows):issues.append(req['id']+': 指定视觉、方法或编辑要求缺产物对应安排')
    doc_bindings=(manifest or {}).get('runtime',{}).get('asset_bindings',[])
    for row in rows:
        if row['requirement_id'] not in active_ids:issues.append('视觉安排引用非有效要求 '+row['requirement_id'])
        if row['artifact_role'] not in project['outputs']:issues.append('视觉安排引用未选产物')
        if project.get('schema',0)>=7 and manifest and manifest['runtime'].get('production_stage')=='proposal' and row['artifact_role'] in ['pptx','ppt_pdf']:continue
        if manifest and manifest['status']=='partial':
            available=set(manifest['source_files'])|set(manifest['exports'])
            if row['artifact_role'] not in available:continue
            if row['artifact_role'] in ['pptx','ppt_pdf'] and row['section_or_page'] not in {p['page_id'] for p in manifest['pages']}:continue
        if row['artifact_role'] in ['pptx','ppt_pdf']:
            page=pages.get(row['section_or_page'])
            if not page:issues.append(row['requirement_id']+': 页面定位无效');continue
            if not manifest:continue
            actual=next((p for p in manifest['pages'] if p['page_id']==row['section_or_page']),None)
            if actual is None:issues.append(row['requirement_id']+': 缺实际页面');continue
            present=bool(any(o.get('icon_shape_ids') for o in actual['objects'])) if row['feature']=='icons' else any(a.get('feature','scene_assets')==row['feature'] for a in actual['assets']) if row['feature'] in ['scene_assets','output_examples'] else bool(page['reference_page_ids']) if row['feature']=='reference_method' else actual['native_text_editable'] and actual['native_relations_editable'] if row['feature']=='editability' else actual['mode']==row['method']
        else:
            if not any(r['artifact_role']==row['artifact_role'] and r['section_or_page']==row['section_or_page'] for r in project['artifact_projection']):issues.append(row['requirement_id']+': 文稿章节定位无效')
            if not manifest:continue
            source_role={'sow_pdf':'sow_docx','proposal_pdf':'proposal_docx'}.get(row['artifact_role'],row['artifact_role'])
            if row['feature'] in ['icons','scene_assets','output_examples']:
                present=any(b['artifact_role']==source_role and b['section_or_page']==row['section_or_page'] and b['feature']==row['feature'] for b in doc_bindings)
            elif row['feature']=='editability':present=source_role in manifest['source_files'] and (row['method']!='direct_editing' or not row['artifact_role'].endswith('_pdf'))
            else:
                # A named method is registered here; its visible effect is
                # assessed in the artifact review against the original request.
                present=bool(row['method']) and source_role in manifest['source_files']
        if row['expectation']=='required' and not present:issues.append(row['requirement_id']+': 要求的实际 '+row['feature']+' 未兑现')
        if row['expectation']=='off' and present:issues.append(row['requirement_id']+': 明确关闭的 '+row['feature']+' 仍被使用')
    if manifest and manifest['status']!='partial':
        for feature,mode in profile.get('feature_use',{}).items():
            present=any(any(o.get('icon_shape_ids') for o in p['objects']) for p in manifest['pages']) if feature=='icons' else any(any(a.get('feature','scene_assets')==feature for a in p['assets']) for p in manifest['pages'])
            present=present or any(b['feature']==feature for b in doc_bindings)
            if mode=='required' and not present:issues.append('任务视觉配置要求 '+feature+'，但无实际调用证据')
            if mode=='off' and present:issues.append('任务关闭 '+feature+'，但成品仍包含对应资源')
    for page in pages.values():
        if page.get('visual',{}).get('composition',page['visual_form'])=='timeline' and not page.get('visual',{}).get('time_labels'):issues.append(page['page_id']+': 时间构图需明确期点或阶段标签')
    return issues
