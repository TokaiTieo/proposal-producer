"""SOW-first production and immutable downstream handoffs; all data synthetic."""
import copy,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from docx import Document
import contracts,proposal as api,proposal_model as model,render_adapter as render,production_chain as chain
from written_fixtures import prepare_written

def prepare_chain(work,presentation=False,sow=False,kind='quote'):
    p,content,plan=prepare_written(work,kind,presentation,sow);p.update(schema=7,production_chain='production-chain.json')
    p['artifact_projection']=[r for r in p['artifact_projection'] if r['artifact_role'] not in ['sow_docx','sow_pdf']]
    for package in p['work_packages']:
        if package.get('sow_anchor') is None:package['sow_anchor']='S02'
    known={s['anchor']:s for s in p['sow_sections']}
    p['sow_sections']=[known.get(s['anchor'],s) for s in contracts.load(contracts.ROOT/'assets/project.json')['sow_sections']]
    for section in p['sow_sections']:
        if not section.get('paragraphs'):section['paragraphs']=['Synthetic scoped clause for '+section['anchor']+'; no business approval represented.']
    api.save(Path(work)/'production-chain.json',contracts.load(contracts.ROOT/'assets/production-chain.json'));api.save(Path(work)/'project.json',p);model.handoff(work,p);return p,content,plan

class ProductionChain(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.work=Path(self.temp.name);self.p,self.c,self.plan=prepare_chain(self.work)
        fonts={r:{'requested':'Arial','actual_family':'Arial','file':None,'available':True} for r in ['body','title']}
        self.fonts=patch.object(render,'font_map',return_value=(fonts,{}));self.fonts.start()
    def tearDown(self):self.fonts.stop();self.temp.cleanup()
    def sow(self):return chain.build_sow(self.work,self.p,self.work/'upstream-sow','SYNTHETIC-CHAIN-PRODUCER')
    def author(self):
        self.sow();chain.proposal_brief(self.work,self.p);return chain.record_proposal(self.work,self.p,'SYNTHETIC-METHOD-PRODUCER')
    def test_cannot_build_proposal_before_real_sow(self):
        with self.assertRaisesRegex(ValueError,'上游 SOW'):render.build(self.work,self.p,None,self.work/'bad')
        self.assertFalse((self.work/'bad').exists())
    def test_sow_is_real_editable_input_without_being_selected_for_delivery(self):
        result=self.sow();file=Path(result['file']['path']);self.assertTrue(file.is_file());self.assertFalse(result['customer_delivery_selected']);self.assertNotIn('sow_docx',self.p['outputs'])
        self.assertIn(self.p['scope'][0],'\n'.join(p.text for p in Document(file).paragraphs));self.assertEqual(chain.issues(self.work,self.p,'sow'),[])
    def test_sow_does_not_require_proposal_model_to_be_written_first(self):
        api.save(self.work/'content-base.json',contracts.load(contracts.ROOT/'assets/templates/01-content-base.json'))
        result=self.sow();self.assertEqual(result['stage'],'sow')
    def test_upstream_sow_respects_explicit_empty_fields_and_repeats_table_header(self):
        result=self.sow();document=Document(result['file']['path']);self.assertEqual(len(document.tables),1)
        table=document.tables[0];self.assertTrue(table.rows[0]._tr.xpath('./w:trPr/w:tblHeader'))
        self.assertTrue(all(row._tr.xpath('./w:trPr/w:cantSplit') for row in table.rows))
    def test_method_handoff_alone_does_not_count_as_authored_proposal(self):
        self.sow();brief=chain.proposal_brief(self.work,self.p)
        self.assertEqual(brief['method']['name'],'business-case-and-proposal');self.assertTrue(brief['sow_text']);self.assertTrue(any('proposal-record' in x for x in chain.issues(self.work,self.p)))
    def test_method_record_binds_actual_sow_method_and_authored_files(self):
        result=self.author();record=result['record'];self.assertEqual(set(record['authored_files']),set(chain.rules()['authored_files']));self.assertTrue(chain.valid(record['method']));self.assertEqual(chain.issues(self.work,self.p),[])
        api.save(self.work/'content-base.json',{**self.c,'notes':'synthetic changed prose'})
        self.assertTrue(any('content-base' in x for x in chain.issues(self.work,self.p)))
    def test_scope_or_price_change_invalidates_upstream_sow(self):
        self.author();self.p['scope'].append('Additional delivery commitment');self.assertTrue(any('SOW' in x and '变化' in x for x in chain.issues(self.work,self.p)))
    def test_downstream_authored_data_does_not_rewrite_the_sow(self):
        self.author();record=chain.read(self.work,self.p);before=record['sow']['file']['sha256'];self.c['semantic_units'][0]['claim']='An authored Proposal value argument';api.save(self.work/'content-base.json',self.c);self.assertEqual(api.filehash(record['sow']['file']['path']),before)
    def test_optional_ppt_cannot_run_before_actual_proposal_export(self):
        self.p,self.c,self.plan=prepare_chain(self.work,presentation=True);self.author()
        with self.assertRaisesRegex(ValueError,'导出 Proposal'):chain.presentation_brief(self.work,self.p)
        with self.assertRaisesRegex(ValueError,'presentation-record'):render.build(self.work,self.p,api.load(self.work/'presentation-plan.json'),self.work/'early-deck',stage='presentation')
    def test_opted_in_ppt_does_not_make_the_written_build_a_deck(self):
        self.p,self.c,self.plan=prepare_chain(self.work,presentation=True);self.author();result=render.build(self.work,self.p,None,self.work/'written-first')
        self.assertEqual(set(result['source_files']),{'proposal_docx'});self.assertEqual(result['pages'],[]);self.assertEqual(result['runtime']['production_stage'],'proposal')
    def test_sow_delivery_uses_upstream_sections_not_proposal_argument_projections(self):
        self.p,self.c,self.plan=prepare_chain(self.work,sow=True);self.author()
        self.assertEqual(model.model_issues(self.work,self.p),[])
        result=render.build(self.work,self.p,None,self.work/'written-with-sow')
        self.assertTrue(Path(result['source_files']['sow_docx']['path']).is_file())
        text='\n'.join(p.text for p in Document(result['source_files']['sow_docx']['path']).paragraphs)
        self.assertNotIn(next(u['claim'] for u in self.c['semantic_units'] if u['id']=='U5'),text)
    def test_method_uses_internal_module_without_reading_host_skill_libraries(self):
        with patch.object(chain.Path,'home',side_effect=AssertionError('The method must not probe a host skill library')):
            source=chain.method()
        self.assertTrue(source['path'].startswith(str(contracts.ROOT)));self.assertEqual(source['sha256'],chain.rules()['method']['sha256'])
    def test_corrupt_internal_method_cannot_fall_back_to_an_external_install(self):
        internal=(contracts.ROOT/chain.rules()['method']['bundled_path']).resolve();read_bytes=Path.read_bytes
        def changed(path):return b'Changed internal method' if path.resolve()==internal else read_bytes(path)
        with patch.object(Path,'read_bytes',changed),patch.object(chain.Path,'home',side_effect=AssertionError('No host lookup is permitted')):
            with self.assertRaisesRegex(ValueError,'缺失或变化'):chain.method()
    def test_internal_source_chain_preserves_earlier_records(self):
        self.sow();first=copy.deepcopy(chain.read(self.work,self.p));chain.proposal_brief(self.work,self.p)
        self.assertTrue(any(api.load(f)['sow']==first['sow'] for f in (self.work/'chain-history').glob('*.json')))
        contracts.validate(api.load(self.work/'production-chain.json'),'production-chain-record.schema.json')
        contracts.validate(api.load(self.work/'state.json'),'state.schema.json')
    def test_cli_stage_history_survives_the_next_command(self):
        font={r:{'requested':'Arial','actual_family':'Arial','file':None,'available':True} for r in ['body','title']}
        script='from unittest.mock import patch\nimport proposal,render_adapter\nwith patch.object(render_adapter,"font_map",return_value=('+repr(font)+',{})):\n proposal.main()\n'
        env={**os.environ,'PYTHONPATH':str(contracts.ROOT/'scripts')+os.pathsep+os.environ.get('PYTHONPATH','')}
        for command,extra in [('sow-build',['--destination',str(self.work/'cli-sow')]),('proposal-brief',[]),('proposal-record',[]),('chain-check',[])]:
            result=subprocess.run([sys.executable,'-c',script,command,'--workdir',str(self.work),'--producer','SYNTHETIC-CLI-PRODUCER',*extra],capture_output=True,text=True,env=env)
            self.assertEqual(result.returncode,0,command+': '+result.stderr[:2000]+result.stdout[:300])
            contracts.validate(api.load(self.work/'state.json'),'state.schema.json')
    def test_schema_rejects_an_unbound_pipeline_record(self):
        record=contracts.load(contracts.ROOT/'assets/production-chain.json');record['sow']={'file':{'path':'fake'}}
        with self.assertRaises(ValueError):contracts.validate(record,'production-chain-record.schema.json')
    def test_business_digest_allows_ppt_selection_without_rewriting_the_proposal(self):
        old=chain.business_digest(self.p);self.p['presentation_requested']=True;self.p['outputs']+=['pptx','ppt_pdf'];self.assertEqual(old,chain.business_digest(self.p))
    def test_written_v6_migrates_to_sow_first_without_overwriting_the_original(self):
        old=copy.deepcopy(self.p);old['schema']=6;api.save(self.work/'project.json',old);original=(self.work/'project.json').read_bytes()
        with tempfile.TemporaryDirectory() as other:
            destination=Path(other)/'migrated';result=model.migrate(self.work,old,destination,'SYNTHETIC-MIGRATION-PRODUCER')
            self.assertEqual(result['to_schema'],7);self.assertEqual(api.load(destination/'document-plan.json'),self.plan)
            self.assertIsNone(api.load(destination/'production-chain.json')['sow'])
            self.assertEqual(api.load(destination/'legacy-records/project.json')['schema'],6)
        self.assertEqual((self.work/'project.json').read_bytes(),original)

if __name__=='__main__':unittest.main(verbosity=2)
