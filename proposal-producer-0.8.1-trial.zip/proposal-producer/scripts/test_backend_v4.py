"""Synthetic v4 backend regressions, including actual-file error mutations.

The files below are small independent fixtures, not client deliverables, real
approvals, visual reviews, or proof of an office application's PDF export.
"""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import contracts
import facts
import proposal as api

ROOT = Path(__file__).resolve().parents[1]


def fixed_project():
    value = contracts.load(ROOT / 'assets/project.json')
    value.update(outputs=['pptx','sow_docx','ppt_pdf','sow_pdf'],mapping_required_roles=['pptx','sow_docx','ppt_pdf','sow_pdf'], schema=4, audience='SYNTHETIC TEST', decision='SYNTHETIC TEST',
                 outline=['SYNTHETIC TEST'], scope=['SYNTHETIC TEST'],
                 shared_facts={'date': '2026-10-26', 'version': 'v4-fixture', 'period_months': 24},
                 requirements=[{'id': 'R01', 'priority': 'P0', 'work_package_ids': ['W01']}],
                 work_packages=[{'id': 'W01', 'title': 'Fixture package', 'sow_anchor': 'S01'}],
                 sow_sections=[{'anchor': 'S01', 'title': 'Fixture scope'}],
                 pricing={'mode': 'fixed_inclusive_total', 'currency': 'USD',
                          'inclusive_total': '345600', 'period_months': 24,
                          'tax_rate': None, 'tax_included': True,
                          'items': [], 'payment_percentages': []})
    return value


class FixedTotal(unittest.TestCase):
    def test_unknown_tax_remains_unknown_and_no_annual_allocation(self):
        project = fixed_project()
        contracts.validate(project, 'project.schema.json')
        result = api.calculate(project)
        self.assertEqual(result['issues'], [])
        amount = result['pricing']
        self.assertEqual(amount['total'], '345600.00')
        self.assertEqual(amount['period_months'], 24)
        self.assertIsNone(amount['tax_rate'])
        self.assertIsNone(amount['tax'])
        self.assertIsNone(amount['subtotal_ex_tax'])
        self.assertEqual(amount['payment_amounts'], [])
        self.assertFalse(any('annual' in key or 'year' in key for key in amount))

    def test_amount_triggers_calculation_in_every_proposal_type(self):
        for kind in contracts.policy()['types']:
            project = fixed_project(); project['kind'] = kind
            with self.subTest(kind=kind):
                self.assertEqual(api.calculate(project)['pricing']['total'], '345600.00')
                project['pricing']['inclusive_total'] = '{{UNKNOWN}}'
                self.assertTrue(api.calculate(project)['issues'])

    def test_zero_tax_is_not_a_substitute_for_unknown_tax(self):
        for value in [0, '0', '.06']:
            project = fixed_project(); project['pricing']['tax_rate'] = value
            with self.subTest(value=value):
                with self.assertRaises(ValueError): contracts.validate(project, 'project.schema.json')
                self.assertTrue(api.calculate(project)['issues'])

    def test_invalid_total_period_and_tax_flag_are_rejected(self):
        for update in [{'inclusive_total': -1}, {'period_months': 0}, {'period_months': 2.5},
                       {'tax_included': False}, {'inclusive_total': True},
                       {'inclusive_total': 'Infinity'}]:
            project = fixed_project(); project['pricing'].update(update)
            with self.subTest(update=update): self.assertTrue(api.calculate(project)['issues'])

    def test_explicit_payments_reconcile_without_inventing_a_schedule(self):
        project = fixed_project(); project['pricing']['payment_percentages'] = ['33.33', '33.33', '33.34']
        amount = api.calculate(project)['pricing']
        self.assertEqual(sum(api.D(value) for value in amount['payment_amounts']), api.D('345600'))
        project['pricing']['payment_percentages'] = [20, 20]
        self.assertTrue(api.calculate(project)['issues'])

    def test_fixed_total_does_not_reinterpret_line_items(self):
        project = fixed_project(); project['pricing']['items'] = [{'id': 'Q1', 'selected': True, 'quantity': 1, 'unit_price': 42}]
        with self.assertRaises(ValueError): contracts.validate(project, 'project.schema.json')
        self.assertTrue(api.calculate(project)['issues'])

    def test_legacy_line_items_and_explicit_line_items_have_same_result(self):
        project = contracts.load(ROOT / 'evals/fixtures/legacy-project-quote.json')
        original = api.calculate(project)
        project['pricing']['mode'] = 'line_items'
        contracts.validate(project, 'project.schema.json')
        self.assertEqual(api.calculate(project), original)
        self.assertEqual(original['pricing']['total'], '7420.00')

    def test_null_tax_is_invalid_for_line_items(self):
        project = contracts.load(ROOT / 'evals/fixtures/legacy-project-quote.json')
        project['pricing']['tax_rate'] = None
        with self.assertRaises(ValueError): contracts.validate(project, 'project.schema.json')
        self.assertTrue(api.calculate(project)['issues'])

    def test_unknown_mode_does_not_silently_use_line_items(self):
        project = fixed_project(); project['pricing']['mode'] = 'guessed'
        self.assertTrue(api.calculate(project)['issues'])


class DeclaredInputs(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.work = Path(self.tmp.name)
        self.cli('init', '--producer', 'SYNTHETIC-PRODUCER', '--kind', 'product')

    def tearDown(self): self.tmp.cleanup()

    def cli(self, command, *args, code=0):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/proposal.py'), command,
                                 '--workdir', str(self.work), *args], capture_output=True, text=True)
        self.assertEqual(result.returncode, code, result.stdout + result.stderr)
        return json.loads(result.stdout or result.stderr)

    def test_unregistered_empty_broken_and_template_looking_json_are_ignored(self):
        project, state = api.context(self.work)
        before = api.candidate(self.work, project, state)
        for name, text in [('empty.json', ''), ('log.json', '{invalid'),
                           ('stray-template.json', '{"template":"fake"}'), ('ordinary.log', 'plain log')]:
            (self.work / name).write_text(text)
        self.cli('status'); self.cli('calculate')
        self.assertEqual(api.candidate(self.work, project, state), before)

    def test_stdout_redirected_to_json_in_workdir_is_safe(self):
        path = self.work / 'run-output.json'
        with path.open('w') as stream:
            result = subprocess.run([sys.executable, str(ROOT / 'scripts/proposal.py'), 'status',
                                     '--workdir', str(self.work)], stdout=stream, stderr=subprocess.PIPE, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('producer', json.loads(path.read_text()))
        self.cli('status')

    def test_damaged_registered_default_names_the_actual_file(self):
        path = self.work / 'content-base.json'; path.write_text('')
        result = self.cli('status', code=2)
        self.assertIn(str(path), result['error'])
        self.assertIn('line 1 column 1', result['error'])

    def test_explicit_extra_data_mapping_is_validated_and_bound(self):
        path = self.work / 'extra.json'
        api.save(path, contracts.load(ROOT / 'evals/fixtures/legacy-06-story-map.json'))
        project = api.load(self.work / 'project.json')
        project['data_files'] = {'extra.json': 'templates/06-story-map.schema.json'}
        api.save(self.work / 'project.json', project)
        project, state = api.context(self.work); before = api.candidate(self.work, project, state)
        data = api.load(path); data['sections'][0]['blocks'][0]['text'] = 'SYNTHETIC CHANGED INPUT'
        api.save(path, data)
        self.assertNotEqual(api.candidate(self.work, project, state), before)
        path.write_text('{"broken":')
        self.assertIn(str(path), self.cli('status', code=2)['error'])

    def test_missing_explicit_data_file_is_an_error(self):
        project = api.load(self.work / 'project.json')
        project['data_files'] = {'missing.json': 'templates/06-story-map.schema.json'}
        api.save(self.work / 'project.json', project)
        self.assertIn('missing.json', self.cli('status', code=2)['error'])

    def test_default_schema_cannot_be_replaced(self):
        project = api.load(self.work / 'project.json')
        project['data_files'] = {'content-base.json': 'templates/06-story-map.schema.json'}
        with self.assertRaisesRegex(ValueError, '不得替换'): contracts.registered_data(self.work, project)

    def test_missing_optional_visual_files_do_not_require_a_schema_yet(self):
        project = api.load(self.work / 'project.json')
        # Default visual data paths are declared optional in the contract.
        self.assertTrue(all(not item['required'] for item in contracts.fact_policy()['default_data_files'] if item['path'].startswith('render-')))
        contracts.registered_data(self.work, project)

    def test_shared_facts_and_mappings_are_bound_to_content_confirmation(self):
        project = fixed_project(); original = api.critical(project)
        for key in ['shared_facts', 'requirements', 'work_packages', 'sow_sections']:
            value = copy.deepcopy(project); value[key] = []
            with self.subTest(key=key): self.assertNotEqual(api.critical(value), original)


class ActualArtifactMutations(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.work = Path(self.tmp.name)
        self.project = fixed_project(); self.calculation = api.calculate(self.project)
        expected = facts.expected(self.project, self.calculation)
        self.lines = [item['text'] for group in expected.values() for item in group]
        self.paths = {role: self.work / (role + contracts.policy()['outputs'][role]['suffix']) for role in self.project['outputs']}
        for role in self.paths: self.write(role)

    def tearDown(self): self.tmp.cleanup()

    def write(self, role, replace=None, heading=True):
        lines = [line.replace(*(replace or ('\0', '\0'))) for line in self.lines]
        if role == 'pptx':
            from pptx import Presentation
            from pptx.util import Inches
            deck = Presentation(); slide = deck.slides.add_slide(deck.slide_layouts[6])
            box = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(8), Inches(5))
            box.text_frame.text = '\n'.join(line for line in lines if '|' not in line)
            table = slide.shapes.add_table(1, 4, Inches(1), Inches(6), Inches(8), Inches(.5)).table
            for cell, text in zip(table.rows[0].cells, next(line for line in lines if '|' in line).split('|')): cell.text = text.strip()
            deck.save(self.paths[role])
        elif role == 'sow_docx':
            from docx import Document
            document = Document()
            for line in lines:
                if '|' in line:
                    row = document.add_table(rows=1, cols=4).rows[0]
                    for cell, text in zip(row.cells, line.split('|')): cell.text = text.strip()
                elif line.startswith('S01 ') and heading: document.add_heading(line, level=1)
                else: document.add_paragraph(line)
            document.save(self.paths[role])
        else:
            from reportlab.pdfgen import canvas
            pdf = canvas.Canvas(str(self.paths[role])); text = pdf.beginText(40, 780)
            for line in lines: text.textLine(line)
            pdf.drawText(text); pdf.showPage(); pdf.save()

    def observed(self): return {role: api.inspect(path, role) for role, path in self.paths.items()}
    def result(self): return facts.check(self.project, self.observed(), self.calculation)

    def test_real_pptx_docx_and_both_pdf_fixtures_match(self):
        result = self.result()
        self.assertEqual(result['issues'], [])
        self.assertEqual(result['fact_comparisons'], 16)
        self.assertEqual(result['mapping_comparisons'], 4)
        self.assertEqual(result['section_comparisons'], 2)

    def test_date_version_period_and_amount_mutations_block_every_role(self):
        for role in self.paths:
            for before, after, fact_id in [('2026-10-26', '2026-10-27', 'date'),
                                            ('v4-fixture', 'v3-fixture', 'version'),
                                            ('24 months', '12 months', 'period_months'),
                                            ('345,600', '4,900,000', 'inclusive_total')]:
                with self.subTest(role=role, fact=fact_id):
                    self.write(role, (before, after))
                    self.assertTrue(any(role in issue and fact_id in issue for issue in self.result()['issues']))
                    self.write(role)

    def test_priority_work_package_and_section_mapping_mutations_block(self):
        for role in self.paths:
            for before, after in [('P0', 'P2'), ('W01', 'W99'), ('S01', 'S99')]:
                with self.subTest(role=role, change=after):
                    self.write(role, (before, after))
                    self.assertTrue(any(role in issue and '映射' in issue for issue in self.result()['issues']))
                    self.write(role)

    def test_sow_anchor_in_body_is_not_an_actual_heading(self):
        self.write('sow_docx', heading=False)
        self.assertTrue(any('sow_docx' in issue and '稳定章节' in issue for issue in self.result()['issues']))

    def test_missing_pdf_section_heading_blocks(self):
        self.write('sow_pdf', ('S01 Fixture scope', 'S99 Wrong section'))
        self.assertTrue(any('sow_pdf' in issue and '稳定章节' in issue for issue in self.result()['issues']))

    def test_scattered_ids_do_not_count_as_a_mapping_row(self):
        observed = self.observed()
        observed['pptx']['blocks'] = [line for line in observed['pptx']['blocks'] if '|' not in line]
        observed['pptx']['blocks'] += ['R01', 'P0', 'W01', 'S01']
        result = facts.check(self.project, observed, self.calculation)
        self.assertTrue(any('pptx' in issue and '映射' in issue for issue in result['issues']))

    def test_valid_and_conflicting_duplicate_facts_are_not_accepted(self):
        observed = self.observed(); observed['pptx']['blocks'].append('Period: 12 months')
        self.assertTrue(any('冲突' in issue for issue in facts.check(self.project, observed, self.calculation)['issues']))

    def test_source_period_and_reference_mutations_are_reported(self):
        for key in ['period', 'package', 'section', 'duplicate']:
            project = copy.deepcopy(self.project)
            if key == 'period': project['shared_facts']['period_months'] = 12
            elif key == 'package': project['requirements'][0]['work_package_ids'] = ['W99']
            elif key == 'section': project['work_packages'][0]['sow_anchor'] = 'S99'
            else: project['requirements'].append(copy.deepcopy(project['requirements'][0]))
            with self.subTest(key=key): self.assertTrue(facts.project_issues(project))

    def test_backend_check_uses_actual_artifacts_and_reports_separate_scope(self):
        state = {'producer': 'SYNTHETIC-PRODUCER', 'files': {role: {'path': str(path), 'sha256': api.filehash(path)} for role, path in self.paths.items()}}
        # Quality/approval checks remain independent; this test only isolates
        # the backend's integration with actual-file extraction.
        with patch.object(api, 'candidate', return_value='SYNTHETIC'), \
             patch.object(api.presentation, 'quality_summary', return_value={'business_argument': 'pending', 'presentation_quality': 'pending'}), \
             patch.object(api.gates, 'technical_conclusion', return_value='blocked'):
            result = api.check(self.work, self.project, state)
        self.assertEqual(result['shared_fact_check']['status'], 'passed')
        self.assertEqual(result['mechanical_checks'], 'blocked')
        self.assertIn('no business truth', result['shared_fact_check']['scope'])


if __name__ == '__main__': unittest.main(verbosity=2)
