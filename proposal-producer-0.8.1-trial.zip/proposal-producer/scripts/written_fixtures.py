"""Generic synthetic written proposals. Never author default/customer facts."""
from pathlib import Path
import copy
import contracts,proposal as api,proposal_model as model,written_proposal as written
from model_fixtures import prepare

def prepare_written(work,kind='quote',presentation=False,sow=False):
    work=Path(work);roles=['proposal_docx','proposal_pdf']+(['pptx','ppt_pdf'] if presentation else [])+(['sow_docx'] if sow else [])
    p,content=prepare(work,kind,roles);p.update(schema=6,presentation_requested=presentation,sow_required=sow,document_plan='document-plan.json',document_metadata={'title':'Workflow Pilot Proposal','author':'Synthetic Proposal Team','date':'2026-10-27','subject':'Synthetic branch regression'},quality_target='client_proposal',sow_sections=p['sow_sections'] if sow else [])
    if not sow:
        for package in p['work_packages']:package['sow_anchor']=None
    if presentation or sow:
        req=copy.deepcopy(p['request_requirements'][0]);req.update(id='RQ-OUTPUTS',scope='outputs',requirement='Select the declared written Proposal and explicitly requested optional deliverables');p['request_requirements'].append(req)
    profile=api.load(work/'visual-profile.json');profile['language']='en';profile['fonts']={'title':'Arial','body':'Arial'};api.save(work/'visual-profile.json',profile)
    mapping={'01':['U1'],'02':['U2'],'03':['U1'],'04':['U3'],'05':['U3'],'06':['U7'],'07':['U4'],'08':['U5'],'09':['U4'],'10':['U6' if kind=='quote' else 'U4'],'11':['U7'],'12':['U8']}
    plan=contracts.load(contracts.ROOT/'assets/document-plan.json')
    for chapter,base in zip(plan['chapters'],written.rules()['chapter_baseline']):
        ident=chapter['section_id'];chapter.update(title=written.rules()['chapter_title_overrides'].get(kind,{}).get(ident,{}).get('en',base['generic_title_en']),purpose='Supports the bounded pilot decision through this part of the shared argument.',source_refs=mapping[ident])
    plan['chapters'][8]['blocks']=[{'kind':'heading','level':2,'text':'Acceptance review'},{'kind':'heading','level':3,'text':'Record sample and owner check'},{'kind':'table','caption':'Pilot deliverables and review','columns':['Deliverable','Owner review'],'rows':[['Traceable pilot records','Check inputs and outcomes after the pilot']],'source_refs':['U4']}]
    if kind=='quote':
        unit=next(u for u in content['semantic_units'] if u['id']=='U6');unit['claim']='The selected package total is {{fact:/pricing/inclusive_total}} CNY for {{fact:/shared_facts/period_months}} months.';unit['fact_refs'].append('/shared_facts/period_months')
    p['artifact_projection']=[r for r in p['artifact_projection'] if r['artifact_role'] not in ['proposal_docx','proposal_pdf']]
    for role in ['proposal_docx','proposal_pdf']:
        p['artifact_projection'] += [{'artifact_role':role,'section_or_page':c['section_id'],'source_refs':c['source_refs'][:],'summary_and_conditions':None} for c in plan['chapters']]
    for name,value in [('project.json',p),('document-plan.json',plan),('content-base.json',content)]:api.save(work/name,value)
    if presentation:
        from model_fixtures import slide_inputs
        slide_inputs(work,p)
    model.handoff(work,p);return p,content,plan
