"""Synthetic behavior tests; identities/evidence below are fixtures, not real approvals."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import contracts
import gates
import proposal as api

ROOT=Path(__file__).resolve().parents[1]

class ContractValidation(unittest.TestCase):
    def test_json_evaluation_cases(self):
        cases=contracts.validate(contracts.load(ROOT/'evals/contracts.json'),'evals.schema.json')['cases']
        for case in cases:
            with self.subTest(case=case['id']):
                value={**contracts.load(ROOT/'assets/project.json'),**case['updates']}
                if case['expected']=='valid': contracts.validate(value,'project.schema.json')
                else:
                    with self.assertRaises(ValueError): contracts.validate(value,'project.schema.json')
    def test_schemas_catalog_and_templates(self):
        self.assertGreater(len(contracts.validate_all()['validated_files']),10)
    def test_bad_enum_unknown_field_and_missing_field(self):
        base=contracts.load(ROOT/'assets/project.json')
        for change in [{'kind':'roadshow'},{'unexpected':1}]:
            value={**base,**change}
            with self.assertRaises(ValueError): contracts.validate(value,'project.schema.json')
        del base['delivery']
        with self.assertRaises(ValueError): contracts.validate(base,'project.schema.json')
    def test_pdf_requires_source(self):
        value=contracts.load(ROOT/'assets/project.json'); value['outputs']=['ppt_pdf']
        with self.assertRaises(ValueError): contracts.validate(value,'project.schema.json')
    def test_table_field_typo_fails(self):
        value=contracts.load(ROOT/'assets/templates/02-missing-items.json')
        table=next(b for s in value['sections'] for b in s['blocks'] if b['kind']=='table')
        table['rows'][0]['typo']='incorrect field'
        with self.assertRaises(ValueError): contracts.validate(value,'templates/02-missing-items.schema.json')
    def test_nonfinite_and_duplicate_json_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'bad.json'
            for text in ['{"value":NaN}','{"value":1,"value":2}']:
                path.write_text(text)
                with self.assertRaises(ValueError): contracts.load(path)
    def test_contract_value_changes_calculation(self):
        policy=copy.deepcopy(contracts.policy()); policy['calculation']['money_quantum']='0.1'
        with patch.object(contracts,'policy',return_value=policy): self.assertEqual(api.money(api.D('1.24')),'1.2')
    def test_example_matches_project_schema_and_recalculates(self):
        value=contracts.load(ROOT/'evals/fixtures/legacy-project-quote.json')
        contracts.validate(value,'project.schema.json')
        result=api.calculate(value)
        self.assertEqual(result['pricing']['total'],'7420.00')
        self.assertIsNone(result['returns']['cash_payback'])

class ReleaseBoundary(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.work=Path(self.tmp.name)
        self.cli('init','--producer','FIXTURE-PRODUCER','--kind','product')
        project=api.load(self.work/'project.json')
        project.update(audience='Fixture audience',decision='Fixture decision',scope=['Fixture scope'],outline=['Fixture outline'],outputs=['pptx'],delivery={'recipients':['FIXTURE-USER'],'channel':'local','authorization_evidence':'SYNTHETIC TEST ONLY'})
        api.save(self.work/'project.json',project)
        from presentation_fixtures import prepare_inputs
        prepare_inputs(self.work,api);self.cli('production-check')
        from pptx import Presentation
        deck=Presentation(); slide=deck.slides.add_slide(deck.slide_layouts[0]); slide.shapes.title.text='Synthetic fixture'
        self.ppt=self.work/'fixture.pptx'; deck.save(self.ppt)
        self.cli('packet'); self.cli('approve','--actor','FIXTURE-USER','--evidence','SYNTHETIC TEST ONLY')
        self.cli('register','--role','pptx','--file',str(self.ppt))
        report=self.work/'review.txt'; report.write_text('Synthetic test evidence, not a real independent review')
        self.cli('review','--reviewer','FIXTURE-REVIEWER','--report',str(report),'--result','pass')
        self.evidence=self.work/'evidence.txt'; self.evidence.write_text('Synthetic observations')
        checks=self.cli('checks-init')
        rules=contracts.policy(); project=api.load(self.work/'project.json')
        for item in checks['items']:
            item.update(status='pass',location='Fixture p1',reviewer='FIXTURE-REVIEWER',evidence=[{'path':str(self.evidence),'sha256':api.filehash(self.evidence)}])
            item['measurements']={metric:contracts.visual_limits(project)[metric] for metric in contracts.measurement_rules(project).get(item['id'],{})}
        api.save(self.work/'checks.json',checks)
        from presentation_fixtures import fill_quality
        fill_quality(self.work,api,'FIXTURE-REVIEWER')
    def tearDown(self): self.tmp.cleanup()
    def cli(self, command,*args,code=0):
        result=subprocess.run([sys.executable,str(ROOT/'scripts/proposal.py'),command,'--workdir',str(self.work),*args],text=True,capture_output=True)
        self.assertEqual(result.returncode,code,result.stdout+result.stderr)
        return json.loads(result.stdout or result.stderr)
    def modify(self,ident,**updates):
        data=api.load(self.work/'checks.json'); next(item for item in data['items'] if item['id']==ident).update(updates); api.save(self.work/'checks.json',data)
    def hook(self,event=None):
        result=subprocess.run([sys.executable,str(ROOT/'hooks/claude_stop.py'),'--workdir',str(self.work)],input=json.dumps(event or {'hook_event_name':'Stop'}),capture_output=True,text=True)
        return result
    def test_successful_release_and_hook(self):
        receipt=self.cli('release'); self.assertTrue((self.work/'release.json').is_file())
        self.assertEqual(receipt['files']['pptx']['sha256'],api.filehash(self.ppt))
        self.assertEqual(json.loads(self.hook().stdout),{})
    def test_pending_check_blocks_output(self):
        self.modify('K05',status='pending'); self.cli('release',code=2)
        self.assertFalse((self.work/'release.json').exists())
    def test_nonwaivable_na_blocks(self):
        self.modify('K03',status='not_applicable',reason='Fixture shortcut')
        self.assertTrue(any('K03' in v for v in self.cli('release',code=2)['issues']))
    def test_incomplete_check_coverage_blocks(self):
        data=api.load(self.work/'checks.json'); data['items']=[v for v in data['items'] if v['id']!='PR04']; api.save(self.work/'checks.json',data)
        self.assertTrue(any('PR04' in v for v in self.cli('release',code=2)['issues']))
    def test_self_review_in_checks_blocks(self):
        self.modify('K05',reviewer='FIXTURE-PRODUCER'); self.cli('release',code=2)
    def test_evidence_tampering_blocks(self):
        self.evidence.write_text('CHANGED FIXTURE'); self.cli('release',code=2)
    def test_visual_threshold_is_enforced(self):
        self.modify('V01',measurements={'body_min_pt':17,'title_min_pt':28,'source_min_pt':10})
        self.assertTrue(any('body_min_pt' in v for v in self.cli('release',code=2)['issues']))
    def test_policy_threshold_change_changes_gate(self):
        p,s=api.context(self.work); fp=api.candidate(self.work,p,s)
        policy=copy.deepcopy(contracts.policy()); policy['optional_presentation']['visual']['body_min_pt']=22
        with patch.object(contracts,'policy',return_value=policy):
            issues=gates.evidence_issues(self.work,p,s,fp,api.filehash)
        self.assertTrue(any('body_min_pt' in v for v in issues))
    def test_bad_hook_event_fails_closed(self):
        self.assertEqual(self.hook({'hook_event_name':'WrongEvent'}).returncode,2)
    def test_draft_may_stop_without_release(self): self.assertEqual(json.loads(self.hook().stdout),{})
    def test_stale_release_is_blocked_by_hook(self):
        self.cli('release'); self.ppt.write_bytes(self.ppt.read_bytes()+b'CHANGED FIXTURE')
        response=self.hook(); self.assertEqual(response.returncode,0,response.stderr)
        self.assertEqual(json.loads(response.stdout)['decision'],'block')
    def test_existing_destination_is_preserved(self):
        target=self.work/'existing'; target.mkdir(); marker=target/'local.txt'; marker.write_text('KEEP')
        self.cli('release','--destination',str(target),code=2)
        self.assertEqual(marker.read_text(),'KEEP')
    def test_release_copy_matches_registered_source(self):
        destination=self.work/'selected-delivery'
        receipt=self.cli('release','--destination',str(destination))
        self.assertEqual(api.filehash(Path(receipt['files']['pptx']['path'])),api.filehash(self.ppt))
    def test_external_sow_cannot_waive_legal(self):
        p,s=api.context(self.work); p['outputs'].append('sow_docx'); p['draft_mode']=False
        data=api.load(self.work/'checks.json')
        for i in range(1,14): data['items'].append({'id':f'S{i:02}','status':'not_applicable','location':'Fixture','reviewer':'FIXTURE-REVIEWER','reason':'Fixture no legal','evidence':[{'path':str(self.evidence),'sha256':api.filehash(self.evidence)}]})
        api.save(self.work/'checks.json',data)
        issues=gates.evidence_issues(self.work,p,s,data['candidate_digest'],api.filehash)
        self.assertTrue(any('S13: 对客' in v for v in issues))

if __name__=='__main__': unittest.main(verbosity=2)
