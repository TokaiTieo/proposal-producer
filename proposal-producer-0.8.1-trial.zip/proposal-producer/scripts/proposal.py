#!/usr/bin/env python3
"""Local proposal trial helpers. Financial arithmetic and mechanical evidence only."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile
import contracts
import gates
import presentation
import facts
import render_adapter
import proposal_model as model

HERE = Path(__file__).resolve().parents[1]
ROLES = set(contracts.policy()['outputs'])
CRITICAL = tuple(contracts.policy()['workflow']['critical_fields'] + contracts.fact_policy()['critical_fields'])
D = Decimal

def now(): return datetime.now(timezone.utc).isoformat()
def canonical(x): return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def digest(x): return hashlib.sha256(canonical(x)).hexdigest()
def filehash(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return contracts.load(p)
def save(p, x):
    p = Path(p); temp = p.with_suffix(p.suffix + '.tmp')
    temp.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n', encoding='utf-8'); temp.replace(p)
def money(x): return str(x.quantize(D(contracts.policy()['calculation']['money_quantum']), rounding=ROUND_HALF_UP))
def number(x, name):
    if isinstance(x, bool) or x is None or isinstance(x, (dict, list)):
        raise ValueError(name + ': 需要明确数值')
    try: value = D(str(x))
    except InvalidOperation: raise ValueError(name + ': 数值待补或无效')
    if not value.is_finite(): raise ValueError(name + ': 需要有限数值')
    return value

def fixed_inclusive_total(q):
    """A declared package amount is not an estimate of tax or annual costs."""
    if not q.get('currency'):raise ValueError('currency: 币种待补')
    if q.get('tax_included') is not True:raise ValueError('fixed_inclusive_total: tax_included 必须为 true')
    if 'tax_rate' not in q or q['tax_rate'] is not None:raise ValueError('fixed_inclusive_total: 未知税率须为 null，不得用 0 代替')
    if q.get('items'):raise ValueError('fixed_inclusive_total: 总包价不接受逐项费用反算；逐项报价请使用 line_items')
    total=number(q.get('inclusive_total'),'inclusive_total')
    if total<0:raise ValueError('inclusive_total: 总包价须非负')
    total=total.quantize(D(contracts.policy()['calculation']['money_quantum']),rounding=ROUND_HALF_UP)
    months=None
    if q.get('period_months') is not None:
        months=number(q['period_months'],'period_months')
        if months<=0 or months!=months.to_integral_value():raise ValueError('period_months: 已提供月数须为正整数')
    elif not isinstance(q.get('coverage_period'),str) or not q['coverage_period'].strip():raise ValueError('coverage_period: 填写实际覆盖期间，或提供已知整数月数')
    payments=q.get('payment_percentages',[]);amounts=[]
    if payments:
        percentages=[number(value,'payment_percentage') for value in payments]
        expected=D(str(contracts.policy()['calculation']['payment_total_percent']))
        if any(value<0 for value in percentages) or sum(percentages)!=expected:raise ValueError('付款比例须非负且合计 '+str(expected))
        for value in percentages[:-1]:amounts.append((total*value/expected).quantize(D(contracts.policy()['calculation']['money_quantum']),rounding=ROUND_HALF_UP))
        amounts.append(total-sum(amounts))
    return {'mode':'fixed_inclusive_total','currency':q['currency'],'rows':[],'subtotal_ex_tax':None,'tax':None,'tax_rate':None,'tax_included':True,'total':money(total),'period_months':int(months) if months is not None else None,**({'coverage_period':q['coverage_period']} if q.get('coverage_period') else {}),'payment_amounts':[money(value) for value in amounts],'rounding':'已知含税总包价按金额精度保留；仅对明确提供的付款比例计算分期，末期吸收分位差','note':contracts.fact_policy()['unknown_tax_note']}

def calculate(p):
    rules=contracts.policy()['calculation']; quantum=D(rules['money_quantum'])
    q = p.get('pricing'); issues = []; result = {'issues': issues, 'pricing': None, 'returns': None}
    if q is None:
        if p.get('kind') == 'quote': issues.append('pricing: 方案报价金额待补')
    elif q.get('mode',contracts.fact_policy()['default_pricing_mode']) not in contracts.fact_policy()['pricing_modes']:
        issues.append('pricing.mode: 未知计价方式')
    elif q.get('mode')=='fixed_inclusive_total':
        try:result['pricing']=fixed_inclusive_total(q)
        except (ValueError,KeyError,TypeError,ArithmeticError) as e:issues.append(str(e))
    else:
        try:
            rate = number(q.get('tax_rate'), 'tax_rate')
            if not D(str(rules['fraction_min'])) <= rate <= D(str(rules['fraction_max'])): raise ValueError('tax_rate: 超出合同规定的小数范围')
            if not q.get('currency'): raise ValueError('currency: 币种待补')
            if not isinstance(q.get('tax_included'), bool): raise ValueError('tax_included: 需要 true 或 false')
            rows = q.get('items', [])
            if not rows: raise ValueError('items: 报价明细待补')
            amounts = []; seen = set(); chosen = D(0)
            for row in rows:
                ident = row.get('id')
                if not ident or ident in seen: raise ValueError('费用 ID 缺失或重复')
                seen.add(ident)
                if not isinstance(row.get('selected'), bool): raise ValueError(str(ident) + ': selected 需要布尔值')
                if not row['selected'] and (row.get('quantity') is None or row.get('unit_price') is None):
                    amounts.append({'id': ident, 'amount': None, 'selected': False, 'period': row.get('period'), 'note': '未选且尚未定价，不计入本期总价'})
                    continue
                qty = number(row.get('quantity'), str(ident) + '.quantity')
                price = number(row.get('unit_price'), str(ident) + '.unit_price')
                if qty < 0 or price < 0: raise ValueError('本计算器只处理非负数量和单价；折扣等复杂模型另算')
                if not row.get('period') or not row.get('unit'): raise ValueError(str(ident) + ': 单位及费用期间待补')
                amount = (qty * price).quantize(quantum, rounding=ROUND_HALF_UP)
                if row['selected']: chosen += amount
                amounts.append({'id': ident, 'amount': money(amount), 'selected': row['selected'], 'period': row['period']})
            if q['tax_included']:
                total = chosen; net = (total / (1 + rate)).quantize(quantum, rounding=ROUND_HALF_UP); tax = total - net
            else:
                net = chosen; tax = (net * rate).quantize(quantum, rounding=ROUND_HALF_UP); total = net + tax
            payments = q.get('payment_percentages', [])
            payment_amounts = []
            if payments:
                percentages = [number(v, 'payment_percentage') for v in payments]
                percent_total=D(str(rules['payment_total_percent']))
                if any(v < 0 for v in percentages) or sum(percentages) != percent_total: raise ValueError('付款比例须非负且合计 '+str(percent_total))
                for percent in percentages[:-1]: payment_amounts.append((total * percent / percent_total).quantize(quantum, rounding=ROUND_HALF_UP))
                payment_amounts.append(total - sum(payment_amounts))
            result['pricing'] = {'currency': q['currency'], 'rows': amounts, 'subtotal_ex_tax': money(net), 'tax': money(tax), 'total': money(total), 'payment_amounts': [money(v) for v in payment_amounts], 'rounding': '各行四舍五入到分；按合计计税；末期付款吸收分位差'}
        except (ValueError, KeyError, TypeError, ArithmeticError) as e: issues.append(str(e))
    r = p.get('returns')
    if r:
        try:
            if r.get('model') not in rules['return_models']: raise ValueError('returns: 其他回报模型须另附可复核计算证据')
            for key in rules['return_basis_fields']:
                if not r.get(key): raise ValueError('returns.' + key + ': 依据待补')
            start = number(r.get('evaluation_start_month'), 'evaluation_start_month'); months = number(r.get('evaluation_months'), 'evaluation_months'); benefit = number(r.get('benefit_start_month'), 'benefit_start_month')
            if any(v != v.to_integral_value() for v in [start, months, benefit]) or start < 0 or benefit < 0 or months <= 0: raise ValueError('评估及收益起算使用非负整数月份，评估月数须大于零')
            hours = number(r.get('hours_per_month'), 'hours_per_month'); improvement = number(r.get('improvement'), 'improvement'); hourly = number(r.get('hourly_value'), 'hourly_value'); cost = number(r.get('comparison_cost'), 'comparison_cost')
            if min(hours, hourly, cost) < 0 or not D(str(rules['fraction_min'])) <= improvement <= D(str(rules['fraction_max'])): raise ValueError('工时、单价及投入须非负，改善率超出合同范围')
            if r['cost_basis'] == 'quote_total' and result['pricing'] and cost != D(result['pricing']['total']): raise ValueError('回报比较投入与本期报价总价不一致')
            effective = max(D(0), start + months - max(start, benefit)); released = hours * improvement * effective; value = released * hourly
            result['returns'] = {'label': '工时价值／投入对照比', 'effective_months': int(effective), 'released_hours': str(released), 'time_value': money(value), 'comparison_cost': money(cost), 'value_cost_ratio': money(value / cost) if cost else None, 'financial_roi': None, 'cash_payback': None, 'note': '此模型未设现金转化；财务 ROI 与现金回本期不适用。复杂爬坡、多年摊销及现金模型另附测算。'}
        except (ValueError, KeyError, TypeError, ArithmeticError) as e: issues.append(str(e))
    return result

def context(work):
    p = load(work / 'project.json'); state = load(work / 'state.json')
    contracts.validate(p,'project.schema.json'); contracts.validate(state,'state.schema.json')
    contracts.registered_data(work,p)
    presentation.read_inputs(work,p)
    if (work/'quality-review.json').is_file():contracts.validate(load(work/'quality-review.json'),'quality-review.schema.json')
    return p, state

def critical(p,work=None):
    value={k:p.get(k) for k in CRITICAL}
    if model.active(p):
        for key in model.rules()['internal_expression_fields']:value.pop(key,None)
        value['request_requirements']=model.business_requirements(p)
        value['decision_context']=p['decision_context']
        # Artifact placement/assets are internal expression work; the shared
        # argument and its decision conditions are bound below.
        if work is not None:
            import client_content
            if client_content.active(p):
                view=client_content.customer_view(work,p,'project',p)
                for key in set(value)&set(client_content.rules()['project_client_fields']):value[key]=view.get(key)
                value['common_argument']=client_content.business_content(work,p)
            else:value['common_argument']={'content':model.base(work),'story':model.story(work)}
    return digest(value)
def candidate(work, p, state):
    files = {}
    for role in p['outputs']:
        item = state.get('files', {}).get(role)
        if not item: files[role] = None; continue
        f = Path(item['path']); files[role] = filehash(f) if f.is_file() else None
    bases={str(path):filehash(path) for path,data,schema in contracts.registered_data(work,p)}
    legacy=work/'content-base.md'
    if legacy.is_file(): bases[legacy.name]=filehash(legacy)
    return digest({'project': p, 'content_base': bases, 'files': files,'contracts':contracts.fingerprint(),'presentation_inputs':presentation.input_manifest(work,p)})

def inspect(path, role):
    if role=='proposal_md':
        text=Path(path).read_text(encoding='utf-8');return {'pages':None,'text':text,'blocks':text.split('\n\n'),'headings':[v.lstrip('# ') for v in text.splitlines() if v.startswith('#')]}
    if role in ['pptx', 'sow_docx','proposal_docx']:
        with ZipFile(path) as z:
            if z.testzip(): raise ValueError('损坏的 OOXML 包')
            if role == 'pptx':
                import re
                pages = sorted(x for x in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+.xml', x))
                roots = [ET.fromstring(z.read(x)) for x in pages]
                ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
                blocks=[''.join(x.text or '' for x in paragraph.findall('.//a:t',ns)) for rt in roots for paragraph in rt.findall('.//a:p',ns)]
                blocks+=[' | '.join(''.join(x.text or '' for x in cell.findall('.//a:t',ns)) for cell in row.findall('a:tc',ns)) for rt in roots for row in rt.findall('.//a:tr',ns)]
                text = '\n'.join(blocks)
                return {'pages': len(pages), 'text': text, 'blocks':blocks, 'editable_text_objects': sum(sum(1 for x in rt.iter() if x.tag.endswith('}txBody')) for rt in roots)}
            rt = ET.fromstring(z.read('word/document.xml'))
            ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            paragraphs=rt.findall('.//w:p',ns)
            blocks=[''.join(x.text or '' for x in paragraph.findall('.//w:t',ns)) for paragraph in paragraphs]
            blocks+=[' | '.join(''.join(x.text or '' for x in cell.findall('.//w:t',ns)) for cell in row.findall('w:tc',ns)) for row in rt.findall('.//w:tr',ns)]
            headings=[]
            for paragraph in paragraphs:
                style=paragraph.find('w:pPr/w:pStyle',ns)
                if style is not None and style.get('{'+ns['w']+'}val','').lower().startswith('heading'):
                    headings.append(''.join(x.text or '' for x in paragraph.findall('.//w:t',ns)))
            sections={};current=None
            styles=ET.fromstring(z.read('word/styles.xml'));style_names={n.get('{'+ns['w']+'}styleId'):(n.find('w:name',ns).get('{'+ns['w']+'}val','') if n.find('w:name',ns) is not None else '') for n in styles.findall('w:style',ns)}
            body=rt.find('w:body',ns)
            for element in body:
                text='\n'.join(''.join(n.text or '' for n in p.findall('.//w:t',ns)) for p in ([element] if element.tag.endswith('}p') else element.findall('.//w:p',ns)))
                style=element.find('w:pPr/w:pStyle',ns)
                if style is not None and style_names.get(style.get('{'+ns['w']+'}val'),'').lower()=='heading 1':current=text;sections[current]=[]
                if current is not None:sections[current].append(text)
            return {'pages': None, 'text': '\n'.join(blocks),'blocks':blocks,'headings':headings,'sections':{k:'\n'.join(v) for k,v in sections.items()}}
    from pypdf import PdfReader
    reader = PdfReader(path)
    pages=[page.extract_text() or '' for page in reader.pages]
    table_blocks=[]
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            spatial_pages=[]
            for page in pdf.pages:
                # Spatial extraction preserves CJK heading order when a PDF
                # draws fallback glyph runs out of text-stream order.
                spatial_pages.append(page.extract_text() or '')
                for table in page.extract_tables():
                    for row in table:table_blocks.append(' | '.join(' '.join((value or '').split()) for value in row))
            pages=spatial_pages
    except ImportError:pass
    # Keep one reading-order stream. Appending alternate extraction and table
    # rows to it can turn a table cell into the last apparent section heading.
    return {'pages': len(reader.pages), 'text': '\n'.join(pages),'blocks':pages+table_blocks}

def check(work, p, state):
    issues = []; calc = calculate(p); issues += calc['issues']
    if model.active(p):issues+=model.model_issues(work,p)
    for key in contracts.policy()['workflow']['required_project_fields']:
        if model.active(p) and key=='outline':continue
        if not p.get(key): issues.append(key + ': 任务关键内容待补')
    quote_fields=['deliverable_details','acceptance'] if model.active(p) else contracts.policy()['workflow']['quote_required_fields']
    if p['kind'] == 'quote' and any(not p.get(k) for k in quote_fields): issues.append('方案报价的交付与验收待补')
    selected_paths = [v['path'] for k, v in state.get('files', {}).items() if k in p['outputs']]
    if len(selected_paths) != len(set(selected_paths)): issues.append('不同交付角色不得复用同一个文件路径')
    approval = state.get('approval')
    if not approval or approval['critical_digest'] != critical(p,work): issues.append('缺本版关键内容的实际确认；请生成确认包并取得确认')
    info = {}
    render_check=render_adapter.actual_checks(work,p)
    issues+=render_check['issues']
    manifest_path=render_adapter.path(work,p.get('render_manifest') or 'render-manifest.json')
    if model.active(p) and manifest_path.is_file():
        manifest=load(manifest_path)
        if manifest['status']=='partial':issues.append('当前清单仅包含关键页试制，完整候选待制作')
        for role,item in state.get('files',{}).items():
            if role not in p['outputs']:continue
            bound=manifest['exports'].get(role,{}).get('file') if role.endswith('_pdf') else manifest['source_files'].get(role)
            if not bound or Path(item['path']).resolve()!=Path(bound['path']).resolve() or item['sha256']!=bound['sha256']:issues.append(role+': 登记成品与实际制作／导出清单不一致')
    for role in p['outputs']:
        record = state.get('files', {}).get(role)
        if not record: issues.append(role + ': 文件未登记'); continue
        f = Path(record['path'])
        if not f.is_file(): issues.append(role + ': 文件不存在'); continue
        if filehash(f) != record['sha256']: issues.append(role + ': 文件变化，须重新登记并复核')
        try:
            info[role] = inspect(f, role)
            audited=render_adapter.audited_text(work,p) if render_check['status']=='passed' else ''
            if audited and role in ['pptx','ppt_pdf']:info[role]['text']+='\n'+audited
            if not info[role]['text'].strip(): issues.append(role + ': 无可抽取文字，须核查原生编辑及导出内容')
            if role in ['pptx', 'ppt_pdf'] and not info[role]['pages']: issues.append(role + ': 页数无效')
        except ImportError: issues.append(role + ': 缺文件读取组件，检查待验证')
        except Exception as e: issues.append(role + ': 读取失败 ' + str(e))
    if 'pptx' in info and 'ppt_pdf' in info and info['pptx']['pages'] != info['ppt_pdf']['pages']: issues.append('PPTX 与对应 PDF 页数不同')
    if 'pptx' in info and p['kind']=='quote' and not model.written(p):
        rules=contracts.policy()['optional_presentation']; pages=info['pptx']['pages']; depth=rules['depth'][p['depth']]
        if not depth['min_pages'] <= pages <= depth['max_pages'] and not p.get('page_plan_evidence'): issues.append('主稿页数不在所选深度区间，缺页级安排依据')
        if pages>rules['page_plan_confirmation_above'] and not p.get('page_plan_evidence'): issues.append('超出默认篇幅，缺页级安排确认依据')
    if p.get('threshold_overrides') and not p.get('threshold_override_evidence'): issues.append('替代版面阈值缺确认依据')
    normalize = lambda s: ''.join(str(s).split()).replace(',', '').replace('，', '')
    count = 0
    for assertion in p.get('assertions', []):
        for role in assertion.get('roles', p['outputs']):
            if role in p['outputs'] and role in info:
                count += 1
                if not assertion.get('text') or normalize(assertion['text']) not in normalize(info[role]['text']): issues.append(role + ': 未找到约定字段 ' + str(assertion.get('id')))
    fact_check=facts.check(p,info,calc,work);issues+=fact_check['issues']
    projection=model.projection_check(work,p,info,state) if model.active(p) else {'status':'not_applicable','issues':[]}
    issues+=projection['issues']
    import client_content
    client_check=client_content.check(work,p,state);issues+=client_check['issues']
    review = state.get('review')
    if not review or review.get('result') != 'pass': issues.append('独立复核未通过或未登记')
    else:
        report = Path(review['report'])
        if review['reviewer'] == state['producer']: issues.append('制作与复核身份相同')
        if review['candidate_digest'] != candidate(work, p, state): issues.append('候选变化，旧独立复核已失效')
        if not report.is_file() or filehash(report) != review['report_sha256']: issues.append('独立复核报告缺失或变化')
    summary = {k: {key: val for key, val in v.items() if key not in ['text','blocks','headings']} for k, v in info.items()}
    quality=presentation.quality_summary(work,p,state,candidate(work,p,state),summary.get('pptx',{}).get('pages'))
    technical=gates.technical_conclusion(work,p,state,candidate(work,p,state),filehash,issues)
    return {'mechanical_checks': 'passed' if not issues else 'blocked', 'issues': issues, 'calculation': calc, 'files': summary, 'candidate_digest': candidate(work, p, state), 'assertion_comparisons': count,'shared_fact_check':fact_check,'projection_check':projection,'client_content_check':client_check,'render_check':render_check, 'quality':quality,'quality_conclusions':{'technical':technical,'business_argument':quality['business_argument'],'presentation_quality':quality['presentation_quality'],'artifact_quality':quality.get('artifact_quality',{})}, 'sop_release': '按本次质量目标分别记录整体 Proposal、载体表达与技术结论'}

def main():
    rules=contracts.policy()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=rules['commands'])
    parser.add_argument('--workdir', required=True, type=Path); parser.add_argument('--producer'); parser.add_argument('--kind', choices=list(rules['types']), default=rules['default_kind'])
    parser.add_argument('--actor'); parser.add_argument('--evidence'); parser.add_argument('--role', choices=sorted(ROLES)); parser.add_argument('--file', type=Path); parser.add_argument('--reviewer'); parser.add_argument('--report', type=Path); parser.add_argument('--result', choices=rules['workflow']['review_results']); parser.add_argument('--destination',type=Path)
    parser.add_argument('--outputs',help='Comma-separated selected artifact roles for init')
    parser.add_argument('--presentation-requested',action='store_true',help='User explicitly requested an optional reporting edition')
    parser.add_argument('--sow-required',action='store_true',help='User requested an independent SOW')
    parser.add_argument('--partial-artifact',action='store_true',help='Explicitly scoped partial artifact, not a complete Proposal')
    args = parser.parse_args(); work = args.workdir.resolve(); command = args.command
    if command=='validate':
        result=contracts.validate_all()
        if (work/'project.json').is_file(): context(work)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return
    if command=='render':
        if not args.file: raise ValueError('render 需要 --file 指向 JSON 模板或目录')
        print(contracts.render(load(args.file))); return
    if command=='hook-config':
        import shlex
        hook=HERE/'hooks/claude_stop.py'
        command_line=' '.join(shlex.quote(str(v)) for v in [sys.executable,hook,'--workdir',work])
        print(json.dumps({'hooks':{'Stop':[{'hooks':[{'type':'command','command':command_line,'timeout':30}]}]}},ensure_ascii=False,indent=2)); return
    if command == 'init':
        if not args.producer: raise ValueError('init 需要实际 producer ID')
        work.mkdir(parents=True, exist_ok=True)
        if any((work / x).exists() for x in ['project.json', 'state.json', 'content-base.md','content-base.json']): raise ValueError('已有项目文件，不覆盖；请读取现有状态或选择新位置')
        p = load(HERE / 'assets/project.json'); p['kind'] = args.kind
        p['outputs']=rules['types'][args.kind]['default_outputs'][:]
        p['presentation_requested']=args.presentation_requested;p['sow_required']=args.sow_required
        p['task_scope']='partial_artifact' if args.partial_artifact else 'complete_proposal'
        if args.presentation_requested:p['outputs'] += rules['optional_presentation']['default_outputs']
        if args.sow_required:p['outputs'] += rules['optional_sow']['default_outputs']
        if args.outputs:p['outputs']=args.outputs.split(',')
        if model.has_ppt(p) and not args.presentation_requested:raise ValueError('汇报版需要显式 --presentation-requested')
        if {'sow_docx','sow_pdf'}&set(p['outputs']) and not args.sow_required:raise ValueError('独立 SOW 需要显式 --sow-required')
        if args.outputs and not args.partial_artifact and not {'proposal_docx','proposal_pdf'}<=set(p['outputs']):raise ValueError('完整书面 Proposal 必须有 DOCX+PDF；局部任务需显式 --partial-artifact 并登记用户要求')
        p['presentation_plan']='presentation-plan.json' if args.presentation_requested else None
        contracts.validate(p,'project.schema.json')
        save(work / 'project.json', p); save(work / 'state.json', {'schema': 2, 'producer': args.producer, 'created': now(), 'files': {}, 'history': []})
        for source in (HERE/'assets/templates').glob('*.json'):
            if source.stem.startswith('07-'): continue
            shutil.copy2(source,work/(source.stem.split('-',1)[1]+'.json'))
        names=['visual-profile.json','render-policy.json','document-plan.json','production-chain.json']+(['presentation-plan.json','calibration.json'] if model.has_ppt(p) else [])
        for name in names:shutil.copy2(HERE/'assets'/name,work/name)
        import written_proposal
        document=load(work/'document-plan.json')
        for chapter in document['chapters']:
            override=written_proposal.rules()['chapter_title_overrides'].get(args.kind,{}).get(chapter['section_id'],{})
            if override:chapter['title']=override['zh']
        save(work/'document-plan.json',document)
        print(json.dumps({'workdir': str(work), 'kind': args.kind}, ensure_ascii=False)); return
    if command=='doctor':
        p=contracts.validate(load(work/'project.json'),'project.schema.json') if (work/'project.json').is_file() else load(HERE/'assets/project.json')
        print(json.dumps(render_adapter.doctor(work,p),ensure_ascii=False,indent=2));return
    p, state = context(work); result = None
    if command in ['sow-build','proposal-brief','proposal-record','presentation-brief','presentation-record','chain-check']:
        import production_chain
        result=production_chain.execute(command,work,p,args)
        state=load(work/'state.json')
    elif command=='shared-facts':result=facts.expected(p,calculate(p))
    elif command=='presentation-image-prepare':
        import ppt_image_method
        if not args.destination:raise ValueError('presentation-image-prepare 需要新目录 --destination')
        result=ppt_image_method.prepare(work,p,load(presentation.plan_path(work,p)),args.destination,args.actor,args.evidence,load(args.file) if args.file else None)
    elif command=='handoff':result=model.handoff(work,p)
    elif command=='model-check':
        problems=model.model_issues(work,p);result={'status':'blocked' if problems else 'ready','issues':problems}
    elif command in ['document-plan-check','document-check']:
        import written_proposal
        if command=='document-plan-check':
            problems=written_proposal.plan_issues(work,p);result={'status':'blocked' if problems else 'ready','issues':problems}
        else:result=render_adapter.verify(work,p,args.file)
    elif command=='projection-check':result=model.projection_check(work,p,model.corpus(work,p,state),state)
    elif command in ['client-content-check','client-review-init']:
        import client_content
        if command=='client-content-check':result=client_content.check(work,p,state)
        else:
            if not client_content.active(p):raise ValueError('先在新任务或明确采用新规则的项目中启用 client_content_policy')
            if not args.reviewer:raise ValueError('client-review-init 需要现有独立检查者 --reviewer')
            path=work/client_content.rules()['client_review_file']
            if path.exists():raise ValueError('正文复核记录已存在；保留原记录后使用当前文件更新结果')
            result=client_content.starter(work,p,state,args.reviewer);contracts.validate(result,'client-content-review.schema.json');save(path,result)
    elif command=='migrate':
        if not args.destination or not args.producer:raise ValueError('migrate 需要新目录 --destination 与实际 --producer')
        result=model.migrate(work,p,args.destination,args.producer)
    elif command in ['eval-freeze','eval-result','eval-compare']:
        import evaluation
        result=evaluation.execute(command,work,p,args)
    elif command in ['build','presentation-build']:
        import production_chain
        if production_chain.active(p):production_chain.enforce(work,p,'presentation' if command=='presentation-build' else 'proposal')
        issues=presentation.registration_issues(work,p,state)
        if issues:raise ValueError('；'.join(issues)+'；关键页试制请使用 render_adapter.py build --calibration')
        plan,_=presentation.read_inputs(work,p)
        output=args.destination or work/'candidates'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        result=render_adapter.build(work,p,plan,output,stage='presentation' if command=='presentation-build' else None)
    elif command=='export':result=render_adapter.export(work,p,args.file or work/'render-manifest.json')
    elif command=='render-check':result=render_adapter.verify(work,p,args.file)
    elif command=='audit-images':result=render_adapter.audit_images(work,p,args.file or work/'render-manifest.json',args.report,args.reviewer)
    elif command == 'calculate': result = calculate(p)
    elif command == 'packet':
        fp = critical(p,work)
        body={'critical_digest':fp,'project':{k:p.get(k) for k in CRITICAL},'calculation':calculate(p),'content_base':'content-base.json','story_map':'story-map.json','presentation_plan':str(presentation.plan_path(work,p)),'calibration':'calibration.json','presentation_inputs':presentation.input_manifest(work,p)}
        if model.written(p):
            body.pop('presentation_plan',None);body.pop('calibration',None);body.pop('presentation_inputs',None)
            body.update(document_plan=p.get('document_plan'),production_inputs=presentation.input_manifest(work,p))
            if p.get('presentation_requested'):body['optional_presentation']={'presentation_plan':p['presentation_plan'],'calibration':'calibration.json'}
        if model.active(p):body.update(request_requirements=model.requirements(p),requirements_version=p['request_requirements_version'],decision_context=p['decision_context'],common_argument=model.base(work),artifact_projection=p['artifact_projection'])
        path = work / ('confirmation-' + fp[:12] + '.json'); save(path,body)
        state['packet'] = {'critical_digest': fp, 'path': str(path), 'sha256': filehash(path), 'created': now()}; result = state['packet']
    elif command == 'approve':
        if not args.actor or not args.evidence: raise ValueError('记录实际确认人及回复位置')
        packet = state.get('packet')
        if not packet or packet['critical_digest'] != critical(p,work): raise ValueError('确认包缺失或关键字段变化，请重新生成并取得实际确认')
        if not Path(packet['path']).is_file() or filehash(packet['path']) != packet['sha256']: raise ValueError('确认包变化，请重新生成')
        state['approval'] = {'actor': args.actor, 'evidence': args.evidence, 'critical_digest': critical(p,work), 'packet': packet, 'time': now()}; result = state['approval']
    elif command == 'register':
        if not args.role or not args.file or not args.file.is_file(): raise ValueError('register 需要有效 role 和实际文件')
        if args.role not in p['outputs']: raise ValueError('role 不在本次交付选择内')
        suffix = rules['outputs'][args.role]['suffix']
        if args.file.suffix.lower() != suffix: raise ValueError('文件扩展名与 role 不符')
        production_issues=presentation.registration_issues(work,p,state)
        if production_issues:raise ValueError('；'.join(production_issues))
        state['files'][args.role] = {'path': str(args.file.resolve()), 'sha256': filehash(args.file), 'registered': now()}; result = state['files'][args.role]
    elif command == 'review':
        if not args.reviewer or args.reviewer == state['producer']: raise ValueError('reviewer 必须是不同的实际实例或人员')
        if not args.report or not args.report.is_file() or not args.result: raise ValueError('review 需要已经完成的实际报告及结果')
        if set(state['files']) & set(p['outputs']) != set(p['outputs']): raise ValueError('先登记全部所选候选文件')
        state['review'] = {'reviewer': args.reviewer, 'result': args.result, 'report': str(args.report.resolve()), 'report_sha256': filehash(args.report), 'candidate_digest': candidate(work, p, state), 'time': now()}; result = state['review']
    elif command == 'status':
        result = {'producer': state['producer'], 'confirmed_current': bool(state.get('approval') and state['approval']['critical_digest'] == critical(p,work)), 'packet': state.get('packet'), 'files': state['files'], 'review_current': bool(state.get('review') and state['review']['candidate_digest'] == candidate(work, p, state)), 'review': state.get('review'),'production_current':not presentation.registration_issues(work,p,state),'quality':presentation.quality_summary(work,p,state,candidate(work,p,state))}
    elif command == 'check': result = check(work, p, state)
    elif command=='production-check':
        result=presentation.production_record(work,p,state)
        if result['issues']:
            print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(2)
        state['production']={k:result[k] for k in ['input_digest','plan_sha256','calibration_sha256']};state['production']['time']=now()
        if model.written(p):state['production']['document_plan_sha256']=result['document_plan_sha256']
    elif command=='quality-init':
        if not args.reviewer or args.reviewer==state['producer']:raise ValueError('使用本次独立检查者的实际身份')
        if not all(role in state['files'] for role in p['outputs']):raise ValueError('先登记全部所选成品')
        path=work/'quality-review.json'
        if path.exists():raise ValueError('quality-review.json 已存在；保留原始评审并修订')
        result=presentation.review_starter(work,p,args.reviewer,candidate(work,p,state));contracts.validate(result,'quality-review.schema.json');save(path,result)
    elif command=='checks-init':
        path=work/'checks.json'
        if path.exists(): raise ValueError('checks.json 已存在；保留原始结果并修订，避免覆盖检查证据')
        result={'schema':1,'candidate_digest':candidate(work,p,state),'items':[{'id':ident,'status':'pending','location':'待登记','reviewer':'待登记','reason':None,'evidence':[]} for ident in contracts.applicable(p)]}
        contracts.validate(result,'check-records.schema.json'); save(path,result)
    elif command=='release':
        result=check(work,p,state)
        manual_issues=gates.evidence_issues(work,p,state,candidate(work,p,state),filehash)
        quality_issues,quality=presentation.release_issues(work,p,state,candidate(work,p,state),result['files'].get('pptx',{}).get('pages'))
        result['quality']=quality
        result['release_issues']=result['issues']+manual_issues+quality_issues
        if not all(p['delivery'].get(k) for k in ['recipients','channel','authorization_evidence']): result['release_issues'].append('交付对象、渠道或有效授权依据未登记')
        if result['release_issues']:
            result['technical_issues']=result['issues'][:];result['issues']=result['release_issues'];result['release_status']='blocked';print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(2)
        # Publication identity is fixed before the first output write.
        fp=candidate(work,p,state); files={}
        destination=args.destination.resolve() if args.destination else None
        if destination:
            names=[Path(state['files'][role]['path']).name for role in p['outputs']]
            if len(names)!=len(set(names)): raise ValueError('放行目录中文件同名')
            if destination.exists(): raise ValueError('目标位置已存在；选择本次新版本位置')
            import tempfile
            destination.parent.mkdir(parents=True,exist_ok=True)
            with tempfile.TemporaryDirectory(dir=destination.parent,prefix='.proposal-release-') as staging:
                folder=Path(staging)/'bundle'; folder.mkdir()
                for role in p['outputs']:
                    record=state['files'][role]; output=folder/Path(record['path']).name
                    shutil.copy2(record['path'],output)
                    if filehash(output)!=record['sha256']: raise ValueError('复制时文件变化，放行已停止')
                    files[role]={'path':str(destination/output.name),'sha256':record['sha256']}
                if candidate(work,p,state)!=fp: raise ValueError('放行时候选变化')
                folder.replace(destination)
        else: files={role:{k:state['files'][role][k] for k in ['path','sha256']} for role in p['outputs']}
        result={'schema':1,'draft_mode':p['draft_mode'],'candidate_digest':fp,'checks_sha256':filehash(work/'checks.json'),'policy_digest':contracts.fingerprint(),'created':now(),'producer':state['producer'],'approval_actor':state['approval']['actor'],'approval_evidence':state['approval']['evidence'],'reviewer':state['review']['reviewer'],'destination':str(destination) if destination else str(work),'files':files,'quality_target':quality['quality_target'],'quality_review_sha256':filehash(work/'quality-review.json'),'quality_conclusions':{'technical':'passed','business_argument':quality['business_argument'],'presentation_quality':quality['presentation_quality']}}
        if model.active(p):result['quality_conclusions'].update(proposal_quality=quality['proposal_quality'],artifact_quality=quality['artifact_quality'])
        if model.written(p):result['task_scope']=p['task_scope']
        import client_content
        if client_content.active(p):result['client_content_review_sha256']=filehash(work/client_content.rules()['client_review_file'])
        contracts.validate(result,'release.schema.json'); save(work/'release.json',result)
    if command in rules['mutating_commands']:
        state['history'].append({'command': command, 'time': now(), 'record': result}); save(work / 'state.json', state)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if (command in ['calculate','check','model-check','projection-check','document-plan-check','document-check','chain-check','client-content-check'] and result.get('issues')) or (command in ['render-check','audit-images'] and result.get('issues')) or (command in ['build','presentation-build'] and result['status']=='failed'): sys.exit(2)

if __name__ == '__main__':
    try: main()
    except (ValueError, KeyError, TypeError, ArithmeticError, OSError, json.JSONDecodeError) as e:
        print(json.dumps({'error': str(e)}, ensure_ascii=False), file=sys.stderr); sys.exit(2)
