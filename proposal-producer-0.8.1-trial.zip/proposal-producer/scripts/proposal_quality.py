"""Review the selected client Proposal, then each artifact, with separate evidence."""
from pathlib import Path
import contracts
import proposal_model as model

def rules():return contracts.validate(contracts.load(contracts.ROOT/'contracts/proposal-quality.json'),'proposal-quality.schema.json')
def rubric_digest():return model.digest(rules())
def business_digest(work,project,state):
    content=model.base(work);chain=model.story(work);data=model.corpus(work,project,state)
    # Style, image bytes, shape placement and visual-only requests are excluded;
    # actual customer text and commercial sources remain part of this fingerprint.
    keys=['kind','audience','decision','scope','deliverables','acceptance','schedule','business','pricing','returns','outputs','shared_facts','requirements','work_packages','sow_sections','deliverable_details','milestones','decision_context']
    def text(role,info):
        if model.written(project) and role in ['proposal_docx','proposal_pdf']:
            import written_proposal,re
            pieces=[model.actual_location(work,project,role,c['section_id'],info,state) for c in written_proposal.plan(work,project)['chapters']]
            value=model.normalize('\n'.join(pieces))
            value=re.sub(r'\d{4}-\d{2}-\d{2}\s*\|\s*\d+','',value)
            title=(project.get('document_metadata') or {}).get('title')
            if title:
                header=title+(' | '+str(project['shared_facts']['version']) if (project.get('shared_facts') or {}).get('version') else '')
                value=value.replace(model.normalize(header),'')
            return model.normalize(value)
        return model.normalize(info['text'])
    import client_content
    if client_content.active(project):
        shared=client_content.business_content(work,project);content=shared['content'];chain=shared['story'];view=client_content.customer_view(work,project,'project',project)
    else:view=project
    return model.digest({'project':{k:view.get(k) for k in keys},'requirements':model.business_requirements(project),'content':content,'story':chain,'customer_text':{r:text(r,v) for r,v in data.items()},'rubric':rubric_digest()})

def applicable(content,project):
    result={v['id']:True for v in rules()['criteria']}
    fields={f for u in content['semantic_units'] for f in u['field_refs']}
    result['PQ01']=bool(content['scenarios'] or 'F08' in fields);result['PQ02']=bool(content['mechanisms'] or 'F09' in fields);result['PQ04']=bool(project.get('pricing') or content['fee_value_mappings'])
    return result

def starter(work,project,state,reviewer,candidate_digest):
    flags=applicable(model.base(work),project)
    fields={'target_defects':[],'followups':[],'limitations':[]}
    return {'schema':2,'candidate_digest':candidate_digest,'business_digest':business_digest(work,project,state),'rubric_version':rules()['rubric_version'],'rubric_digest':rubric_digest(),'decision_context':project['decision_context'],'quality_target':project['quality_target'],'reviewer':reviewer,'requirements_review':{'result':'not_evaluated','requirements_digest':model.requirements_digest(project),'checked_requirement_ids':[],'missing_requirements':[],'reason':'待对照原始有效指令核实提取完整性'},'proposal_reviews':[{'criterion_id':v['id'],'applicable':flags[v['id']],'result':'not_evaluated' if flags[v['id']] else 'not_applicable','reason':'待查看所选客户文件中的完整论证','evidence':[],**fields} for v in rules()['criteria']],'artifact_reviews':[{'artifact_role':r,'artifact_digest':state['files'][r]['sha256'],'result':'not_evaluated','reason':'待查看本交付物实际表达与可用性','evidence':[],'visual_observations':{},**fields} for r in project['outputs']],'technical_checks_refs':[],**fields}

def finding_issues(record,work):
    issues=[];open_target=any(v['status']=='open' for v in record.get('target_defects',[]))
    for key in ['followups','limitations']:open_target |= any(v['affects_target'] for v in record.get(key,[]))
    for defect in record.get('target_defects',[]):
        if defect['status']=='resolved':
            if not defect['resolution_evidence']:issues.append('缺陷关闭缺修复证据')
            for evidence in defect['resolution_evidence']:
                p=model.resolve(work,evidence['path'])
                if not p.is_file() or model.sha(p)!=evidence['sha256']:issues.append('缺陷修复证据缺失或变化')
    return open_target,issues

def evidence_issues(work,project,state,record,observed,units):
    issues=[]
    for evidence in record.get('evidence',[]):
        role=evidence['artifact_role'];info=observed.get(role)
        if info is None:issues.append('评审依据不在所选客户产物 '+role);continue
        if not evidence['claim_refs'] or set(evidence['claim_refs'])-set(units):issues.append('评审主张引用缺失或无效')
        if set(evidence['source_field_refs'])-set(contracts.load(contracts.ROOT/'contracts/fields.json')['fields']):issues.append('评审共同字段引用无效')
        actual=model.actual_location(work,project,role,evidence['section_or_page'],info,state) if not role.startswith('supporting:') else info['text']
        if model.normalize(evidence['quote']) not in model.normalize(actual):issues.append('评审摘录未见于实际页面或章节 '+role+'/'+evidence['section_or_page'])
    return issues

def aggregate(values):
    positive=rules()['positive']
    return 'gap' if 'gap' in values else 'not_evaluated' if not values or any(v not in positive for v in values) else 'strong' if all(v=='strong' for v in values) else 'acceptable'

def summary(work,project,state,candidate_digest,source_pages=None):
    result={'quality_target':project['quality_target'],'business_argument':'not_evaluated','proposal_quality':'not_evaluated','presentation_quality':'not_applicable' if not model.has_ppt(project) else 'not_evaluated','artifact_quality':{},'requirements':'not_evaluated','target_met':False,'issues':[]}
    file=Path(work)/'quality-review.json'
    if not file.is_file():result['issues'].append('缺当前 Proposal 及所选交付物的独立评价');return result
    record=contracts.validate(contracts.load(file),'quality-review.schema.json');issues=result['issues']
    if record.get('schema')!=2:issues.append('新模型使用质量记录 v2；历史记录保留原版本');return result
    shared=[]
    if record['reviewer']==state['producer'] or record['reviewer']!=state.get('review',{}).get('reviewer'):shared.append('质量评价应由本次实际独立检查者完成')
    if record['rubric_version']!=rules()['rubric_version'] or record['rubric_digest']!=rubric_digest():shared.append('商业判据版本已变化')
    if record['decision_context']!=project['decision_context']:shared.append('实际决定范围已变化')
    if record['quality_target']!=project['quality_target']:shared.append('质量目标已变化')
    issues+=shared
    req=record['requirements_review'];expected={r['id'] for r in model.requirements(project)}
    if req['requirements_digest']!=model.requirements_digest(project) or set(req['checked_requirement_ids'])!=expected or req['missing_requirements'] or req['result'] not in rules()['positive']:
        issues.append('原始有效要求的提取完整性尚未核实或已变化')
    else:result['requirements']=req['result']
    observed=model.corpus(work,project,state);coverage=model.projection_check(work,project,observed,state);result['projection_check']=coverage
    units={v['id']:v for v in model.base(work)['semantic_units']};flags=applicable(model.base(work),project)
    records={r['criterion_id']:r for r in record['proposal_reviews']};business=[]
    if len(records)!=len(record['proposal_reviews']):issues.append('商业评价项重复');business.append('not_evaluated')
    for definition in rules()['criteria']:
        ident=definition['id'];entry=records.get(ident)
        if not entry:issues.append(ident+': 缺整体商业评价');business.append('not_evaluated');continue
        if entry['applicable']!=flags[ident]:issues.append(ident+': 适用性与共同论证不一致');business.append('not_evaluated')
        if not flags[ident]:
            if entry['result']!='not_applicable':issues.append(ident+': 登记实际不适用结论')
            continue
        verdict=entry['result'];positive=verdict in rules()['positive'];local=evidence_issues(work,project,state,entry,observed,units)
        if positive and not entry['evidence']:local.append('通过结论缺所选客户文件中的依据')
        if positive and entry['evidence'] and not any(set(rules()['field_map'][ident]) & set(e['source_field_refs']) & {f for ref in e['claim_refs'] if ref in units for f in units[ref]['field_refs']} for e in entry['evidence']):local.append('实际证据未关联本商业判据的共同字段')
        target,findings=finding_issues(entry,work);local+=findings
        business.append('gap' if target else verdict)
        if target and positive:local.append('目标缺陷与商业通过结论冲突')
        if local:issues += [ident+': '+v for v in local];business.append('not_evaluated')
    if record['business_digest']!=business_digest(work,project,state):issues.append('商业论证、正式事实或实际客户文稿已变化，需重评商业部分');business.append('not_evaluated')
    if coverage['issues']:issues+=coverage['issues'];business.append('gap')
    if shared:business.append('not_evaluated')
    result['business_argument']=result['proposal_quality']=aggregate(business)
    artifacts={r['artifact_role']:r for r in record['artifact_reviews']}
    if len(artifacts)!=len(record['artifact_reviews']):issues.append('交付物评价重复')
    for role in project['outputs']:
        entry=artifacts.get(role)
        if not entry:issues.append(role+': 缺载体表达评价');result['artifact_quality'][role]='not_evaluated';continue
        values=[entry['result']];local=evidence_issues(work,project,state,entry,observed,units)
        current=state.get('files',{}).get(role,{})
        file=Path(current.get('path',''))
        if not file.is_file() or entry['artifact_digest']!=model.sha(file):local.append('载体文件已变化，重评本交付物')
        if entry['result'] in rules()['positive'] and not entry['evidence']:local.append('载体通过结论缺实际页面或章节依据')
        target,findings=finding_issues(entry,work);local+=findings
        if target:values.append('gap')
        if coverage['artifact_gaps'].get(role):values.append('gap');local.append('本载体摘要或关键条件存在生成遗漏')
        if role in ['pptx','ppt_pdf'] and entry['result'] in rules()['positive']:
            import presentation
            plan,_=presentation.read_inputs(Path(work),project)
            selected={key for page in plan['pages'] for key in page.get('visual',{}).get('calibration_focus',[])}
            if selected-set(entry['visual_observations']):local.append('缺所选视觉重点的实际观察')
        for realization in project.get('requirement_realizations',[]):
            if realization['artifact_role']==role and entry['result'] in rules()['positive'] and not entry['visual_observations'].get(realization['requirement_id']):local.append('缺任务要求在成品中的实际观察 '+realization['requirement_id'])
        if local:issues += [role+': '+v for v in local];values.append('not_evaluated')
        if shared:values.append('not_evaluated')
        result['artifact_quality'][role]=aggregate(values)
    if model.has_ppt(project):result['presentation_quality']=aggregate([v for r,v in result['artifact_quality'].items() if r in ['pptx','ppt_pdf']])
    for entry in record['technical_checks_refs']:
        file=model.resolve(work,entry['path'])
        if not file.is_file() or model.sha(file)!=entry['sha256']:issues.append('技术检查证据缺失或变化')
    global_target,global_issues=finding_issues(record,work);issues+=global_issues
    result['target_met']=not issues and not global_target and result['business_argument'] in rules()['positive'] and all(v in rules()['positive'] for v in result['artifact_quality'].values())
    result['candidate_current']=record['candidate_digest']==candidate_digest
    return result
