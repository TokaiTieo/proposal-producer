"""Illustrative authoring example and explicitly synthetic test evidence only."""
import copy
import json
from pathlib import Path
import hashlib

def example_plan():
    source=Path(__file__).resolve().parents[1]/'evals/fixtures/presentation-plan.json'
    return json.loads(source.read_text(encoding='utf-8'))


def prepare_inputs(work,api):
    """Create real local fixture files; these are not real proposal quality evidence."""
    from PIL import Image
    work=Path(work)
    # These pre-v4 protocol fixtures intentionally exercise schema-3 compatibility.
    project=api.load(work/'project.json');project['schema']=3;project['quality_target']='client_presentation'
    for key in ['shared_facts','requirements','work_packages','sow_sections']:project.pop(key,None)
    api.save(work/'project.json',project)
    for name in ['01-content-base','06-story-map']:
        (work/(name.split('-',1)[1]+'.json')).write_bytes((Path(__file__).resolve().parents[1]/'evals/fixtures'/('legacy-'+name+'.json')).read_bytes())
    img=work/'SYNTHETIC-render.png';Image.new('RGB',(4,4),'white').save(img)
    source=work/'SYNTHETIC-reference.txt';source.write_text('Synthetic reference, not a real client sample')
    def proof(path):return {'path':str(path),'sha256':api.filehash(path)}
    plan=example_plan();plan['project_label']='SYNTHETIC TEST ONLY'
    plan['references'][0].update(source=proof(source),page_view=proof(img))
    api.save(work/'presentation-plan.json',plan)
    cal={'schema':1,'plan_sha256':api.filehash(work/'presentation-plan.json'),'producer':api.load(work/'state.json')['producer'],'pages':[{'page_id':'P1','render':proof(img),'comparison':proof(img),'reference_page_ids':['REF1'],'result':'acceptable','reason':'Synthetic calibration assertion only','observed_object_ids':['O1','O2','O3'],'observed_relation_ids':['R1','R2']}]}
    api.save(work/'calibration.json',cal)
    return plan

def fill_quality(work,api,reviewer):
    import presentation
    work=Path(work);p,s=api.context(work)
    record=presentation.review_starter(work,p,reviewer,api.candidate(work,p,s))
    evidence={'path':str(work/'SYNTHETIC-render.png'),'sha256':api.filehash(work/'SYNTHETIC-render.png')}
    for item in record['criteria']:
        item.update(result='acceptable' if item['applicable'] else 'not_applicable',page_refs=['P1'] if item['applicable'] else [],reference_page_refs=['REF1'],reason='Synthetic assessment only',evidence=[evidence])
    record['page_reviews']=[{'page_id':'P1','result':'acceptable','decision_question_answered':True,'observed_takeaway':'Synthetic takeaway observation','observed_object_ids':['O1','O2','O3'],'observed_relation_ids':['R1','R2'],'reference_method_observed':'Synthetic object flow observation','reason':'Synthetic assessment only','render':evidence}]
    api.save(work/'quality-review.json',record)
    return record
