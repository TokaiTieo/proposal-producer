"""Bundled image-PPT method, real upstream script execution and artifact gates."""
from pathlib import Path
import json,re,subprocess,sys
import contracts,proposal_model as model

def rules():
    return contracts.validate(contracts.load(contracts.ROOT/'contracts/ppt-image-render.json'),'ppt-image-render.schema.json')

def bundle():
    policy=rules();root=(contracts.ROOT/policy['root']).resolve()
    if not root.is_relative_to(contracts.ROOT.resolve()):raise ValueError('PPT 内置方法路径越界')
    for name,expected in policy['files'].items():
        file=(root/name).resolve()
        if not file.is_relative_to(root) or not file.is_file() or model.sha(file)!=expected:
            raise ValueError('ppt-image-render 内置文件缺失或变化：'+name)
    return {'name':policy['name'],'version':policy['version'],'entrypoint':model.proof(root/policy['entrypoint']),'contract':model.proof(contracts.ROOT/'contracts/ppt-image-render.json'),'root':str(root)}

def invoke(root,script,arguments,log):
    argv=[sys.executable,str(Path(root)/'scripts'/script),*[str(v) for v in arguments]]
    result=subprocess.run(argv,capture_output=True,text=True,timeout=120)
    model.save(log,{'argv':argv,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    if result.returncode:raise ValueError(script+' 执行失败，见 '+str(log))

def sources(work,project,plan):
    import render_adapter as render,facts
    from proposal import calculate
    if plan.get('schema')==2:plan=model.materialized_plan(work,project,plan)
    calculation=calculate(project)
    if calculation['issues']:raise ValueError('；'.join(calculation['issues']))
    import client_content
    footers=([v['text'] for v in facts.expected(project,calculation,work)['facts'] if v['id'] in ['date','version']] if client_content.active(project) else facts.fact_texts(project,calculation,work))
    result={}
    for page in plan['pages']:
        ident=page['page_id']
        if not re.fullmatch(r'[A-Za-z0-9_-]+',ident):raise ValueError('PPT 页面 ID 不能用作安全文件名：'+ident)
        text=render.frozen_copy(page)+footers
        result[ident]='# '+text[0]+'\n\n'+'\n\n'.join(text[1:])+'\n'
        if len(result[ident])>rules()['limits']['max_source_characters']:raise ValueError(ident+': 超过整页图像内容容量，调整页计划后重新准备')
    if not result:raise ValueError('PPT 页计划为空')
    return result

def style(profile):
    # The upstream teal/01.AI/Chinese/6-agent overlay is a historical example.
    # The task's explicit language, brand and palette are authoritative here.
    return ('Create a professional 16:9 business presentation. Render only the frozen slide copy as visible text. '
            'Keep title position, typography, margins, line weights and icon family consistent across the deck. '
            'Use restrained small icons for semantic grouping and scene or output illustrations when they clarify the business mechanism. '
            'Show the actual direction of relationships and readable labels. Reserve ample whitespace and maintain legible body text. '
            'Use only the current project brand and entities present in the frozen copy. Do not add inherited brands, platform names, model names, agent counts or decorative text. '
            'The JSON below configures appearance and is not slide copy. Lock the actual chosen font family for titles, body, digits and English across all pages. '
            'If no brand or color is specified, use a restrained neutral business style. Do not translate or rewrite frozen content during rendering.\n\n'
            +json.dumps(profile,ensure_ascii=False,indent=2))

def prepare(work,project,plan,destination,actor,evidence,blueprints=None):
    if not project.get('presentation_requested'):raise ValueError('用户尚未选择制作 PPT')
    if not actor or not evidence:raise ValueError('登记采用图像 PPT 的已有选择依据：--actor 与 --evidence')
    import production_chain as chain,render_adapter as render
    chain.enforce(work,project,'presentation')
    method=bundle();content=sources(work,project,plan);destination=Path(destination).resolve()
    if destination.exists():raise ValueError('图像制作目录已存在，使用新候选目录')
    profile,route,_,route_file=render.task_config(work,project)
    # Preparation is a new immutable image job, not a rewrite of earlier source.
    destination.mkdir(parents=True)
    invoke(method['root'],'init_project.py',['--root',destination,'--skill',method['root']],destination/'init-command.json')
    for ident,text in content.items():(destination/'00_source'/f'{ident}.md').write_text(text,encoding='utf-8')
    if blueprints:
        contracts.validate(blueprints,'ppt-image-blueprints.schema.json')
        for ident,entry in blueprints.items():
            if ident not in content:raise ValueError('蓝本引用未知页面：'+ident)
            file=model.resolve(work,entry['path'])
            if not file.is_file() or model.sha(file)!=entry['sha256']:raise ValueError('蓝本缺失或版本变化：'+ident)
            from PIL import Image
            with Image.open(file) as im:im.verify()
            suffix=file.suffix.lower()
            if suffix not in ['.png','.jpg']:raise ValueError('蓝本使用 PNG 或 JPG')
            (destination/'05_blueprints'/(ident+suffix)).write_bytes(file.read_bytes())
    overlay=destination/'01_style_overlay/style_overlay_lean.md';overlay.write_text(style(profile),encoding='utf-8')
    (destination/'01_style_overlay/style_overlay_full.md').write_text(style(profile),encoding='utf-8')
    report=destination/'03_render_report'
    invoke(method['root'],'select_path.py',['--pages-dir',destination/'00_source','--blueprints-dir',destination/'05_blueprints','--out',report/'path_decision.json'],report/'select-command.json')
    invoke(method['root'],'build_prompt.py',['--pages-dir',destination/'00_source','--style-overlay',overlay,'--path-decision',report/'path_decision.json','--out-prompt-dir',destination/'02_render_prompt','--out-diff',report/'diff_report.json'],report/'prompt-command.json')
    route.update(default_mode='full_image',page_modes={},editable_text=False,editable_relations=False,full_image_choice={'actor':actor,'evidence':evidence,'page_ids':list(content)})
    contracts.validate(route,'render-policy.schema.json')
    immutable=[overlay,destination/'01_style_overlay/style_overlay_full.md',destination/'init-command.json',report/'select-command.json',report/'prompt-command.json',report/'path_decision.json',report/'high_density_flags.json',*sorted((destination/'00_source').glob('*.md')),*sorted((destination/'02_render_prompt').glob('*.md')),*sorted((destination/'05_blueprints').glob('*'))]
    job={'schema':1,'root':str(destination),'method':method['contract'],'entrypoint':method['entrypoint'],'profile_digest':model.digest(profile),'route':route,'files':[model.proof(f) for f in immutable]}
    contracts.validate(job,'ppt-image-job.schema.json');model.save(Path(work)/rules()['job_pointer'],job)
    return {'status':'prepared','job':job,'next':'Read the bundled method and integration guide; generate actual images from these prompts into staging, transcribe and OCR, run the bundled audit and promote scripts, then register the promoted images and regions in the page plan and refresh presentation-record.'}

def task_route(work,route):
    file=Path(work)/rules()['job_pointer']
    if not file.is_file():return route
    job=contracts.validate(contracts.load(file),'ppt-image-job.schema.json')
    return contracts.validate(job['route'],'render-policy.schema.json')

def read_job(work,project,plan):
    method=bundle();file=Path(work)/rules()['job_pointer']
    if not file.is_file():raise ValueError('先运行 presentation-image-prepare，使用内置 ppt-image-render')
    job=contracts.validate(contracts.load(file),'ppt-image-job.schema.json')
    if job['method']!=method['contract'] or job['entrypoint']!=method['entrypoint']:raise ValueError('PPT 内置方法版本已变化，重新准备图像制作')
    for proof in job['files']:
        if not Path(proof['path']).is_file() or model.sha(proof['path'])!=proof['sha256']:raise ValueError('PPT 冻结源文、样式或提示词已变化：'+proof['path'])
    root=Path(job['root'])
    import render_adapter
    profile,_,_,_=render_adapter.task_config(work,project)
    if job['profile_digest']!=model.digest(profile):raise ValueError('PPT 项目样式已变化，重新准备图像制作')
    current=sources(work,project,plan)
    if {p.stem:p.read_text(encoding='utf-8') for p in (root/'00_source').glob('*.md')}!=current:raise ValueError('PPT 上屏文字已变化，重新准备并出图')
    return root,job

def evidence(work,project,plan,selected):
    """Require actual promoted images and complete per-page QA, including calibration."""
    import render_adapter as render
    root,job=read_job(work,project,plan);report=root/'03_render_report'
    _,route,_,_=render.task_config(work,project,presentation=True)
    required=[report/name for name in rules()['required_reports']]
    for file in required:
        if not file.is_file():raise ValueError('PPT 图像制作缺实际记录：'+file.name)
    data={f.name:contracts.load(f) for f in required}
    from jsonschema import Draft7Validator
    Draft7Validator(contracts.load(Path(bundle()['root'])/'assets/diff_report.schema.json')).validate(data['diff_report.json'])
    audits={r['page']:r for r in data['audit_result.json'].get('results',[])}
    promoted={r['page']:Path(r['to']).resolve() for r in data['promotion_log.json'].get('promoted',[])}
    entries={r['page']:r for r in data['diff_report.json']['files']}
    literal=data['literal_transcription.json'].get('pages',data['literal_transcription.json'])
    ocr=data['ocr_extracts.json'].get('pages',data['ocr_extracts.json'])
    visual=data['visual_qa.json'].get('pages',data['visual_qa.json'])
    images=[]
    for page in selected:
        ident=page['page_id'];audit=audits.get(ident,{})
        if render.mode_for(page,route)!='full_image':raise ValueError(ident+': 选配 PPT 使用内置 ppt-image-render 整页图像路线')
        if audit.get('verdict')!='pass' or visual.get(ident,{}).get('verdict')!='pass':raise ValueError(ident+': 图像内容或视觉审计尚未通过')
        for layer in rules()['audit_layers']:
            actual=audit.get(layer,{})
            if (actual.get('ok') is not True if layer=='layer_2_5_resolution' else actual.get('verdict')!='pass'):raise ValueError(ident+': 缺完整通过的图像审计层 '+layer)
        miss=audit['layer_1_content_qa'].get('miss_rate')
        if not isinstance(miss,(int,float)) or not 0<=miss<rules()['limits']['content_miss_rate_exclusive_max']:raise ValueError(ident+': 图像文字缺失率未满足契约阈值')
        if not literal.get(ident,{}).get('fields') or not ocr.get(ident,{}).get('ocr_text'):raise ValueError(ident+': 缺实际逐字转写或 OCR')
        if entries.get(ident,{}).get('source_hash')!='sha256:'+model.sha(root/'00_source'/f'{ident}.md') or entries.get(ident,{}).get('prompt_hash')!='sha256:'+model.sha(root/'02_render_prompt'/f'{ident}.prompt.md'):raise ValueError(ident+': 审计对应的源文或提示词已变化')
        asset=page.get('visual',{}).get('background_asset_id')
        if not asset:raise ValueError(ident+': 登记审计后晋级的整页图片 background_asset_id')
        image,_,_=render.image_asset(work,plan,asset)
        if ident not in promoted or image.resolve()!=promoted[ident] or not image.resolve().is_relative_to((root/'04_output/images').resolve()):raise ValueError(ident+': 页面未使用实际晋级图像')
        if visual[ident].get('image_sha256')!=model.sha(image):raise ValueError(ident+': 视觉审计未绑定当前图像哈希')
        if literal[ident].get('image_sha256')!=model.sha(image) or ocr[ident].get('image_sha256')!=model.sha(image):raise ValueError(ident+': 转写或 OCR 未绑定当前图像哈希')
        images.append(model.proof(image))
    return {'method':bundle()['contract'],'job':model.proof(Path(work)/rules()['job_pointer']),'files':job['files']+[model.proof(f) for f in required]+images}

def validate_deck(work,project,plan,deck,destination,selected):
    root,_=read_job(work,project,plan);target=Path(destination)/'image-method-file-qa.json'
    # Upstream validator counts source files; calibration uses an explicit subset.
    pages_dir=root/'00_source'
    if len(selected)!=len(plan['pages']):
        pages_dir=Path(destination)/'calibration-sources';pages_dir.mkdir()
        for page in selected:(pages_dir/(page['page_id']+'.md')).write_bytes((root/'00_source'/(page['page_id']+'.md')).read_bytes())
    invoke(bundle()['root'],'validate_deck.py',['--pptx',deck,'--pages-dir',pages_dir,'--out',target],Path(destination)/'image-method-validate-command.json')
    return model.proof(target)

def recorded_issues(evidence):
    problems=[]
    try:bundle()
    except ValueError as exc:problems.append(str(exc))
    for item in [evidence.get('method'),evidence.get('job'),*evidence.get('files',[])]:
        if not item or not Path(item['path']).is_file() or model.sha(item['path'])!=item['sha256']:problems.append('PPT 内置方法制作证据缺失或变化')
    return problems
