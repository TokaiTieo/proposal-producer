"""A4 written Proposal planning, native Word authoring and actual document checks.

Deck planning remains a separate optional branch. SOW never supplies missing
required argument in the main written Proposal.
"""
from datetime import datetime,timezone
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json,re
import xml.etree.ElementTree as ET
import contracts
import proposal_model as model
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS={'w':W}

def rules():return contracts.validate(contracts.load(contracts.ROOT/'contracts/written-proposal.json'),'written-proposal.schema.json')
def layout_limits(project):return {**contracts.policy()['visual'],**project.get('threshold_overrides',{})}
def has_proposal(project):return bool({'proposal_docx','proposal_pdf'}&set(project['outputs']))
def plan_path(work,project):return model.resolve(work,project.get('document_plan') or 'document-plan.json')
def plan(work,project):
    import client_content
    raw=contracts.validate(contracts.load(plan_path(work,project)),'document-plan.schema.json')
    return client_content.customer_view(work,project,'document_plan',raw)
def form_issues(project):
    issues=[];outputs=set(project['outputs']);active=model.requirements(project)
    if {'pptx','ppt_pdf'}&outputs:
        if not project.get('presentation_requested'):issues.append('V09: 汇报版未由 presentation_requested 启用')
        elif not any(r['origin']=='user_instruction' and r['scope']=='outputs' and {'pptx','ppt_pdf'}&set(r['affected_outputs']) for r in active):issues.append('V09: 汇报版缺用户明确要求的记录')
    if {'sow_docx','sow_pdf'}&outputs:
        if not project.get('sow_required'):issues.append('V09: 独立 SOW 未由 sow_required 启用')
        elif not any(r['origin']=='user_instruction' and r['scope']=='outputs' and {'sow_docx','sow_pdf'}&set(r['affected_outputs']) for r in active):issues.append('V09: 独立 SOW 缺用户要求的记录')
    if project.get('task_scope','complete_proposal')=='complete_proposal' and not {'proposal_docx','proposal_pdf'}<=outputs:issues.append('V09: 完整书面 Proposal 必须有 DOCX+PDF，独立选配文件不能替代')
    if project.get('task_scope')=='partial_artifact' and not any(r['origin']=='user_instruction' and r['scope']=='outputs' for r in active):issues.append('V09: 局部交付缺用户明确选择的范围依据')
    return issues

def plan_issues(work,project):
    issues=form_issues(project)
    if not has_proposal(project):return issues
    file=plan_path(work,project)
    if not file.is_file():return issues+['书面 Proposal 缺 document-plan.json 章节计划']
    data=plan(work,project);content=model.base(work);units={u['id']:u for u in content['semantic_units']};sections={};covered=set();assets={a['asset_id'] for a in project.get('visual_assets',[])}
    for chapter in data['chapters']:
        ident=chapter['section_id']
        if ident in sections:issues.append('章节 ID 重复 '+ident)
        sections[ident]=chapter
        if not chapter['purpose']:issues.append(ident+': 章节目的待填写')
        if set(chapter['source_refs'])-set(units):issues.append(ident+': 章节引用未知论证单元')
        if not chapter['source_refs']:issues.append(ident+': 章节缺共同论证来源')
        covered.update(chapter['source_refs'])
        for block in chapter['blocks']:
            if block['kind']=='argument' and set(block['unit_refs'])-set(chapter['source_refs']):issues.append(ident+': 段落引用超出本章共同论证')
            if block['kind']=='figure' and block['asset_ref'] not in assets:issues.append(ident+': 图片未登记来源 '+block['asset_ref'])
            if block['kind']=='table' and (not block['columns'] or any(len(row)!=len(block['columns']) for row in block['rows'])):issues.append(ident+': 表格列数不一致')
    if {u['id'] for u in units.values() if u['required_for_decision']}-covered:issues.append('必需论证尚未进入书面章节计划')
    for row in project['artifact_projection']:
        if row['artifact_role'] not in ['proposal_docx','proposal_pdf']:continue
        chapter=sections.get(row['section_or_page'])
        if not chapter or set(row['source_refs'])-set(chapter['source_refs']):issues.append('书面投影与章节计划不一致 '+row['section_or_page'])
    meta=project.get('document_metadata') or {}
    for key in ['title','author','date']:
        if not meta.get(key):issues.append('书面文档元数据待补 '+key)
    if meta.get('date'):
        try:datetime.fromisoformat(meta['date'][:10])
        except ValueError:issues.append('文档日期使用 ISO 日期')
    if any(value in str(meta.values()) for value in rules()['metadata_forbidden_values']):issues.append('文档元数据包含参考稿或生成器占位内容')
    return issues

def field(paragraph,instruction,result='1'):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    instruction=instruction.replace('\\\\','\\')
    run=paragraph.add_run();begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin');run._r.append(begin)
    run=paragraph.add_run();code=OxmlElement('w:instrText');code.set(qn('xml:space'),'preserve');code.text=' '+instruction+' ';run._r.append(code)
    sep=OxmlElement('w:fldChar');sep.set(qn('w:fldCharType'),'separate');paragraph.add_run()._r.append(sep)
    paragraph.add_run(result)
    end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end');paragraph.add_run()._r.append(end)

def clean_styles(document,profile,fonts,project=None):
    from docx.shared import Pt,Mm,RGBColor
    from docx.oxml.ns import qn
    from docx.enum.style import WD_STYLE_TYPE
    limits=layout_limits(project or {})
    if 'Source' not in document.styles:document.styles.add_style('Source',WD_STYLE_TYPE.PARAGRAPH)
    for section in document.sections:
        section.page_width=Mm(limits['page_width_mm']);section.page_height=Mm(limits['page_height_mm'])
        section.top_margin=section.bottom_margin=section.left_margin=section.right_margin=Mm(limits['margin_min_mm'])
        section.header_distance=section.footer_distance=Mm(10)
    sizes={'Normal':max(limits['body_font_pt'],limits['body_min_pt']),'Title':26,'Subtitle':12,'Heading 1':max(limits['heading1_font_pt'],limits['heading1_min_pt']),'Heading 2':max(limits['heading2_font_pt'],limits['heading2_min_pt']),'Heading 3':max(limits['heading3_font_pt'],limits['heading3_min_pt']),'Caption':limits['caption_min_pt'],'Source':limits['source_min_pt']}
    for name,size in sizes.items():
        style=document.styles[name];style.font.name=fonts['body']['actual_family'];style.font.size=Pt(size);style.font.color.rgb=RGBColor(0,0,0)
        for border in list(style.element.xpath('.//w:pBdr')):border.getparent().remove(border)
        rpr=style.element.get_or_add_rPr();rf=rpr.rFonts
        for attr in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:rf.attrib.pop(qn('w:'+attr),None)
        for attr in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+attr),fonts['body']['actual_family'])
        pf=style.paragraph_format;pf.line_spacing=limits['line_spacing'];pf.space_after=Pt(7 if name=='Normal' else 9)
        if name.startswith('Heading'):pf.keep_with_next=True;pf.space_before=Pt(14)
    for name in ['Header','Footer']:
        style=document.styles[name];style.font.name=fonts['body']['actual_family'];style.font.size=Pt(limits['source_min_pt']);style.font.color.rgb=RGBColor(0,0,0)

def metadata_and_running(document,project,role):
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    meta=project['document_metadata'];core=document.core_properties
    core.title=meta['title']+(' — Statement of Work' if role=='sow_docx' else '');core.author=meta['author'];core.subject=meta.get('subject') or '';core.comments='';core.keywords='';core.last_modified_by=meta['author']
    date=datetime.fromisoformat(meta['date'][:10]).replace(tzinfo=timezone.utc);core.created=date;core.modified=date
    settings=document.settings.element;old=settings.find(qn('w:updateFields'))
    if old is None:old=OxmlElement('w:updateFields');settings.append(old)
    old.set(qn('w:val'),'true')
    for section in document.sections:
        header=section.header.paragraphs[0];header.text=core.title+(' | '+str(project['shared_facts']['version']) if (project.get('shared_facts') or {}).get('version') else '')
        footer=section.footer.paragraphs[0];footer.text='';footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        footer.add_run(meta['date'][:10]+'  |  ');field(footer,'PAGE','1')

def bookmark(paragraph,ident,number):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    existing=[int(v) for v in paragraph.part.element.xpath('.//w:bookmarkStart/@w:id')]
    number=max(number,max(existing,default=-1)+1)
    begin=OxmlElement('w:bookmarkStart');begin.set(qn('w:id'),str(number));begin.set(qn('w:name'),ident)
    end=OxmlElement('w:bookmarkEnd');end.set(qn('w:id'),str(number));paragraph._p.insert(0,begin);paragraph._p.append(end)

def toc(document,chapters,language):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Inches
    heading=document.add_paragraph('目录' if language=='zh' else 'Contents',style='Title')
    p=document.add_paragraph();begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin');p.add_run()._r.append(begin)
    code=OxmlElement('w:instrText');code.set(qn('xml:space'),'preserve');code.text=' TOC \\o "1-3" \\h \\z \\u ';p.add_run()._r.append(code)
    sep=OxmlElement('w:fldChar');sep.set(qn('w:fldCharType'),'separate');p.add_run()._r.append(sep)
    for i,chapter in enumerate(chapters,1):
        row=document.add_paragraph();row.style=document.styles['Normal'];row.paragraph_format.tab_stops.add_tab_stop(Inches(6.1),2,1)
        row.add_run(chapter['section_id']+' '+chapter['title']+'\t');field(row,'PAGEREF _proposal_'+str(i)+' \\h','1')
    end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end');document.add_paragraph().add_run()._r.append(end)
    document.add_page_break()

def native_table(document,columns,rows,caption,project,number,cross_reference=False):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt,RGBColor
    language=model.client_language(project['_workdir']);p=document.add_paragraph(style='Caption');p.paragraph_format.keep_with_next=True
    p.add_run('表 ' if language=='zh' else 'Table ');field(p,'SEQ Table \\* ARABIC',str(number))
    bookmark(p,'_proposal_table_'+str(number),1000+number);p.add_run(' '+model.resolve_text(project,caption))
    if cross_reference:
        reference=document.add_paragraph();reference.paragraph_format.keep_with_next=True
        reference.add_run('见' if language=='zh' else 'See ');field(reference,'REF _proposal_table_'+str(number)+' \\h',('表 ' if language=='zh' else 'Table ')+str(number));reference.add_run('。' if language=='zh' else '.')
        p._p.addprevious(reference._p)
    table=document.add_table(rows=1,cols=len(columns));table.style='Table Grid'
    style=rules()['table_layout'];section=document.sections[-1];available=int(section.page_width-section.left_margin-section.right_margin)
    weights=[max(len(str(v)) for v in [columns[i]]+[r[i] for r in rows])**.5 for i in range(len(columns))]
    minimum=min(style['min_column_fraction'],1/len(columns));remaining=1-minimum*len(columns);fractions=[minimum+remaining*w/sum(weights) for w in weights]
    table.autofit=False
    for column,fraction in zip(table.columns,fractions):column.width=round(available*fraction)
    for cell,value in zip(table.rows[0].cells,columns):cell.text=model.resolve_text(project,value)
    repeat=OxmlElement('w:tblHeader');repeat.set(qn('w:val'),'true');table.rows[0]._tr.get_or_add_trPr().append(repeat)
    for values in rows:
        for cell,value in zip(table.add_row().cells,values):cell.text=model.resolve_text(project,value)
    for row_index,row in enumerate(table.rows):
        no_split=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(no_split)
        for col_index,cell in enumerate(row.cells):
            cell.width=round(available*fractions[col_index]);props=cell._tc.get_or_add_tcPr();margins=OxmlElement('w:tcMar')
            for side,mm in style['cell_margins_mm'].items():
                tag=OxmlElement('w:'+side);tag.set(qn('w:w'),str(round(mm*1440/25.4)));tag.set(qn('w:type'),'dxa');margins.append(tag)
            props.append(margins);borders=OxmlElement('w:tcBorders')
            for side in ['top','bottom','left','right']:
                border=OxmlElement('w:'+side);border.set(qn('w:val'),'single');border.set(qn('w:sz'),str(style['border_eighth_pt']));border.set(qn('w:color'),style['border_color']);borders.append(border)
            props.append(borders)
            if row_index==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),style['header_fill']);props.append(shade)
            for p in cell.paragraphs:
                if row_index==0:p.paragraph_format.keep_with_next=True
                for run in p.runs:
                    run.font.size=Pt(max(layout_limits(project)['table_cell_min_pt'],layout_limits(project)['table_font_pt']))
                    if row_index==0:run.bold=style['header_bold'];run.font.color.rgb=RGBColor.from_string(style['header_text_color'])
    document.add_paragraph()

def author(work,project,destination,profile,fonts):
    from docx import Document
    from docx.shared import Inches
    import render_adapter as render
    import client_content as client
    project=client.customer_view(work,project,'project',project)
    data=plan(work,project);document=Document();clean_styles(document,profile,fonts,project);metadata_and_running(document,project,'proposal_docx');language=model.client_language(work)
    meta=project['document_metadata'];document.add_paragraph(meta['title'],style='Title');document.add_paragraph(project.get('audience') or '',style='Subtitle');document.add_paragraph(meta['author']);document.add_paragraph(meta['date'][:10]);document.add_paragraph((project.get('shared_facts') or {}).get('version') or '');document.add_page_break();toc(document,data['chapters'],language)
    units={u['id']:u for u in model.base(work)['semantic_units']};assets={a['asset_id']:a for a in project.get('visual_assets',[])};bindings=[];table_number=figure_number=0
    project_view={**project,'_workdir':str(work)}
    for index,chapter in enumerate(data['chapters'],1):
        head=document.add_paragraph(chapter['section_id']+' '+chapter['title'],style='Heading 1');bookmark(head,'_proposal_'+str(index),index)
        row=next((r for r in model.projection_rows(project,'proposal_docx') if r['section_or_page']==chapter['section_id']),None)
        # Same-family icons and registered chapter assets stay observable.
        view={'_workdir':str(work),'_shared_units':units};icon_project=copy.deepcopy(project)
        for projected in icon_project['artifact_projection']:projected['asset_refs']=[]
        render.add_document_assets(document,head,icon_project,view,destination,profile,'proposal_docx',chapter['section_id'],index-1,bindings)
        emitted=set();emitted_citations=set()
        emitted_assets=set()
        def sources(refs):
            for text in client.citations(work,refs):
                if text not in emitted_citations:document.add_paragraph(text,style='Source');emitted_citations.add(text)
        def picture(ident,caption,cross_reference=False):
            nonlocal figure_number
            source,dimensions,item=render.image_asset(work,{'visual_assets':list(assets.values())},ident)
            document.add_picture(str(source),width=Inches(min(6.0,5.8*dimensions[0]/dimensions[1])));figure_number+=1;emitted_assets.add(ident)
            document.paragraphs[-1].paragraph_format.keep_with_next=True
            p=document.add_paragraph(style='Caption');p.add_run('图 ' if language=='zh' else 'Figure ');field(p,'SEQ Figure \\* ARABIC',str(figure_number))
            bookmark(p,'_proposal_figure_'+str(figure_number),2000+figure_number);p.add_run(' '+model.resolve_text(project,caption))
            if cross_reference:
                reference=document.add_paragraph();reference.add_run('见' if language=='zh' else 'See ');field(reference,'REF _proposal_figure_'+str(figure_number)+' \\h',('图 ' if language=='zh' else 'Figure ')+str(figure_number));reference.add_run('。' if language=='zh' else '.')
            bindings.append({'artifact_role':'proposal_docx','section_or_page':chapter['section_id'],'asset_id':ident,'feature':'output_examples' if item['identity']=='product_screenshot' else 'scene_assets','source':model.proof(source),'identity':item['identity'],'dimensions':dimensions})
        def arguments(refs):
            for ident in refs:
                if ident in emitted:continue
                emitted.add(ident)
                for value in model.unit_texts(project,units[ident],model.projection_summary(row) if row else None,work,'proposal_docx',chapter['section_id']):
                    for paragraph in value.split('\n\n'):
                        if paragraph.strip():
                            p=document.add_paragraph(paragraph.strip())
                            if len(paragraph.split())<=rules()['table_layout']['paragraph_keep_together_max_words']:p.paragraph_format.keep_together=True
        for block in chapter['blocks']:
            if block['kind']=='argument':arguments(block['unit_refs'])
            elif block['kind']=='heading':document.add_paragraph(model.resolve_text(project,block['text']),style='Heading '+str(block['level']))
            elif block['kind']=='table':table_number+=1;native_table(document,block['columns'],block['rows'],block['caption'],project_view,table_number,block.get('cross_reference',False))
            elif block['kind']=='figure':
                picture(block['asset_ref'],block['caption'],block.get('cross_reference',False))
            if client.active(project) and block.get('evidence_refs'):
                sources(block['evidence_refs'])
        arguments([r for r in chapter['source_refs'] if r not in emitted])
        if client.active(project):
            for value in client.located_disclosures(work,project,'proposal_docx',chapter['section_id']):document.add_paragraph(value)
            refs=[ref for ident in chapter['source_refs'] for ref in units[ident]['evidence_refs']]
            sources(refs)
        for ident in (row or {}).get('asset_refs',[]):
            if ident not in emitted_assets:
                if client.active(project) and not assets[ident].get('client_caption'):raise ValueError('CC02: 客户图片需要 client_caption '+ident)
                picture(ident,assets[ident].get('client_caption') or assets[ident]['source_description'])
    document.save(destination);Document(destination)
    return bindings

def add_sources(work,project,destination,report,profile,fonts,calculation):
    import render_adapter as render
    from docx import Document
    if has_proposal(project):
        file=Path(destination)/'written-proposal.docx';bindings=author(work,project,file,profile,fonts);report['runtime'].setdefault('asset_bindings',[]).extend(bindings);report['source_files']['proposal_docx']=model.proof(file)
    if {'sow_docx','sow_pdf'}&set(project['outputs']):
        if project.get('schema',0)>=7:
            import production_chain,shutil
            production_chain.enforce(work,project,'sow');source=production_chain.read(work,project)['sow']['file'];file=Path(destination)/'sow.docx';shutil.copy2(source['path'],file);report['source_files']['sow_docx']=model.proof(file)
            report['runtime']['document_plan_sha256']=model.sha(plan_path(work,project)) if has_proposal(project) else None
            return
        file=Path(destination)/'sow.docx';content=model.base(work);view={'_workdir':str(work),'_shared_units':{u['id']:u for u in content['semantic_units']},'project_label':project['document_metadata']['title']+' — Statement of Work','deliverables':[],'fee_value_mappings':content['fee_value_mappings']}
        render.build_sow(project,view,file,profile,fonts,calculation,asset_bindings=report['runtime'].setdefault('asset_bindings',[]))
        d=Document(file);clean_styles(d,profile,fonts,project);metadata_and_running(d,project,'sow_docx');d.save(file);report['source_files']['sow_docx']=model.proof(file)
    report['runtime']['document_plan_sha256']=model.sha(plan_path(work,project)) if has_proposal(project) else None

def build(work,project,destination):
    import render_adapter as render
    from proposal import calculate
    work=Path(work).resolve();destination=Path(destination).resolve()
    if project.get('schema',0)>=7:
        import production_chain
        production_chain.enforce(work,project,'proposal')
    if destination.exists():raise ValueError('候选目录已存在，选择新版本位置')
    issues=model.model_issues(work,project)+plan_issues(work,project)
    if issues:raise ValueError('；'.join(dict.fromkeys(issues)))
    calculation=calculate(project)
    if calculation['issues']:raise ValueError('；'.join(calculation['issues']))
    destination.mkdir(parents=True)
    try:
        profile,route,a,b=render.task_config(work,project);fonts,_=render.font_map(profile,route,destination/'font-environment')
        if not all(v['available'] for v in fonts.values()):raise ValueError('书面字体未匹配；运行 doctor 并选择实际字体')
        report={'schema':1,'plan_sha256':model.sha(plan_path(work,project)) if has_proposal(project) else model.sha(work/'content-base.json'),'profile_sha256':model.sha(a),'render_policy_sha256':model.sha(b),'project_sha256':model.sha(work/'project.json'),'model_digest':model.digest({'base':model.base(work),'story':model.story(work)}),'directory':str(destination),'source_files':{},'pages':[],'exports':{},'runtime':{'fonts':fonts,'planning_source':'document-plan.json','catalogue':model.proof(contracts.ROOT/'assets/visual-kit/catalog.json'),'source_reopen':'python-docx round trip'},'status':'candidate'}
        if project.get('schema',0)>=7:report['runtime'].update(production_stage='proposal',source_business_digest=production_chain.business_digest(project))
        add_sources(work,project,destination,report,profile,fonts,calculation);model.save(destination/'render-manifest.json',report);model.save(work/'render-manifest.json',report);return report
    except Exception as exc:model.save(destination/'failure.json',{'status':'failed','error':str(exc)});raise

def inspect_docx(file):
    from docx import Document
    from docx.oxml.ns import qn
    d=Document(file);all_paragraphs=list(d.paragraphs)+[p for t in d.tables for r in t.rows for c in r.cells for p in c.paragraphs]
    def inherited(p,attr):
        value=getattr(p.paragraph_format,attr)
        style=p.style
        while value is None and style is not None:value=getattr(style.paragraph_format,attr);style=style.base_style
        return value
    def size(run,p):
        if run.font.size is not None:return run.font.size.pt
        style=p.style
        while style:
            if style.font.size is not None:return style.font.size.pt
            style=style.base_style
        return None
    body=[];heading={1:[],2:[],3:[]};lines=[];lengths=[];table_sizes=[];caption_sizes=[];heading_levels=[]
    for p in all_paragraphs:
        if not p.text.strip():continue
        name=p.style.name.lower();level=next((i for i in [1,2,3] if name=='heading '+str(i)),None)
        in_table=any(a.tag.endswith('}tbl') for a in p._p.iterancestors())
        if in_table:table_sizes += [size(r,p) for r in p.runs if r.text.strip() and size(r,p) is not None]
        if name=='caption':caption_sizes += [size(r,p) for r in p.runs if r.text.strip() and size(r,p) is not None]
        if level and not in_table:heading_levels.append(level)
        target=heading[level] if level else body if name=='normal' and not in_table else []
        target += [size(r,p) for r in p.runs if r.text.strip() and size(r,p) is not None]
        if name=='normal' and not in_table:
            spacing=inherited(p,'line_spacing');lines.append(spacing if isinstance(spacing,float) else None)
            lengths.append({'words':len(p.text.split()),'cjk':len(re.findall(r'[\u3400-\u9fff]',p.text))})
    with ZipFile(file) as z:
        root=ET.fromstring(z.read('word/document.xml'));core=ET.fromstring(z.read('docProps/core.xml'));app=ET.fromstring(z.read('docProps/app.xml'));header=''.join(z.read(n).decode() for n in z.namelist() if re.fullmatch(r'word/header\d+\.xml',n));footer=''.join(z.read(n).decode() for n in z.namelist() if re.fullmatch(r'word/footer\d+\.xml',n))
        props={ET.QName(n.tag).localname if hasattr(ET.QName(n.tag),'localname') else n.tag.split('}')[-1]:n.text for n in core}
        app_props={n.tag.split('}')[-1]:n.text for n in app};fields=root.findall('.//w:instrText',NS);codes=[x.text or '' for x in fields]
    normal=list(d.paragraphs);body_start=next((i for i,p in enumerate(normal) if p.style.name.lower()=='heading 1'),len(normal));body_paragraphs=normal[body_start:]+[p for t in d.tables for row in t.rows for cell in row.cells for p in cell.paragraphs]
    body_words=sum(len(p.text.split()) for p in body_paragraphs);body_cjk=sum(len(re.findall(r'[\u3400-\u9fff]',p.text)) for p in body_paragraphs);toc_words=sum(len(p.text.split()) for p in normal if any('PAGEREF' in (n.text or '') for n in p._p.xpath('.//w:instrText')))
    return {'a4_sections':[{'width_mm':s.page_width.mm,'height_mm':s.page_height.mm,'margins_mm':[s.top_margin.mm,s.bottom_margin.mm,s.left_margin.mm,s.right_margin.mm]} for s in d.sections],'body_min_pt':min(body) if body else None,'heading_min_pt':{str(k):min(v) if v else None for k,v in heading.items()},'heading_levels':heading_levels,'heading1_text':[p.text for p in d.paragraphs if p.style.name.lower()=='heading 1'],'styles_present':[name for name in ['Heading 1','Heading 2','Heading 3'] if name in d.styles],'line_spacing_values':lines,'paragraph_lengths':lengths,'body_word_count':body_words,'body_cjk_character_count':body_cjk,'toc_word_count':toc_words,'word_count':sum(len(p.text.split()) for p in all_paragraphs),'cjk_character_count':sum(len(re.findall(r'[\u3400-\u9fff]',p.text)) for p in all_paragraphs),'table_count':len(d.tables),'table_cell_min_pt':min(table_sizes) if table_sizes else None,'caption_min_pt':min(caption_sizes) if caption_sizes else None,'figure_count':sum(s.width.inches>.6 for s in d.inline_shapes),'caption_count':sum(p.style.name=='Caption' for p in d.paragraphs),'toc_field':any(re.match(r'\s*TOC\b',c) for c in codes),'pageref_fields':[c for c in codes if 'PAGEREF' in c],'header_present':bool(header),'footer_present':bool(footer),'page_field':'PAGE' in footer,'metadata':props,'cached_pages':int(app_props.get('Pages') or 0),'document_xml':root,'paragraphs':d.paragraphs}

def check_file(file,project,role='proposal_docx',export=None):
    measured=inspect_docx(file);limits=layout_limits(project);issues=[];warnings=[]
    for s in measured['a4_sections']:
        if abs(s['width_mm']-limits['page_width_mm'])>limits['page_geometry_tolerance_mm'] or abs(s['height_mm']-limits['page_height_mm'])>limits['page_geometry_tolerance_mm']:issues.append('V01: 书面文档不是 A4')
        if min(s['margins_mm'])+.01<limits['margin_min_mm']:issues.append('V03: A4 页边距不足')
    if measured['body_min_pt'] is not None and measured['body_min_pt']+.01<limits['body_min_pt']:issues.append('V01: 正文字号低于书面阈值')
    for level,size in measured['heading_min_pt'].items():
        if size is not None and size<limits['heading'+level+'_min_pt']:issues.append('V01: Heading '+level+' 字号不足')
    if any(x is None or not limits['line_spacing_min']<=x<=limits['line_spacing_max'] for x in measured['line_spacing_values']):issues.append('V01: 正文行距不符合书面范围')
    if role=='proposal_docx':
        if len(measured['styles_present'])!=3 or not measured['heading1_text']:issues.append('V01: 章节未使用完整的 Heading 样式体系')
        if not measured['toc_field'] or not measured['pageref_fields']:issues.append('V05: 缺自动目录与实际章节引用')
        if not measured['page_field'] or not measured['header_present'] or not measured['footer_present']:issues.append('V05: 缺页码或页眉页脚')
        if measured['caption_count']<measured['table_count']+measured['figure_count']:issues.append('V02: 表格或图片缺题注')
        previous=0
        for level in measured['heading_levels']:
            if level>previous+1:issues.append('V02: 标题层级跳级');break
            previous=level
    if measured['table_cell_min_pt'] is not None and measured['table_cell_min_pt']<limits['table_cell_min_pt']:issues.append('V02: 表格字号不足')
    if measured['caption_min_pt'] is not None and measured['caption_min_pt']<limits['caption_min_pt']:issues.append('V02: 题注字号不足')
    meta=project.get('document_metadata') or {};observed=measured['metadata'];title=meta.get('title')+(' — Statement of Work' if role=='sow_docx' else '') if meta.get('title') else None
    if observed.get('title')!=title or observed.get('creator')!=meta.get('author') or not str(observed.get('created','')).startswith(str(meta.get('date',''))[:10]):issues.append('V05: title/author/date 与任务元数据不一致')
    if any(v in str(observed) for v in rules()['metadata_forbidden_values']):issues.append('V05: 存在参考稿或生成器元数据')
    if any(r['words']>limits['paragraph_max_words'] or r['cjk']>limits['paragraph_max_chars'] for r in measured['paragraph_lengths']):warnings.append('V02: 长段落需检查可读性或说明保留理由')
    if export:
        if export.get('source_layout_sha256')!=model.sha(file):issues.append('V05: DOCX 源稿与实际导出依据已不一致')
        if measured['cached_pages']!=export['pages']:issues.append('V05: DOCX 实际排版页数与 PDF 不一致')
        if not export.get('toc_verified') and role=='proposal_docx':issues.append('V05: 自动目录未与实际导出页码核对')
        if role=='proposal_docx':
            depth=contracts.policy()['depth'][project['depth']];pages=export['pages']
            if not depth['min_pages']<=pages<=depth['max_pages']:warnings.append('书面页数偏离所选深度的建议范围；记录内容理由，不凑页')
            if not measured['body_cjk_character_count'] and not depth['min_words']<=measured['body_word_count']<=depth['max_words']:warnings.append('英文正文词数偏离建议范围；目录另列，记录展开理由')
    public={k:v for k,v in measured.items() if k not in ['document_xml','paragraphs']}
    return {'status':'blocked' if issues else 'passed','issues':issues,'warnings':warnings,'measurements':public}


def update_app_pages(file,count):
    with ZipFile(file) as z:entries={n:z.read(n) for n in z.namelist()}
    root=ET.fromstring(entries['docProps/app.xml']);ns=root.tag.split('}')[0]+'}';pages=root.find(ns+'Pages')
    if pages is None:pages=ET.SubElement(root,ns+'Pages')
    pages.text=str(count);entries['docProps/app.xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    with ZipFile(file,'w',ZIP_DEFLATED) as z:
        for n,data in entries.items():z.writestr(n,data)

def toc_pages_from_pdf(project,work,pdf):
    from pypdf import PdfReader
    chapters=plan(work,project)['chapters'];reader=PdfReader(pdf);pages={}
    for chapter in chapters:
        needle=model.normalize(chapter['section_id']+' '+chapter['title']);found=[]
        for index,p in enumerate(reader.pages,1):
            if needle in model.normalize(p.extract_text() or ''):found.append(index)
        if not found:raise ValueError('实际 PDF 未定位章节 '+chapter['section_id'])
        pages[chapter['section_id']]=found[-1]
    return pages

def refresh_toc_cache(file,chapters,pages):
    from docx import Document
    from docx.oxml.ns import qn
    d=Document(file);changed=False
    for i,chapter in enumerate(chapters,1):
        for p in d.paragraphs:
            if any('_proposal_'+str(i)+' ' in (n.text or '') for n in p._p.xpath('.//w:instrText')):
                target=str(pages[chapter['section_id']]);text_nodes=p._p.xpath('.//w:t');node=text_nodes[-1]
                if node.text!=target:node.text=target;changed=True
    if changed:d.save(file)
    return changed


def finalize_export(work,project,role,source,record,converter,exported,env):
    """Update real TOC field caches from actual pagination, then re-export."""
    import render_adapter as render
    from pypdf import PdfReader
    if role=='proposal_docx':
        chapters=plan(work,project)['chapters']
        for attempt in range(rules()['toc_max_export_passes']):
            current=toc_pages_from_pdf(project,work,record['file']['path'])
            if not refresh_toc_cache(source,chapters,current):break
            render.run([converter,'--headless','--convert-to','pdf','--outdir',exported,source],env=env,timeout=120)
            record['file']=model.proof(exported/(source.stem+'.pdf'));record['pages']=len(PdfReader(record['file']['path']).pages)
        else:raise ValueError('自动目录与实际分页未稳定')
        record['toc_pages']=current;record['toc_verified']=True
    from pypdf import PdfWriter
    pdf=Path(record['file']['path']);reader=PdfReader(pdf);writer=PdfWriter();writer.clone_document_from_reader(reader)
    metadata={str(k):str(v) for k,v in (reader.metadata or {}).items()};meta=project['document_metadata'];title=meta['title']+(' — Statement of Work' if role=='sow_docx' else '')
    date='D:'+meta['date'][:10].replace('-','')+'000000Z';metadata.update({'/Title':title,'/Author':meta['author'],'/Subject':meta.get('subject') or '', '/CreationDate':date,'/ModDate':date,'/ProposalDate':meta['date'][:10]});writer.add_metadata(metadata)
    normalized=pdf.with_suffix('.metadata.pdf')
    with normalized.open('wb') as stream:writer.write(stream)
    normalized.replace(pdf);record['file']=model.proof(pdf)
    update_app_pages(source,record['pages']);record['source_layout_sha256']=model.sha(source);record['pagination_method']='Actual Office PDF export; source page cache recorded after pagination; body and layout unchanged.'
    return record

def verify_exports(work,project,report):
    from pypdf import PdfReader
    issues=[];documents={};limits=layout_limits(project)
    if has_proposal(project) and report['runtime'].get('document_plan_sha256')!=model.sha(plan_path(work,project)):issues.append('书面章节计划与实际制作清单不一致')
    for role,item in report['source_files'].items():
        if role not in ['proposal_docx','sow_docx'] or not Path(item['path']).is_file():continue
        target='proposal_pdf' if role=='proposal_docx' else 'sow_pdf';entry=report['exports'].get(target)
        documents[role]=check_file(item['path'],project,role,entry);issues+=documents[role]['issues']
        if not entry or not Path(entry['file']['path']).is_file():continue
        pdf=PdfReader(entry['file']['path'])
        if len(pdf.pages)!=entry['pages']:issues.append('V05: 实际 PDF 页数与排版记录不一致')
        for page in pdf.pages:
            w,h=float(page.mediabox.width)*25.4/72,float(page.mediabox.height)*25.4/72
            if abs(w-limits['page_width_mm'])>limits['page_geometry_tolerance_mm'] or abs(h-limits['page_height_mm'])>limits['page_geometry_tolerance_mm']:issues.append('V01: 实际 PDF 页框不是 A4');break
        observed=pdf.metadata or {};expected=project['document_metadata'];title=expected['title']+(' — Statement of Work' if role=='sow_docx' else '')
        if observed.get('/Title')!=title or observed.get('/Author')!=expected['author'] or observed.get('/ProposalDate')!=expected['date'][:10]:issues.append('V07: PDF 元数据与本项目不一致')
        documents[role]['measurements']['pdf_metadata']=dict(observed)
        if role=='proposal_docx':
            actual=toc_pages_from_pdf(project,work,entry['file']['path'])
            if entry.get('toc_pages')!=actual:issues.append('V05: 目录登记与实际 PDF 章节页码不一致')
            from docx import Document
            doc=Document(item['path'])
            for i,chapter in enumerate(plan(work,project)['chapters'],1):
                matches=[p for p in doc.paragraphs if any('_proposal_'+str(i)+' ' in (n.text or '') for n in p._p.xpath('.//w:instrText'))]
                if not matches or matches[0]._p.xpath('.//w:t')[-1].text!=str(actual[chapter['section_id']]):issues.append('V05: 原生目录字段缓存未与实际章节页对应 '+chapter['section_id'])
    return issues,documents
