"""Explicit synthetic fixtures for protocol tests, never project defaults or approvals."""
from pathlib import Path
import copy
import contracts
import proposal_model as model

def prepare(work,kind='product',outputs=None):
    from proposal import save
    work=Path(work);work.mkdir(parents=True,exist_ok=True)
    p=contracts.load(contracts.ROOT/'assets/project.json');p.pop('client_content_policy',None);p.update(schema=5,kind=kind,audience='Synthetic operations owner',decision='Decide a bounded pilot',scope=['One controlled record workflow'],acceptance=['Owner checks traceable pilot records'],project_label='Synthetic Proposal',shared_facts={'date':'2026-10-27','version':'fixture-0.5','period_months':12 if kind=='quote' else None},outputs=outputs or ['proposal_md'],decision_context={'requested_action':'Decide a bounded pilot','commitment_scope':'pilot','evidence_expectation':'Clear value hypothesis, limited scope and validation plan','source_requirement_refs':['RQ1']},work_packages=[{'id':'W1','title':'Controlled pilot','sow_anchor':'S01'}],sow_sections=[{'anchor':'S01','title':'Pilot scope','paragraphs':[],'source_fields':['scope','deliverables','acceptance','requirements','milestones']},{'anchor':'S02','title':'Value and decision','paragraphs':[],'source_fields':['decision','business_terms']}],deliverable_details=[{'id':'D1','work_package_id':'W1','name':'Traceable pilot records','acceptance':'Owner checks input and outcome records after the pilot','owner':'Operations owner'}],requirements=[{'id':'REQ1','priority':'P0','work_package_ids':['W1']}])
    if kind=='quote':p['pricing']={'mode':'fixed_inclusive_total','currency':'CNY','inclusive_total':'36000','tax_included':True,'tax_rate':None,'period_months':12,'items':[],'payment_percentages':[]}
    instructions=work/'original-brief.txt';instructions.write_text('SYNTHETIC TEST INPUT ONLY. Produce the selected proposal for an operations owner to decide a bounded pilot. Keep text editable. Use the requested language and preserve the limited pilot decision. Visual choices are task specific.\n')
    p['request_requirements']=[{'id':'RQ1','revision':1,'requirement':'Produce the selected proposal to decide a bounded pilot','origin':'user_instruction','source':{'reference':'synthetic original brief','quote':'Produce the selected proposal for an operations owner to decide a bounded pilot.','evidence':model.proof(instructions)},'status':'active','scope':'business','affected_outputs':p['outputs'][:],'method_or_reference':None}]
    base=contracts.load(contracts.ROOT/'assets/templates/01-content-base.json')
    entries=[('U1',['F01','F02','F03','F04'],'Operations owners need a decision on a controlled workflow pilot.','proposal',None),('U2',['F05','F06','F07'],'Manual next-day summaries make repeated issues harder to notice.','proposal',None),('U3',['F08','F09'],'A record moves from submission through classification to owner review.','proposal',None),('U4',['F10','F11','F12','F13','F16'],'The pilot delivers a traceable record and an owner-led acceptance review.','proposal',None),('U5',['F14'],'Earlier visibility may support earlier owner action.','assumption','Compare recording, alert and review times in the pilot.'),('U6',['F15','F16'],'The selected package total is {{fact:/pricing/inclusive_total}} CNY for the stated period.' if kind=='quote' else 'Resource needs will be estimated before any expansion decision.','proposal',None),('U7',['F17'],'The operations owner manages false alerts and access to records.','proposal',None),('U8',['F18'],'Decide whether to start the bounded pilot and appoint the owner.','proposal',None)]
    needed=set(model.rules()['required_fields'][kind])
    for ident,fields,claim,typ,validation in entries:
        # Optional commercial content stays optional outside an actual quote.
        if ident=='U6' and kind!='quote':continue
        unit={'id':ident,'field_refs':fields,'claim':claim,'kind':typ,'mechanism_refs':[],'evidence_refs':[],'fact_refs':['/pricing/inclusive_total'] if ident=='U6' and kind=='quote' else [],'assumptions':[],'conditions':[],'validation':validation,'decision_relevance':p['decision'],'required_for_decision':True}
        base['semantic_units'].append(unit);base['modules'].append({'id':'MODULE-'+ident,'field_refs':fields,'applicability':'applicable','reason':None,'unit_refs':[ident]})
    if kind=='quote':base['fee_value_mappings']=[{'fee_id':'Q1','project_pointer':'/pricing/inclusive_total','work_package_ids':['W1'],'deliverable_ids':['D1'],'coverage_period':'12 months','included_scope':['Controlled pilot and stated support'],'separate_budget_items':['Expansion scope remains separate'],'value_ids':['U5']}]
    for role in p['outputs']:
        if role in ['pptx','ppt_pdf']:continue
        for unit in base['semantic_units']:
            section='S01' if unit['id'] in ['U1','U2','U3','U4'] else 'S02'
            row=next((r for r in p['artifact_projection'] if r['artifact_role']==role and r['section_or_page']==section),None)
            if row:row['source_refs'].append(unit['id'])
            else:p['artifact_projection'].append({'artifact_role':role,'section_or_page':section,'source_refs':[unit['id']],'summary_and_conditions':None})
    chain=contracts.load(contracts.ROOT/'assets/templates/06-story-map.json');chain['decision_unit_refs']=['U8']
    for a,b in zip(base['semantic_units'],base['semantic_units'][1:]):chain['connections'].append({'id':'E-'+a['id'],'from':a['id'],'to':b['id'],'reason':'The previous point provides context for the next part of the bounded decision.','evidence_refs':[],'assumption_refs':['U5'] if b['id']=='U5' else []})
    for name,value in [('project.json',p),('content-base.json',base),('story-map.json',chain),('visual-profile.json',contracts.load(contracts.ROOT/'assets/visual-profile.json')),('render-policy.json',contracts.load(contracts.ROOT/'assets/render-policy.json')),('state.json',{'schema':2,'producer':'SYNTHETIC-PRODUCER','created':'synthetic','files':{},'history':[]})]:save(work/name,value)
    model.handoff(work,p);return p,base

def register_report(work,project,files):
    from proposal import save,load,filehash,candidate
    import proposal_quality as quality
    work=Path(work);state=load(work/'state.json');state['files']={r:{'path':str(Path(f).resolve()),'sha256':filehash(f),'registered':'synthetic'} for r,f in files.items()};state['review']={'reviewer':'SYNTHETIC-CHECKER'};save(work/'state.json',state)
    record=quality.starter(work,project,state,'SYNTHETIC-CHECKER',candidate(work,project,state));content=model.base(work);units={u['id']:u for u in content['semantic_units']}
    observed=model.corpus(work,project,state)
    def evidence(role,unit):
        row=next(r for r in project['artifact_projection'] if r['artifact_role']==role and unit['id'] in r['source_refs'])
        return {'artifact_role':role,'section_or_page':row['section_or_page'],'claim_refs':[unit['id']],'source_field_refs':unit['field_refs'],'observation':'Synthetic assessment protocol fixture','quote':model.resolve_text(project,unit['claim'])}
    role=project['outputs'][0]
    for item in record['proposal_reviews']:
        if not item['applicable']:continue
        fields=quality.rules()['field_map'][item['criterion_id']];unit=next((u for u in units.values() if set(fields)&set(u['field_refs'])),next(iter(units.values())))
        item.update(result='acceptable',reason='Synthetic positive judgment for regression only',evidence=[evidence(role,unit)])
    for item in record['artifact_reviews']:item.update(result='acceptable',reason='Synthetic artifact judgment',evidence=[evidence(item['artifact_role'],next(iter(units.values())))])
    record['requirements_review'].update(result='acceptable',checked_requirement_ids=[r['id'] for r in model.requirements(project)],reason='Synthetic source-comparison fixture only')
    save(work/'quality-review.json',record);return state,record

def slide_inputs(work,project):
    """Synthetic v2 slide plan derived from the same units as written fixtures."""
    from presentation_fixtures import example_plan
    from proposal import save
    work=Path(work);content=model.base(work);template=example_plan()['pages'][0]
    plan=contracts.load(contracts.ROOT/'assets/presentation-plan.json')
    plan.update(project_label=project['project_label'],reference_strategy={'status':'unavailable','reason':'Synthetic fixture has no external page reference'})
    for index,unit in enumerate(content['semantic_units']):
        ident='P'+str(index+1);page=copy.deepcopy(template)
        page.update(page_id=ident,source_refs=[unit['id']],claim_ids=[unit['id']],evidence_ids=[],reference_page_ids=[],scenario_ids=[],mechanism_ids=[],value_ids=[],fee_ids=[],key_page=index in [2,4],decision_question='What does this part contribute to the pilot decision?',takeaway=unit['claim'],explanation_roles=['mechanism'] if unit['id']=='U3' else ['value'] if unit['id']=='U5' else ['other'],visual_form='workflow',objects=[{'object_id':'A','label':'Input record','semantic_ref':unit['id']},{'object_id':'B','label':'Owner review','semantic_ref':unit['id']}],relations=[{'relation_id':'AB','from':'A','to':'B','meaning':'Routes to owner','semantic_ref':unit['id']}],copy={'headline':{'U1':'Pilot decision','U2':'Current problem','U3':'How the record moves','U4':'Scope and acceptance','U5':'Value hypothesis','U6':'Package and period','U7':'Responsibility and risks','U8':'Next decision'}[unit['id']],'body':[unit['claim']]},visual={'composition':'workflow','layout_reason':'Synthetic object transfer example','icon_ids':{},'asset_ids':[],'calibration_focus':['relations'],'body_position':[.05,.70,.90,.19]})
        plan['pages'].append(page)
        for role in set(project['outputs']) & {'pptx','ppt_pdf'}:project['artifact_projection'].append({'artifact_role':role,'section_or_page':ident,'source_refs':[unit['id']],'summary_and_conditions':None})
    save(work/'project.json',project);save(work/'presentation-plan.json',plan);model.handoff(work,project)
    return plan
