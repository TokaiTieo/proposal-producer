"""Portable bundled PPT integration; synthetic images, no service calls or quality claims."""
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from pptx import Presentation
import contracts,proposal_model as model,ppt_image_method as image,render_adapter as render
from test_chain_v7 import prepare_chain

class ImageBundle(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name)
        self.p,_,_=prepare_chain(self.work,presentation=True)
        self.plan=contracts.load(self.work/'presentation-plan.json')
        self.job=self.work/'images-v1'
    def tearDown(self):self.tmp.cleanup()
    def prepare(self,blueprints=None):
        with patch('production_chain.enforce'):
            return image.prepare(self.work,self.p,self.plan,self.job,'SYNTHETIC-USER','synthetic-existing-choice',blueprints)
    def test_package_is_local_and_all_vendor_hashes_match(self):
        with patch.object(Path,'home',side_effect=AssertionError('No global skill lookup')):method=image.bundle()
        self.assertTrue(Path(method['entrypoint']['path']).is_file())
        self.assertFalse(list((contracts.ROOT/'references/methods/ppt-image-render').rglob('SKILL.md')))
    def test_corrupt_script_cannot_fallback_to_host_install(self):
        original=Path.read_bytes;target=Path(image.bundle()['root'])/'scripts/build_prompt.py'
        def corrupt(file):return b'corrupt' if file==target else original(file)
        with patch.object(Path,'read_bytes',corrupt):
            with self.assertRaisesRegex(ValueError,'缺失或变化'):image.bundle()
    def test_prepare_executes_real_upstream_scripts_and_freezes_current_copy(self):
        original_route=(self.work/'render-policy.json').read_bytes()
        self.prepare();root,job=image.read_job(self.work,self.p,self.plan)
        self.assertEqual(root,self.job.resolve())
        for name in ['select-command.json','prompt-command.json']:
            record=contracts.load(root/'03_render_report'/name)
            self.assertEqual(record['exit_code'],0);self.assertIn('ppt-image-render/scripts',record['argv'][1])
        self.assertEqual((self.work/'render-policy.json').read_bytes(),original_route)
        _,route,_,_=render.task_config(self.work,self.p,presentation=True)
        self.assertEqual(route['default_mode'],'full_image');self.assertFalse(route['editable_text'])
        for file in (root/'02_render_prompt').glob('*.md'):
            self.assertNotIn('工业 AI 操作平台',file.read_text());self.assertNotIn('01.AI',file.read_text())
        self.assertEqual(len(list((root/'00_source').glob('*.md'))),len(self.plan['pages']))
    def test_blueprint_routes_through_real_B_script_path(self):
        page=self.plan['pages'][0]['page_id'];file=self.work/'blueprint.png';Image.new('RGB',(1920,1080),'white').save(file)
        self.prepare({page:model.proof(file)})
        decisions=contracts.load(self.job/'03_render_report/path_decision.json')['decisions']
        self.assertEqual(decisions[page]['path_type'],'B_blueprint')
    def test_changed_copy_or_prompt_invalidates_preparation(self):
        self.prepare();modified=copy.deepcopy(self.plan);modified['pages'][0]['takeaway']='Changed frozen takeaway'
        # The actual source comes from the materialized page copy.
        modified['pages'][0].setdefault('copy',{})['headline']='Changed frozen headline'
        with self.assertRaisesRegex(ValueError,'上屏文字'):image.read_job(self.work,self.p,modified)
        file=next((self.job/'02_render_prompt').glob('*.md'));file.write_text(file.read_text()+' tamper')
        with self.assertRaisesRegex(ValueError,'提示词'):image.read_job(self.work,self.p,self.plan)
    def test_over_capacity_page_fails_before_creating_a_job(self):
        self.plan['pages'][0]['copy']['headline']='X'*16000
        with self.assertRaisesRegex(ValueError,'内容容量'):self.prepare()
        self.assertFalse(self.job.exists())
    def test_missing_audit_is_blocked(self):
        self.prepare()
        with self.assertRaisesRegex(ValueError,'缺实际记录'):image.evidence(self.work,self.p,self.plan,self.plan['pages'])
    def synthetic_gate_records(self):
        # Deliberately synthetic records exercise binding logic, not visual truth.
        self.prepare();plan=model.materialized_plan(self.work,self.p,self.plan);page=plan['pages'][0];ident=page['page_id']
        file=self.job/'04_output/images'/f'{ident}.png';Image.new('RGB',(1920,1080),'white').save(file)
        plan['visual_assets'].append({'asset_id':'SYNTHETIC-IMAGE','source':model.proof(file),'identity':'illustrative_generated','source_description':'Synthetic unit test only','rights':'synthetic test fixture'})
        page['visual']['background_asset_id']='SYNTHETIC-IMAGE'
        report=self.job/'03_render_report'
        model.save(report/'audit_result.json',{'results':[{'page':ident,'verdict':'pass',**{k:({'ok':True} if k=='layer_2_5_resolution' else {'verdict':'pass','miss_rate':0.0} if k=='layer_1_content_qa' else {'verdict':'pass'}) for k in image.rules()['audit_layers']}}]})
        for name,entry in [('literal_transcription.json',{'fields':{'synthetic':'synthetic'},'image_sha256':model.sha(file)}),('ocr_extracts.json',{'ocr_text':'synthetic','image_sha256':model.sha(file)}),('visual_qa.json',{'verdict':'pass','image_sha256':model.sha(file)})]:model.save(report/name,{'pages':{ident:entry}})
        model.save(report/'promotion_log.json',{'promoted':[{'page':ident,'to':str(file)}]})
        return plan,page,file
    def test_gate_binds_approved_image_bytes_and_rejects_replacement(self):
        plan,page,file=self.synthetic_gate_records()
        proof=image.evidence(self.work,self.p,plan,[page]);self.assertTrue(any(v['path']==str(file.resolve()) for v in proof['files']))
        Image.new('RGB',(1920,1080),'red').save(file)
        plan['visual_assets'][-1]['source']=model.proof(file)
        with self.assertRaisesRegex(ValueError,'当前图像哈希'):image.evidence(self.work,self.p,plan,[page])
    def test_overall_pass_cannot_hide_an_unexecuted_audit_layer(self):
        plan,page,file=self.synthetic_gate_records();report=self.job/'03_render_report/audit_result.json';data=contracts.load(report);del data['results'][0]['layer_0_literal_transcription'];model.save(report,data)
        with self.assertRaisesRegex(ValueError,'审计层'):image.evidence(self.work,self.p,plan,[page])
    def test_content_threshold_is_read_from_contract_not_a_pass_label(self):
        plan,page,file=self.synthetic_gate_records();report=self.job/'03_render_report/audit_result.json';data=contracts.load(report);data['results'][0]['layer_1_content_qa']['miss_rate']=image.rules()['limits']['content_miss_rate_exclusive_max'];model.save(report,data)
        with self.assertRaisesRegex(ValueError,'缺失率'):image.evidence(self.work,self.p,plan,[page])
    def test_native_image_editing_flags_are_not_misrepresented(self):
        self.prepare();_,route,_,_=render.task_config(self.work,self.p,presentation=True)
        self.assertEqual(route['full_image_choice']['evidence'],'synthetic-existing-choice')
        self.assertFalse(route['editable_relations'])
    def test_actual_upstream_file_QA_rejects_empty_and_accepts_one_full_image_per_slide(self):
        self.prepare();file=self.work/'blank.png';Image.new('RGB',(1920,1080),'white').save(file)
        deck=Presentation();deck.slide_width,deck.slide_height=image.rules()['canvas_emu']
        for page in self.plan['pages']:deck.slides.add_slide(deck.slide_layouts[6])
        candidate=self.work/'candidate';candidate.mkdir();ppt=candidate/'synthetic.pptx';deck.save(ppt)
        with self.assertRaisesRegex(ValueError,'validate_deck'):image.validate_deck(self.work,self.p,self.plan,ppt,candidate,self.plan['pages'])
        for slide in deck.slides:slide.shapes.add_picture(str(file),0,0,width=deck.slide_width,height=deck.slide_height)
        deck.save(ppt);proof=image.validate_deck(self.work,self.p,self.plan,ppt,candidate,self.plan['pages'])
        self.assertEqual(contracts.load(proof['path'])['verdict'],'pass')
    def test_written_path_does_not_load_the_PPT_bundle(self):
        self.p['presentation_requested']=False
        with patch.object(image,'bundle',side_effect=AssertionError('No PPT method needed')):
            with self.assertRaisesRegex(ValueError,'尚未选择'):image.prepare(self.work,self.p,self.plan,self.job,'user','choice')

if __name__=='__main__':unittest.main(verbosity=2)
