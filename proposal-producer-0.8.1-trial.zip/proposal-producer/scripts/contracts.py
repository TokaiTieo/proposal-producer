"""Read, validate and consume the Skill's local JSON contracts (no network retrieval)."""
import hashlib
import json
from pathlib import Path
from functools import lru_cache

ROOT = Path(__file__).resolve().parents[1]

def load(path):
    def pairs(values):
        result={}
        for key,value in values:
            if key in result: raise ValueError('重复 JSON 字段: '+key)
            result[key]=value
        return result
    def invalid(value): raise ValueError('JSON 非有限数值: '+value)
    path=Path(path)
    try:
        return json.loads(path.read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=invalid)
    except (ValueError, UnicodeError) as exc:
        raise ValueError(str(path)+': '+str(exc)) from exc

def validate(data, schema_name):
    try: from jsonschema import Draft202012Validator
    except ImportError as exc:
        raise ValueError('缺 jsonschema；使用本任务 Python 环境安装 requirements.txt 后重试') from exc
    path=ROOT/'schemas'/schema_name
    stat=path.stat()
    validator=_validator(str(path),stat.st_mtime_ns,stat.st_size)
    errors=sorted(validator.iter_errors(data),key=lambda e:str(list(e.path)))
    if errors:
        error=errors[0]
        raise ValueError(schema_name+' /'+'/'.join(map(str,error.path))+': '+error.message)
    return data

@lru_cache(maxsize=128)
def _validator(path,mtime,size):
    from jsonschema import Draft202012Validator
    schema=load(path); Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)

def policy(): return validate(load(ROOT/'contracts/policy.json'),'policy.schema.json')
def fact_policy(): return validate(load(ROOT/'contracts/fact-policy.json'),'fact-policy.schema.json')
def checklist(): return validate(load(ROOT/'contracts/checks.json'),'checks.schema.json')
def visual_limits(project=None,presentation=False):
    rules=policy()
    return rules['optional_presentation']['visual'] if presentation or (project is not None and project.get('schema',0)<6) else rules['visual']
def measurement_rules(project):
    rules=policy()
    if project.get('schema',0)<6:return rules['optional_presentation']['measurement_checks']
    result={**rules['measurement_checks']}
    if project.get('presentation_requested'):
        result.update({'P'+k:{name:limit for name,limit in v.items() if not name.startswith('sow_')} for k,v in rules['optional_presentation']['measurement_checks'].items()})
    return result

def registered_data(work,project):
    """Read declared authoring inputs only; unrelated JSON and redirected logs are not inputs."""
    work=Path(work).resolve()
    entries={item['path']:{**item} for item in fact_policy()['default_data_files']}
    for field,schema in fact_policy()['optional_path_fields'].items():
        if field=='document_plan' and project.get('schema',0)<6:continue
        if field=='production_chain' and project.get('schema',0)<7:continue
        if project.get(field):entries[project[field]]={'path':project[field],'schema':schema,'required':True}
    for name,schema in project.get('data_files',{}).items():
        if name in entries and entries[name]['schema']!=schema:
            raise ValueError('data_files: 默认数据文件不得替换 Schema '+name)
        entries[name]={'path':name,'schema':schema,'required':True}
    result=[];seen=set()
    schema_root=(ROOT/'schemas').resolve()
    for entry in entries.values():
        path=Path(entry['path']);path=(path if path.is_absolute() else work/path).resolve()
        if path in seen:raise ValueError('data_files: 同一实际数据文件重复登记 '+str(path))
        seen.add(path)
        if not path.is_file():
            if entry['required']:raise ValueError('data_files: 已登记数据文件不存在 '+str(path))
            continue
        schema=(schema_root/entry['schema']).resolve()
        if not schema.is_relative_to(schema_root) or not schema.is_file():
            raise ValueError('data_files: 未知本地 Schema '+entry['schema'])
        try:data=validate(load(path),entry['schema'])
        except (ValueError,OSError) as exc:raise ValueError('data_files '+str(path)+': '+str(exc)) from exc
        result.append((path,data,entry['schema']))
    return result
def fingerprint():
    paths=sorted((ROOT/'contracts').glob('*.json'))+sorted((ROOT/'schemas').rglob('*.json'))
    payload={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()

def applicable(project):
    rules=policy();common=rules['workflow']['common_checks'] if project.get('schema',0)>=6 else rules['optional_presentation']['legacy_common_checks']
    ids=list(rules['types'][project['kind']]['content_checks'])+common[:]
    if project.get('schema',0)>=6 and project.get('presentation_requested'):ids += ['PV01','PV02','PV03','PV05']
    if 5<=project.get('schema',0)<6 and not {'pptx','ppt_pdf'}&set(project['outputs']):
        ids=[v for v in ids if v not in ['V01','V02']]
        if set(project['outputs'])=={'proposal_md'}:ids=[v for v in ids if v not in ['V03','V04','V05','V06']]
    if {'sow_docx','sow_pdf'}&set(project['outputs']): ids += [k for k in checklist()['checks'] if k.startswith('S')]
    import client_content
    if client_content.active(project):ids += [v['id'] for v in client_content.rules()['checks']]
    return ids

def validate_all():
    from jsonschema import Draft202012Validator
    schemas=list((ROOT/'schemas').rglob('*.json'))
    for path in schemas: Draft202012Validator.check_schema(load(path))
    files=[]
    for path in sorted((ROOT/'contracts').glob('*.json')):
        validate(load(path),path.stem+'.schema.json'); files.append(str(path.relative_to(ROOT)))
    for name in ['visual-profile','render-policy','document-plan']:
        validate(load(ROOT/f'assets/{name}.json'),name+'.schema.json');files.append('assets/'+name+'.json')
    validate(load(ROOT/'assets/production-chain.json'),'production-chain-record.schema.json');files.append('assets/production-chain.json')
    catalog=validate(load(ROOT/'assets/visual-kit/catalog.json'),'visual-catalog.schema.json')
    for item in catalog['assets']:
        file=(ROOT/item['path']).resolve()
        if not file.is_relative_to(ROOT) or not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=item['sha256']:raise ValueError('视觉资源缺失或变化 '+item['path'])
    files.append('assets/visual-kit/catalog.json')
    import ppt_image_method
    ppt_image_method.bundle()
    validate(load(ROOT/'assets/project.json'),'project.schema.json'); files.append('assets/project.json')
    for path in sorted((ROOT/'evals/fixtures').glob('project-*.json')):
        validate(load(path),'project.schema.json'); files.append(str(path.relative_to(ROOT)))
    validate(load(ROOT/'evals/contracts.json'),'evals.schema.json'); files.append('evals/contracts.json')
    validate(load(ROOT/'evals/client-content-cases.json'),'client-content-cases.schema.json');files.append('evals/client-content-cases.json')
    validate(load(ROOT/'evals/fixtures/sop-worked-case.json'),'sop-catalog.schema.json'); files.append('evals/fixtures/sop-worked-case.json')
    for name,schema in [('assets/presentation-plan.json','presentation-plan.schema.json'),('assets/calibration.json','calibration.schema.json'),('evals/fixtures/presentation-plan.json','presentation-plan.schema.json'),('evals/presentation-cases.json','presentation-cases.schema.json')]:
        validate(load(ROOT/name),schema);files.append(name)
    for path in sorted((ROOT/'assets/templates').glob('*.json')):
        validate(load(path),'templates/'+path.stem+'.schema.json'); files.append(str(path.relative_to(ROOT)))
    rules=policy(); catalog=checklist(); project_schema=load(ROOT/'schemas/project.schema.json')
    if set(project_schema['properties']['kind']['enum'])!=set(rules['types']): raise ValueError('类型词表与 Schema 不一致')
    if set(project_schema['properties']['outputs']['items']['enum'])!=set(rules['outputs']): raise ValueError('文件角色词表与 Schema 不一致')
    if set(project_schema['properties']['depth']['enum'])!=set(rules['depth']): raise ValueError('深度词表与 Schema 不一致')
    known=set(catalog['checks'])
    quality=load(ROOT/'contracts/presentation-quality.json')
    for name,key in [('presentation-plan','visual_forms'),('quality-review','quality_targets')]:
        schema=load(ROOT/f'schemas/{name}.schema.json')
        if 'oneOf' in schema:schema=schema['oneOf'][0]
        enum=(schema['properties']['pages']['items']['properties']['visual_form']['enum'] if name=='presentation-plan' else schema['properties']['quality_target']['enum'])
        if enum!=quality[key]:raise ValueError('展示质量词表与 Schema 不一致')
    for route in rules['types'].values():
        if set(route['content_checks'])-known: raise ValueError('类型引用不存在的检查项')
        if set(route['default_outputs'])-set(rules['outputs']): raise ValueError('默认输出引用未知角色')
    if set(rules['workflow']['common_checks'])-known: raise ValueError('共通检查引用缺失')
    fields=load(ROOT/'contracts/fields.json')['fields']
    quality_ids={c['id'] for c in quality['criteria']}|{c['id'] for c in load(ROOT/'contracts/proposal-quality.json')['criteria']}
    for item in catalog['checks'].values():
        if set(item.get('quality_criteria_refs',[]))-quality_ids:raise ValueError('内容检查引用未知质量项')
    for page in catalog['content_tasks']:
        if set(page['fields'])-set(fields) or page['check'] not in known: raise ValueError('页／字段／检查映射断裂')
    for name in ['sop-catalog','governance']:
        for section in load(ROOT/f'contracts/{name}.json')['sections']:
            for block in section['blocks']:
                if block['kind']=='table' and any(set(row)!=set(block['columns']) for row in block['rows']): raise ValueError(name+': 表字段不齐')
    return {'schemas':len(schemas),'validated_files':files,'policy_digest':fingerprint()}

def render(data):
    """Derived reading view; never consumed as the rule source."""
    if data.get('schema')==2 and 'semantic_units' in data:
        return '\n\n'.join('## '+u['id']+'\n'+u['claim'] for u in data['semantic_units'])
    if data.get('schema')==2 and 'connections' in data:
        return '\n'.join(v['from']+' -> '+v['to']+': '+v['reason'] for v in data['connections'])
    result=[]
    for section in data['sections']:
        result+=['## '+section['title'],'']
        for block in section['blocks']:
            kind=block['kind']
            if kind=='table':
                cols=block['columns']; result+=['| '+' | '.join(cols)+' |','| '+' | '.join('---' for _ in cols)+' |']
                result += ['| '+' | '.join(str(row[k]).replace('|','／') for k in cols)+' |' for row in block['rows']]
            elif kind in ['diagram','code']: result+=['```'+block['language'],block['source'],'```']
            else: result+=[('- ' if kind=='item' else '')+block['text']]
            result+=['']
    return '\n'.join(result)
