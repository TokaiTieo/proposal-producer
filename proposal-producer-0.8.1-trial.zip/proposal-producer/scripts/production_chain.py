"""Observable file handoffs for SOW -> business-case method -> Proposal -> PPT.

The producer declares applying the method. File hashes prove inputs and results,
not an agent's private reasoning or the user's business approval.
"""
from datetime import datetime,timezone
from pathlib import Path
import copy,json,shutil
import contracts,proposal_model as model

def active(project):return project.get('schema',0)>=7
def rules():return contracts.validate(contracts.load(contracts.ROOT/'contracts/production-chain.json'),'production-chain.schema.json')
def stamp():return datetime.now(timezone.utc).isoformat()
def path(work,project):return model.resolve(work,project.get('production_chain') or rules()['record_file'])
def read(work,project):
    file=path(work,project)
    return contracts.validate(contracts.load(file),'production-chain-record.schema.json') if file.is_file() else contracts.load(contracts.ROOT/'assets/production-chain.json')
def valid(entry):return bool(entry and Path(entry['path']).is_file() and model.sha(entry['path'])==entry['sha256'])
def write(work,project,record):
    contracts.validate(record,'production-chain-record.schema.json');file=path(work,project);file.parent.mkdir(parents=True,exist_ok=True)
    state_file=Path(work)/'state.json';state=contracts.load(state_file) if state_file.is_file() else None
    if file.is_file():
        folder=Path(work)/'chain-history';folder.mkdir(exist_ok=True);old=folder/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json');shutil.copy2(file,old)
        if state is not None:state['history'].append({'command':rules()['history_archive_command'],'time':stamp(),'record':{'previous_chain':model.proof(old)}})
    model.save(file,record)
    if state is not None:state['production_chain']=model.proof(file);model.save(state_file,state)
    return record
def method():
    item=rules()['method'];file=(contracts.ROOT/item['bundled_path']).resolve()
    if not file.is_relative_to(contracts.ROOT.resolve()):raise ValueError('内置提案方法必须位于本 Skill 中')
    if not file.is_file() or model.sha(file)!=item['sha256']:raise ValueError('business-case-and-proposal 实际方法文件缺失或变化')
    return model.proof(file)
def sow_digest(project,work=None):
    import client_content
    value={k:project.get(k) for k in rules()['sow_input_fields']}
    if work is not None and client_content.active(project):value['client_projection']=[a for a in client_content.annotations(work) if a['source']=='project']
    return model.digest(value)
def business_digest(project):
    requirements=[{k:v for k,v in r.items() if k not in ['affected_outputs','revision']} for r in model.business_requirements(project)]
    return model.digest({'project':{k:project.get(k) for k in rules()['proposal_input_fields']},'effective_requirements':requirements})
def proposal_digest(project,sow,source):return model.digest({'business':business_digest(project),'sow':sow,'method':source})
def issues(work,project,stage='proposal'):
    if not active(project):return []
    result=[];record=read(work,project);sow=record['sow']
    if not sow or not valid(sow['file']):return ['先生成实际上游 SOW（sow-build）']
    if sow['inputs_digest']!=sow_digest(project,work):result.append('SOW 范围、金额或制作输入已变化；更新 SOW 后再制作下游文件')
    if stage=='sow':return result
    proposal=record['proposal']
    if not proposal:return result+['先根据 SOW 应用 business-case-and-proposal，登记实际文稿（proposal-record）']
    if proposal['sow']!=sow['file'] or not valid(proposal['sow']):result.append('Proposal 方法记录引用的 SOW 已变化')
    if not valid(proposal['method']) or proposal['method']['sha256']!=rules()['method']['sha256']:result.append('Proposal 方法来源已变化')
    if not valid(proposal['brief']):result.append('Proposal 方法交接文件已变化')
    if proposal['inputs_digest']!=proposal_digest(project,sow['file'],proposal['method']):result.append('Proposal 方法所依据的业务输入已变化')
    for name in rules()['authored_files']:
        if not valid(proposal['authored_files'].get(name)):result.append('实际 Proposal 文稿或章节计划已变化 '+name)
    if stage=='proposal':return result
    if not project.get('presentation_requested'):return result+['用户尚未选择制作 PPT']
    ppt=record['presentation']
    if not ppt:return result+['先从实际 Proposal 提炼汇报版并登记（presentation-record）']
    import ppt_image_method
    try:
        current_method=ppt_image_method.bundle()['contract']
        if ppt.get('method')!=current_method:result.append('PPT 内置 ppt-image-render 方法未登记或已变化；重新执行 presentation-brief 与 presentation-record')
    except ValueError as exc:result.append(str(exc))
    for key in ['manifest','proposal_docx','proposal_pdf','brief','plan']:
        if not valid(ppt[key]):result.append('PPT 上游或提炼输入已变化 '+key)
    return result
def enforce(work,project,stage):
    problems=issues(work,project,stage)
    if problems:raise ValueError('；'.join(problems))

def build_sow(work,project,destination,producer):
    """Build from scoped work data before any Proposal method is applied."""
    import render_adapter as render,written_proposal as written
    from proposal import calculate
    from docx import Document
    work=Path(work).resolve();destination=Path(destination).resolve()
    if not producer:raise ValueError('sow-build 需要实际制作实例 --producer')
    if destination.exists():raise ValueError('SOW 候选目录已存在，选择新位置')
    if not project.get('scope') or not project.get('deliverable_details') or not project.get('acceptance'):raise ValueError('先填写 SOW 的范围、成果和验收要求')
    calculation=calculate(project)
    if calculation['issues']:raise ValueError('；'.join(calculation['issues']))
    destination.mkdir(parents=True);profile,route,_,_=render.task_config(work,project);fonts,_=render.font_map(profile,route,destination/'font-environment')
    if not all(v['available'] for v in fonts.values()):raise ValueError('SOW 字体未匹配，运行 doctor 选择实际字体')
    # This stage reads the SOW inputs only; later Proposal units cannot write
    # themselves back into the upstream agreement through artifact projections.
    import client_content
    problems=client_content.input_issues(work,project,sow_only=True)
    if problems:raise ValueError('；'.join(problems))
    view=client_content.customer_view(work,project,'project',project);view['artifact_projection']=[]
    if not view.get('sow_sections'):view['sow_sections']=contracts.load(contracts.ROOT/'assets/project.json')['sow_sections']
    plan={'_workdir':str(work),'_shared_units':{},'project_label':project['document_metadata']['title']+' — Statement of Work'+(' — Draft' if project.get('draft_mode') else ''),'deliverables':[],'fee_value_mappings':[]}
    file=destination/'sow.docx';render.build_sow(view,plan,file,profile,fonts,calculation);document=Document(file);written.clean_styles(document,profile,fonts,project);written.metadata_and_running(document,project,'sow_docx');document.save(file)
    check=written.check_file(file,project,'sow_docx')
    if check['issues']:raise ValueError('；'.join(check['issues']))
    record=read(work,project);record.update(sow={'producer':producer,'created':stamp(),'file':model.proof(file),'inputs_digest':sow_digest(project,work),'draft':bool(project.get('draft_mode'))},proposal_handoff=None,proposal=None,presentation_handoff=None,presentation=None);write(work,project,record)
    return {'status':'ready','stage':'sow','file':record['sow']['file'],'document_check':check,'customer_delivery_selected':bool(project.get('sow_required'))}

def proposal_brief(work,project):
    enforce(work,project,'sow');record=read(work,project);source=method();sow=record['sow']['file'];digest=proposal_digest(project,sow,source)
    from proposal import inspect
    text=inspect(sow['path'],'sow_docx')['text'];folder=Path(work)/'method-handoffs';folder.mkdir(exist_ok=True);file=folder/('proposal-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
    value={'stage':'proposal','method':{'name':rules()['method']['name'],'file':source,'mode':'read_and_apply'},'sow':sow,'sow_text':text,'effective_requirements':model.requirements(project),'decision_context':project['decision_context'],'business_context':{k:project.get(k) for k in rules()['proposal_input_fields']},'integration_rules':rules()['integration_rules'],'scenario_policy':rules()['scenario_policy'],'authored_outputs':rules()['authored_files'],'next':'Read the actual method file and SOW, author the business argument and chapter plan, then proposal-record with the actual producer. This handoff alone is not execution.'};model.save(file,value)
    record.update(proposal_handoff={'file':model.proof(file),'sow':sow,'method':source,'inputs_digest':digest},proposal=None,presentation_handoff=None,presentation=None);write(work,project,record);return value

def record_proposal(work,project,producer):
    if not producer:raise ValueError('proposal-record 需要实际方法执行实例 --producer')
    enforce(work,project,'sow');record=read(work,project);handoff=record['proposal_handoff']
    if not handoff or not all(valid(handoff[k]) for k in ['file','sow','method']):raise ValueError('先生成并读取有效的 proposal-brief 和方法原文')
    if handoff['sow']!=record['sow']['file'] or handoff['inputs_digest']!=proposal_digest(project,record['sow']['file'],handoff['method']):raise ValueError('方法交接的 SOW 或有效业务要求已变化，重新生成 proposal-brief')
    import written_proposal
    problems=model.model_issues(work,project)+written_proposal.plan_issues(work,project)
    if problems:raise ValueError('；'.join(dict.fromkeys(problems)))
    authored={name:model.proof(Path(work)/name if name!='document-plan.json' else written_proposal.plan_path(work,project)) for name in rules()['authored_files']}
    record.update(proposal={'producer':producer,'created':stamp(),'sow':handoff['sow'],'method':handoff['method'],'brief':handoff['file'],'inputs_digest':handoff['inputs_digest'],'authored_files':authored},presentation_handoff=None,presentation=None);write(work,project,record)
    return {'status':'ready','stage':'proposal_method','record':record['proposal'],'scope':'Producer declaration bound to actual method, SOW and authored outputs; not proof of private reasoning or business approval.'}

def written_manifest(work,project):
    enforce(work,project,'proposal');file=Path(work)/'proposal-source-manifest.json'
    if not file.is_file():raise ValueError('先实际制作并导出 Proposal DOCX/PDF，再提炼 PPT')
    record=contracts.validate(contracts.load(file),'render-manifest.schema.json')
    if not valid(record['source_files'].get('proposal_docx')) or not valid(record['exports'].get('proposal_pdf',{}).get('file')):raise ValueError('实际 Proposal DOCX/PDF 缺失或已变化')
    import render_adapter
    result=render_adapter.verify(work,project,file)
    if result['status']!='passed':raise ValueError('实际 Proposal 尚未通过导出检查：'+'；'.join(result['issues']))
    return file,record

def presentation_brief(work,project):
    if not project.get('presentation_requested'):raise ValueError('用户尚未选择制作 PPT')
    import ppt_image_method
    image_method=ppt_image_method.bundle()
    import written_proposal
    problems=written_proposal.form_issues(project)
    if problems:raise ValueError('；'.join(problems))
    file,manifest=written_manifest(work,project)
    from proposal import inspect
    doc=manifest['source_files']['proposal_docx'];pdf=manifest['exports']['proposal_pdf']['file'];folder=Path(work)/'method-handoffs';folder.mkdir(exist_ok=True);brief=folder/('presentation-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
    value={'stage':'presentation','proposal_docx':doc,'proposal_pdf':pdf,'proposal_text':inspect(doc['path'],'proposal_docx')['text'],'requirements':[r for r in model.requirements(project) if r['scope'] in ['outputs','visual','editability','language']],'source_sections':inspect(doc['path'],'proposal_docx')['sections'],'next':'Extract a reporting plan from this actual Proposal, preserve decision scope and figures, then presentation-record. Do not use the SOW as a substitute for the written Proposal.'};model.save(brief,value)
    value.update(method=image_method,integration_contract=str(contracts.ROOT/'contracts/ppt-image-render.json'),integration_guide=str(contracts.ROOT/'references/ppt-image-render.md'))
    model.save(brief,value)
    record=read(work,project);record.update(presentation_handoff={'file':model.proof(brief),'manifest':model.proof(file),'proposal_docx':doc,'proposal_pdf':pdf,'method':image_method['contract']},presentation=None);write(work,project,record);return value

def record_presentation(work,project,producer):
    if not producer:raise ValueError('presentation-record 需要实际制作实例 --producer')
    if not project.get('presentation_requested'):raise ValueError('用户尚未选择制作 PPT')
    written_manifest(work,project);record=read(work,project);handoff=record['presentation_handoff']
    if not handoff or not all(valid(handoff[k]) for k in ['file','manifest','proposal_docx','proposal_pdf']):raise ValueError('先读取当前实际 Proposal 的 presentation-brief')
    import ppt_image_method
    image_method=ppt_image_method.bundle()
    if handoff.get('method')!=image_method['contract']:raise ValueError('重新读取包含内置 ppt-image-render 的 presentation-brief')
    from proposal import inspect
    from presentation import plan_path
    plan=contracts.validate(contracts.load(plan_path(work,project)),'presentation-plan.schema.json');body=model.normalize(inspect(handoff['proposal_docx']['path'],'proposal_docx')['text']);units={u['id']:u for u in model.base(work)['semantic_units']}
    for page in plan['pages']:
        if not page.get('source_refs'):raise ValueError(page['page_id']+': PPT 页面缺书面 Proposal 来源')
        for ref in page['source_refs']:
            if ref not in units or model.normalize(model.resolve_text(project,units[ref]['claim'])) not in body:raise ValueError(page['page_id']+': PPT 引用尚未进入实际 Proposal 的论证 '+ref)
    record['presentation']={'producer':producer,'created':stamp(),'manifest':handoff['manifest'],'proposal_docx':handoff['proposal_docx'],'proposal_pdf':handoff['proposal_pdf'],'brief':handoff['file'],'plan':model.proof(plan_path(work,project)),'method':image_method['contract']};write(work,project,record);return {'status':'ready','stage':'presentation','record':record['presentation']}

def execute(command,work,project,args):
    if command=='chain-check':
        stage='presentation' if read(work,project)['presentation'] else 'proposal';problems=issues(work,project,stage);return {'status':'blocked' if problems else 'ready','stage':stage,'issues':problems}
    if command=='sow-build':return build_sow(work,project,args.destination or Path(work)/'sow-candidates'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'),args.producer)
    if command=='proposal-brief':return proposal_brief(work,project)
    if command=='proposal-record':return record_proposal(work,project,args.producer)
    if command=='presentation-brief':return presentation_brief(work,project)
    if command=='presentation-record':return record_presentation(work,project,args.producer)
    raise ValueError('未知制作链命令 '+command)
