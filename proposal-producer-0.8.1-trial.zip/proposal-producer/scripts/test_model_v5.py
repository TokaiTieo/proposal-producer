"""V5 behavioral regressions with synthetic source files and explicit test identities."""
import copy,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import contracts,proposal as api,proposal_model as model,proposal_quality as quality
import presentation,render_adapter as render,evaluation
from model_fixtures import prepare,register_report

class SharedModel(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name);self.p,self.content=prepare(self.work)
    def tearDown(self):self.tmp.cleanup()
    def persist(self):api.save(self.work/'project.json',self.p);api.save(self.work/'content-base.json',self.content)
    def build_md(self):
        import document_adapter
        document_adapter.build(self.work,self.p,self.work/'candidate');return self.work/'candidate/proposal.md'
    def test_valid_shared_model_and_free_modules(self):
        self.assertEqual(model.model_issues(self.work,self.p),[])
        self.assertNotIn('sections',self.content);self.assertEqual(len(self.content['modules']),7)
    def test_registered_requirement_omission_or_version_change_is_caught(self):
        hand=api.load(self.work/'handoff.json');hand['requirements']=[];api.save(self.work/'handoff.json',hand)
        self.assertTrue(any('交接要求' in v for v in model.request_issues(self.work,self.p)))
    def test_source_material_cannot_become_instruction_origin(self):
        self.p['request_requirements'][0]['origin']='reference_document'
        with self.assertRaises(ValueError):contracts.validate(self.p,'project.schema.json')
    def test_visual_method_and_editability_survive_handoff(self):
        for scope in ['visual','method','editability']:
            item=copy.deepcopy(self.p['request_requirements'][0]);item.update(id='RQ-'+scope,scope=scope,requirement='Keep the supplied method and editable scope',method_or_reference={'kind':'skill','reference':'requested-reference-skill'});self.p['request_requirements'].append(item)
        hand=model.handoff(self.work,self.p);self.assertEqual(len(hand['requirements']),4);self.assertEqual(hand['requirements'][-1]['method_or_reference']['reference'],'requested-reference-skill')
    def test_fact_reference_uses_project_authority_and_invalid_pointer_fails(self):
        self.content['semantic_units'][0]['claim']='Chosen currency {{fact:/pricing/currency}}';self.content['semantic_units'][0]['fact_refs']=['/pricing/currency'];self.persist()
        self.assertTrue(any('正式事实引用' in v or 'NoneType' in v for v in model.model_issues(self.work,self.p)))
    def test_assumption_needs_validation_and_commitment_needs_support(self):
        self.content['semantic_units'][4]['validation']=None;self.persist();self.assertTrue(any('假设缺验证' in v for v in model.model_issues(self.work,self.p)))
        self.content['semantic_units'][0]['kind']='commitment';self.p['decision_context']['commitment_scope']='binding';self.persist();model.handoff(self.work,self.p)
        self.assertTrue(any('结果承诺' in v for v in model.model_issues(self.work,self.p)))
    def test_three_types_select_their_own_fields_and_amount_features(self):
        for kind in ['opportunity','product','quote']:
            folder=self.work/kind;p,c=prepare(folder,kind)
            self.assertEqual(model.model_issues(folder,p),[],kind)
            if kind=='quote':self.assertEqual(api.calculate(p)['pricing']['total'],'36000.00');self.assertIsNone(api.calculate(p)['pricing']['tax'])
    def test_text_only_build_and_production_do_not_read_a_slide_plan(self):
        file=self.build_md();self.assertTrue(file.is_file());self.assertFalse((self.work/'presentation-plan.json').exists())
        self.assertEqual(presentation.production_issues(self.work,self.p,'SYNTHETIC-PRODUCER'),[])
        self.assertEqual(render.verify(self.work,self.p)['issues'],[])
    def test_internal_argument_is_not_a_delivered_artifact(self):
        result=model.projection_check(self.work,self.p,{})
        self.assertEqual(result['status'],'blocked');self.assertEqual(len(result['missing_unit_ids']),7)
    def test_real_written_artifact_contains_argument_and_validation(self):
        file=self.build_md();state={'files':{'proposal_md':{'path':str(file)}}};result=model.projection_check(self.work,self.p,model.corpus(self.work,self.p,state),state)
        self.assertEqual(result['issues'],[]);self.assertIn('Compare recording',file.read_text())
    def test_one_artifact_can_supply_argument_omitted_from_another(self):
        self.p['outputs']=['proposal_md','sow_docx'];self.p['request_requirements'][0]['affected_outputs']=self.p['outputs'][:]
        self.p['artifact_projection'] += [{**r,'artifact_role':'sow_docx'} for r in self.p['artifact_projection']];self.persist();model.handoff(self.work,self.p)
        full='\n'.join(r['section_or_page']+'\n'+'\n'.join(t for u in self.content['semantic_units'] if u['id'] in r['source_refs'] for t in model.unit_texts(self.p,u)) for r in model.projection_rows(self.p,'sow_docx'))
        result=model.projection_check(self.work,self.p,{'proposal_md':{'text':'Incomplete summary'},'sow_docx':{'text':full}})
        self.assertEqual(result['status'],'passed');self.assertIn('proposal_md',result['artifact_gaps'])
    def test_same_decision_rubric_is_independent_of_draft_label(self):
        before=quality.rubric_digest();self.p['draft_mode']=not self.p['draft_mode'];self.p['quality_target']='review_draft'
        self.assertEqual(quality.rubric_digest(),before);self.assertEqual(self.p['decision_context']['commitment_scope'],'pilot')
    def test_style_change_keeps_business_confirmation_but_scope_change_does_not(self):
        old=api.critical(self.p,self.work);profile=api.load(self.work/'visual-profile.json');profile['brand']='Different synthetic style';api.save(self.work/'visual-profile.json',profile)
        self.assertEqual(api.critical(self.p,self.work),old)
        self.p['scope'].append('New committed work');self.assertNotEqual(api.critical(self.p,self.work),old)
    def test_story_missing_connection_and_field_coverage_are_detected(self):
        story=api.load(self.work/'story-map.json');story['connections']=[];api.save(self.work/'story-map.json',story)
        self.content['modules']=self.content['modules'][:-1];self.persist()
        result=model.model_issues(self.work,self.p);self.assertTrue(any('story map' in v for v in result));self.assertTrue(any('F18' in v for v in result))
    def test_quality_uses_actual_client_quotes_and_preserves_source_gap(self):
        file=self.build_md();state,record=register_report(self.work,self.p,{'proposal_md':file})
        result=quality.summary(self.work,self.p,state,api.candidate(self.work,self.p,state));self.assertEqual(result['business_argument'],'acceptable');self.assertTrue(result['target_met'],result['issues'])
        record['proposal_reviews'][0]['evidence'][0]['quote']='Absent claim';api.save(self.work/'quality-review.json',record)
        self.assertFalse(quality.summary(self.work,self.p,state,api.candidate(self.work,self.p,state))['target_met'])
    def test_target_gap_cannot_hide_as_a_followup(self):
        file=self.build_md();state,record=register_report(self.work,self.p,{'proposal_md':file});record['proposal_reviews'][0]['followups']=[{'description':'Current argument missing','affects_target':True,'reason':'Stops the requested decision'}];api.save(self.work/'quality-review.json',record)
        self.assertEqual(quality.summary(self.work,self.p,state,api.candidate(self.work,self.p,state))['business_argument'],'gap')
    def test_artifact_byte_change_alone_keeps_business_judgment(self):
        file=self.build_md();state,record=register_report(self.work,self.p,{'proposal_md':file});file.write_text(file.read_text()+'\n')
        state['files']['proposal_md']['sha256']=api.filehash(file)
        result=quality.summary(self.work,self.p,state,api.candidate(self.work,self.p,state));self.assertEqual(result['business_argument'],'acceptable');self.assertEqual(result['artifact_quality']['proposal_md'],'not_evaluated')
    def test_freeze_carries_requirements_and_excludes_old_ratings(self):
        (self.work/'quality-review.json').write_text('{"old_rating":"PRIVATE_HISTORY"}')
        src=self.work/'sources.json';api.save(src,[{'role':'user_instructions','path':str(self.work/'original-brief.txt')}])
        frozen=evaluation.freeze_inputs(self.work,self.p,src,self.work/'frozen');self.assertTrue((Path(frozen['task'])/'handoff.json').is_file());self.assertFalse((Path(frozen['task'])/'quality-review.json').exists())
        self.assertEqual(model.request_issues(Path(frozen['task']),api.load(Path(frozen['task'])/'project.json')),[])
    def test_migration_preserves_originals_and_legacy_review(self):
        old=self.work/'old';old.mkdir();api.save(old/'project.json',contracts.load(contracts.ROOT/'evals/fixtures/legacy-project-quote.json'));api.save(old/'quality-review.json',{'original_rating':'unchanged'});api.save(old/'state.json',{'old':'state'})
        before=(old/'quality-review.json').read_bytes();result=model.migrate(old,api.load(old/'project.json'),self.work/'migrated','ACTUAL-MIGRATION-PRODUCER')
        self.assertEqual((old/'quality-review.json').read_bytes(),before);self.assertEqual((self.work/'migrated/legacy-records/quality-review.json').read_bytes(),before);self.assertEqual(result['to_schema'],7)

if __name__=='__main__':unittest.main(verbosity=2)
