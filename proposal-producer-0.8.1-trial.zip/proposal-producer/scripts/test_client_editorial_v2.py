"""Synthetic protocol assertions, never independent semantic approval of real text."""
import copy,importlib.util,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from docx import Document
import contracts,client_content as client,proposal as api,proposal_model as model,gates
from test_client_content import annotation,prepare_client,FONTS
import render_adapter as render

def complete_synthetic_record(work,project,state,record):
    """Fill fixture assertions to isolate the gate under test, not a real review."""
    evidence=Path(work)/'synthetic-editorial-evidence.txt';evidence.write_text('SYNTHETIC TEST EVIDENCE ONLY. No human, customer or independent contextual review is represented.')
    from PIL import Image
    visual=Path(work)/'synthetic-visual.png';Image.new('RGB',(80,80),'white').save(visual)
    proof=model.proof(evidence);record['result']='acceptable'
    queue={s['id']:s for s in client.check(work,project,state)['signals']}
    for a in record['artifact_reviews']:
        a.update(result='acceptable',decision_conditions_preserved=True,observation='Synthetic gate fixture',surfaces={s:'reviewed' for s in client.rules()['surfaces']},visual_evidence=[model.proof(visual)])
        for c in a['checks']:c.update(result='acceptable',observation='Synthetic assertion for '+c['id'],evidence=[proof])
    for f in record['findings']:
        signal=queue[f['signal_refs'][0]];repeat=signal['kind']=='exact_repetition'
        f.update(category='necessary_business',determination='necessary_business',disposition='necessary_business',resolution='Synthetic necessary-business assertion',necessity={'linked_claim_term_or_decision':'Synthetic bounded pilot decision','specific_misunderstanding_if_removed':'Synthetic acceptance owner would be omitted','placement_reason':'Synthetic decision section','duplicates_elsewhere':repeat,'other_locations':[o['location'] for o in signal['occurrences'][1:]] if repeat else [],'independent_business_purpose':'Synthetic distinct decision context at each occurrence' if repeat else None},evidence=[proof],final_verification={'file':f['observed_file'],'location':f['location'],'text':f['quote'],'residual_present':False,'observation':'Synthetic current-file assertion','evidence':[proof]})
        f['necessity']['duplicate_uses']=[{'location':o['location'],'business_purpose':'Synthetic business purpose at '+o['location'],'linked_claim_term_or_decision':'Synthetic clause at '+o['location']} for o in signal['occurrences']] if repeat else []
    return record

class EditorialV2(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name);self.p,self.c,self.plan=prepare_client(self.work)
        self.file=self.work/'actual.docx';d=Document();d.add_paragraph('The operations owner reviews the sample before approving a pilot expansion.');d.save(self.file)
        self.state={'producer':'PRODUCER-FIXTURE','review':{'reviewer':'REVIEWER-FIXTURE'},'files':{'proposal_docx':model.proof(self.file)}}
    def tearDown(self):self.tmp.cleanup()
    def record(self):return complete_synthetic_record(self.work,self.p,self.state,client.starter(self.work,self.p,self.state,'REVIEWER-FIXTURE'))
    def save(self,record):api.save(self.work/'client-content-review.json',record)
    def issues(self,record):self.save(record);return client.review_issues(self.work,self.p,self.state)
    def test_each_of_six_checks_blocks_independently_of_overall_result(self):
        clean=self.record();self.assertEqual(self.issues(clean),[])
        for ident in ['CE01','CE02','CE03','CE04','CE05','CE06']:
            r=copy.deepcopy(clean);next(c for c in r['artifact_reviews'][0]['checks'] if c['id']==ident)['result']='gap'
            self.assertTrue(any(i.startswith(ident+':') for i in self.issues(r)))
    def test_duplicate_or_missing_check_and_old_retention_branch_rejected(self):
        record=self.record();record['artifact_reviews'][0]['checks'][0]['id']='CE02'
        with self.assertRaises(ValueError):contracts.validate(record,'client-content-review.schema.json')
        record=self.record();record['findings'][0]['disposition']='retained_with_reason'
        with self.assertRaises(ValueError):contracts.validate(record,'client-content-review.schema.json')
    def test_each_signal_requires_a_decision_no_global_retention(self):
        r=self.record();r['findings']=[];self.assertTrue(any('待判定疑点' in i for i in self.issues(r)))
        r=self.record();r['findings']+=copy.deepcopy(r['findings']);self.assertTrue(any('只处置一次' in i for i in self.issues(r)))
    def test_necessity_requires_specific_five_part_evidence(self):
        for field in ['linked_claim_term_or_decision','specific_misunderstanding_if_removed','placement_reason','duplicates_elsewhere','other_locations','independent_business_purpose','duplicate_uses']:
            r=self.record();r['findings'][0]['necessity'].pop(field)
            with self.assertRaises(ValueError):contracts.validate(r,'client-content-review.schema.json')
    def test_confirmed_internal_and_defensive_content_cannot_be_waived(self):
        for category in ['internal_production','excessive_defense']:
            r=self.record();r['findings'][0].update(category=category,determination='confirmed_violation',disposition='necessary_business')
            with self.assertRaises(ValueError):contracts.validate(r,'client-content-review.schema.json')
    def test_unresolved_or_residual_blocks_even_with_six_passes(self):
        r=self.record();r['findings'][0].update(disposition='unresolved',determination='pending',category='undetermined');self.assertTrue(any('未解决' in i for i in self.issues(r)))
        r=self.record();r['findings'][0]['final_verification']['residual_present']=True;self.assertTrue(any('残留' in i for i in self.issues(r)))
    def test_final_file_hash_and_original_quote_are_independently_bound(self):
        r=self.record();r['findings'][0]['quote']='An invented quotation.';self.assertTrue(any('原文不在' in i for i in self.issues(r)))
        r=self.record();r['findings'][0]['final_verification']['file']['sha256']='0'*64;self.assertTrue(any('当前文件' in i for i in self.issues(r)))
    def test_resolved_violation_must_disappear_from_actual_deliverable(self):
        r=self.record();f=r['findings'][0];f.update(category='internal_production',determination='confirmed_violation',disposition='delete',necessity=None)
        self.assertTrue(any('原违规文字仍在' in i for i in self.issues(r)))
        old=self.work/'original.docx';old.write_bytes(self.file.read_bytes());f['observed_file']=model.proof(old)
        d=Document();d.add_paragraph('Approve the bounded pilot and appoint the accountable operations owner.');d.save(self.file);self.state['files']['proposal_docx']=model.proof(self.file)
        f['signal_refs']=[];f['final_verification'].update(file=model.proof(self.file),text=None)
        r['artifact_reviews'][0]['file']=model.proof(self.file);r['input_digest']=client.input_digest(self.work,self.p,self.state)
        self.assertEqual(self.issues(r),[])
    def test_exact_repetition_is_a_candidate_even_without_keywords(self):
        text='Training licences and travel costs are excluded from the fixed implementation fee.';d=Document();d.add_paragraph(text);d.add_paragraph(text);d.save(self.file);self.state['files']['proposal_docx']=model.proof(self.file)
        report=client.check(self.work,self.p,self.state);self.assertEqual(report['status'],'passed');self.assertTrue(any(s['kind']=='exact_repetition' for s in report['signals']))
        r=self.record();f=next(f for f in r['findings'] if f['check_id']=='CE03');f['necessity']['duplicates_elsewhere']=False
        self.assertTrue(any('逐处独立业务用途' in i for i in self.issues(r)))
    def test_pending_region_cannot_be_hidden_behind_not_present(self):
        r=self.record();r['artifact_reviews'][0]['surfaces']['source']='pending';self.assertTrue(any('区域仍待判定' in i for i in self.issues(r)))
    def test_old_project_marker_does_not_bypass_new_editorial_rules(self):
        self.p['client_content_policy']='client-1';self.assertTrue(client.active(self.p))
        r=self.record();r['schema']=1;self.assertTrue(any('当前逐项协议' in i for i in self.issues(r)))
    def test_prohibited_category_rejected_before_authoring_without_keyword_rules(self):
        self.c['content_annotations'][0]['content_category']='excessive_defense';api.save(self.work/'content-base.json',self.c)
        self.assertTrue(any('禁止内容不能' in i for i in client.input_issues(self.work,self.p)))
    def test_writing_conversion_keeps_raw_status_internal_and_requires_owner(self):
        self.c['semantic_units'][0]['conditions']=['Producer awaits a replacement sample upload.']
        self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'))
        a=self.c['content_annotations'][0];a.update(conversion={'kind':'missing_input','from_source':'content_base','from_pointer':'/semantic_units/0/conditions/0','business_meaning':'Sample availability determines pilot kickoff','arrangement':'Provide samples before kickoff'})
        api.save(self.work/'content-base.json',self.c);self.assertTrue(any('解决动作和责任人' in i for i in client.input_issues(self.work,self.p)))
        a.update(action='Supply authorized de-identified records before kickoff',owner='Operations owner');api.save(self.work/'content-base.json',self.c);self.assertEqual(client.input_issues(self.work,self.p),[])
    def test_source_region_cannot_be_free_text_disclaimer(self):
        self.p,self.c,self.plan=prepare_client(self.work,presentation=True)
        plan=api.load(self.work/'presentation-plan.json');plan['pages'][0]['copy']['source_note']='For reference only; we do not guarantee results.'
        self.c['content_annotations'].append(annotation('/pages/0/copy/source_note',purpose='evidence',placement='source',source='presentation_plan'))
        api.save(self.work/'content-base.json',self.c);api.save(self.work/'presentation-plan.json',plan)
        self.assertTrue(any('只能由可定位证据派生' in i for i in client.input_issues(self.work,self.p)))
        view=model.materialized_plan(self.work,self.p,plan);self.assertEqual(view['pages'][0]['copy']['source_note'],'')
    def test_release_and_stop_hook_share_the_pending_signal_gate(self):
        self.save(self.record());record=api.load(self.work/'client-content-review.json');record['findings']=[];self.save(record)
        result=gates.evidence_issues(self.work,self.p,self.state,'fixture',model.sha);self.assertTrue(any('待判定疑点' in i for i in result))
        spec=importlib.util.spec_from_file_location('client_v2_stop',contracts.ROOT/'hooks/claude_stop.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        (self.work/'release.json').write_text('{}')
        with patch.object(module.proposal,'context',return_value=(self.p,self.state)),patch.object(module.proposal,'candidate',return_value='fixture'),patch.object(module.proposal,'check',return_value={'issues':[]}),patch.object(module.presentation,'release_issues',return_value=([],None)),patch.object(module.gates,'receipt_issues',return_value=[]):
            response=module.verdict(self.work,{'hook_event_name':'Stop'})
        self.assertEqual(response['decision'],'block');self.assertIn('待判定疑点',response['reason'])
    def test_rewrite_fixtures_preserve_explicit_business_terms_in_native_files(self):
        cases=contracts.load(contracts.ROOT/'evals/client-content-cases.json')['cases']
        for case in cases:
            if not case.get('preserved_business_terms'):continue
            text=case.get('rewritten_text') or case['client_text'];d=Document();d.add_paragraph(text);f=self.work/(case['id']+'.docx');d.save(f)
            actual='\n'.join(r['text'] for r in client.extract(f,'proposal_docx')['segments'])
            basis=' '.join(case.get('supplied_business_facts',[case['client_text']]))
            for term in case['preserved_business_terms']:self.assertIn(term,actual);self.assertIn(term,basis)
            if case.get('rewritten_text'):self.assertNotIn(case['client_text'],actual)
    def test_program_pass_does_not_supply_six_editorial_passes(self):
        d=Document();d.add_paragraph('Esta propuesta fue redactada tras reorganizar las instrucciones recibidas.');d.save(self.file);self.state['files']['proposal_docx']=model.proof(self.file)
        self.assertEqual(client.check(self.work,self.p,self.state)['status'],'passed')
        r=client.starter(self.work,self.p,self.state,'REVIEWER-FIXTURE');self.assertEqual({c['result'] for c in r['artifact_reviews'][0]['checks']},{'not_evaluated'})
        self.assertTrue(self.issues(r))
    def test_source_style_is_extracted_as_a_separate_review_surface(self):
        from docx.enum.style import WD_STYLE_TYPE
        d=Document();d.styles.add_style('Source',WD_STYLE_TYPE.PARAGRAPH);d.add_paragraph('Facilities pilot brief · section 2',style='Source');d.save(self.file)
        self.assertEqual(client.extract(self.file,'proposal_docx')['segments'][0]['surface'],'source')
    def test_pdf_repetition_is_located_within_pages_and_across_pages(self):
        from reportlab.pdfgen.canvas import Canvas
        file=self.work/'repeat.pdf';c=Canvas(str(file));line='Hardware and installation labour are outside the agreed service fee.'
        c.drawString(40,750,line);c.drawString(40,700,line);c.showPage();c.drawString(40,750,line);c.save()
        found=client.signals('proposal_pdf',file,client.extract(file,'proposal_pdf'));repeat=next(s for s in found if s['kind']=='exact_repetition')
        self.assertEqual(len(repeat['occurrences']),3);self.assertTrue(any('page 2#' in o['location'] for o in repeat['occurrences']))
    def test_document_file_cannot_impersonate_rendered_visual_evidence(self):
        r=self.record();r['artifact_reviews'][0]['visual_evidence']=[model.proof(self.file)]
        self.assertTrue(any('实际页面或图中文字截图' in i for i in self.issues(r)))
    def test_fixing_an_omission_can_preserve_the_original_correct_business_sentence(self):
        original=self.work/'before-omission.docx';original.write_bytes(self.file.read_bytes());quote=Document(original).paragraphs[0].text
        added='The facilities lead supplies authorized, de-identified samples before kickoff.'
        d=Document(self.file);d.add_paragraph(added);d.save(self.file);self.state['files']['proposal_docx']=model.proof(self.file)
        r=self.record();f=copy.deepcopy(r['findings'][0]);f.update(id='F-OMISSION',signal_refs=[],check_id='CE04',category='condition_expression',determination='confirmed_violation',disposition='rewrite',necessity=None,observed_file=model.proof(original),quote=quote,location='original first paragraph',resolution='Added the omitted business condition and preserved the existing correct sentence.')
        f['final_verification'].update(file=model.proof(self.file),text=added,location='new second paragraph');r['findings'].append(f)
        self.assertEqual(self.issues(r),[])

if __name__=='__main__':unittest.main(verbosity=2)
