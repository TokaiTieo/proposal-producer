"""Freeze raw effective inputs/results before any cross-version comparison."""
from datetime import datetime,timezone
from pathlib import Path
import copy
import json
import shutil
import contracts
import proposal_model as model

def save(path,value):model.save(path,value)
def fresh(path):
    path=Path(path).resolve()
    if path.exists():raise ValueError('冻结目录已存在，保留原始记录并使用新位置')
    path.mkdir(parents=True);return path

def freeze_inputs(work,project,sources_file,destination):
    problems=model.request_issues(work,project)
    if problems:raise ValueError('；'.join(problems))
    declared=contracts.validate(contracts.load(sources_file),'evaluation-sources.schema.json')
    if not isinstance(declared,list):raise ValueError('输入清单使用带 role/path 的数组')
    if not declared:raise ValueError('登记原始有效指令及所用资料')
    for item in declared:
        if set(item)!={'role','path'} or item['role'] not in model.rules()['evaluation_input_roles']:raise ValueError('独立输入仅登记原始指令、资料和参考方法')
    if not any(v['role']=='user_instructions' for v in declared):raise ValueError('保留完整原始有效用户要求')
    instruction_files={model.resolve(work,v['path']) for v in declared if v['role']=='user_instructions'}
    for req in model.requirements(project):
        evidence=req['source']['evidence']
        if req['origin']=='user_instruction' and evidence and model.resolve(work,evidence['path']) not in instruction_files:raise ValueError('有效要求原文未列入 user_instructions '+req['id'])
    folder=fresh(destination);original=folder/'original-inputs';original.mkdir();task=folder/'task';task.mkdir();copies={};source_records=[]
    def copy_source(source,role):
        file=model.resolve(work,source)
        if not file.is_file():raise ValueError('冻结输入缺失 '+str(file))
        target=original/(str(len(copies)+1).zfill(3)+'-'+file.name)
        if str(file) not in copies:
            shutil.copy2(file,target);copies[str(file)]=str(target)
        else:target=Path(copies[str(file)])
        source_records.append({'role':role,'source':model.proof(file),'frozen':model.proof(target)})
    for item in declared:copy_source(item['path'],item['role'])
    names=['project.json','content-base.json','story-map.json','handoff.json','visual-profile.json','render-policy.json']+(['presentation-plan.json'] if model.has_ppt(project) else [])+(['document-plan.json'] if model.written(project) else [])
    if project.get('schema',0)>=7:names.append('production-chain.json')
    import presentation
    aliases={name:model.resolve(work,project.get(field) or name) for field,name in [('visual_profile','visual-profile.json'),('render_policy','render-policy.json'),('document_plan','document-plan.json'),('presentation_plan','presentation-plan.json')]}
    if project.get('schema',0)>=7:aliases['production-chain.json']=model.resolve(work,project.get('production_chain') or 'production-chain.json')
    data={name:contracts.load(aliases.get(name,Path(work)/name)) for name in names if aliases.get(name,Path(work)/name).is_file()}
    for field,name in [('visual_profile','visual-profile.json'),('render_policy','render-policy.json'),('document_plan','document-plan.json'),('presentation_plan','presentation-plan.json')]:
        if name in data:data['project.json'][field]=name
    if project.get('schema',0)>=7:data['project.json']['production_chain']='production-chain.json'
    for value in data.values():
        for proof in presentation.proofs(value):
            if str(model.resolve(work,proof['path'])) not in copies:copy_source(proof['path'],'reference_method')
    def remap(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256'}:
                old=str(model.resolve(work,value['path']));return {'path':copies.get(old,value['path']),'sha256':value['sha256']}
            return {k:remap(v) for k,v in value.items()}
        if isinstance(value,list):return [remap(v) for v in value]
        return value
    for name,value in data.items():save(task/name,remap(value))
    new_project=contracts.load(task/'project.json');model.handoff(task,new_project)
    snapshot=folder/'skill';shutil.copytree(contracts.ROOT,snapshot,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    snapshot_files={f.relative_to(snapshot).as_posix():model.sha(f) for f in sorted(snapshot.rglob('*')) if f.is_file()}
    import proposal_quality
    frozen={'schema':1,'phase':'inputs_frozen','created':datetime.now(timezone.utc).isoformat(),'skill_version':contracts.policy()['version'],'rule_digest':contracts.fingerprint(),'rubric_digest':proposal_quality.rubric_digest(),'decision_digest':model.digest(project['decision_context']),'requirements_digest':model.requirements_digest(project),'sources_digest':model.digest(sorted(v['source']['sha256'] for v in source_records if v['role'] in ['user_instructions','source_material'])),'task':str(task),'sources':source_records,'input_files':{name:model.proof(task/name) for name in data},'history_access':'Only after original artifacts and independent review have been frozen.'}
    frozen['skill_snapshot']={'path':str(snapshot),'files':snapshot_files,'digest':model.digest(snapshot_files)}
    contracts.validate(frozen,'evaluation-input-freeze.schema.json');save(folder/'input-freeze.json',frozen);return frozen

def verify_inputs(inputs):
    contracts.validate(inputs,'evaluation-input-freeze.schema.json')
    for entry in [v['frozen'] for v in inputs['sources']]+list(inputs['input_files'].values()):
        if not Path(entry['path']).is_file() or model.sha(entry['path'])!=entry['sha256']:raise ValueError('冻结输入已变化 '+entry['path'])
    snapshot=inputs['skill_snapshot'];root=Path(snapshot['path'])
    actual={f.relative_to(root).as_posix():model.sha(f) for f in sorted(root.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc'}
    if actual!=snapshot['files'] or model.digest(actual)!=snapshot['digest']:raise ValueError('冻结的 skill 版本已变化')

def freeze_result(record_file,destination):
    record=contracts.validate(contracts.load(record_file),'evaluation-result-input.schema.json');inputs=contracts.load(record['input_freeze']);verify_inputs(inputs)
    if inputs['phase']!='inputs_frozen':raise ValueError('先冻结完整有效输入')
    if record['producer']==record['reviewer']:raise ValueError('执行与检查使用独立的实际实例')
    roles=[e['artifact_role'] for e in record['artifacts'] if e.get('artifact_role')]
    if len(roles)!=len(set(roles)):raise ValueError('同一轮原始产物角色重复')
    for entry in record['artifacts']:
        role=entry.get('artifact_role')
        if role:
            suffix='.pptx' if role=='pptx' else '.docx' if role.endswith('_docx') else '.pdf' if role.endswith('_pdf') else '.md'
            if Path(entry['path']).suffix.lower()!=suffix:raise ValueError('原始产物载体与文件格式不一致 '+role)
    folder=fresh(destination);artifacts=[]
    for index,entry in enumerate(record['artifacts']+[record['review']]):
        file=Path(entry['path']).resolve()
        if not file.is_file() or model.sha(file)!=entry['sha256']:raise ValueError('原始产物或原始评价变化 '+str(file))
        target=folder/(str(index).zfill(3)+'-'+file.name);shutil.copy2(file,target);item=model.proof(target)
        if entry.get('artifact_role'):item['artifact_role']=entry['artifact_role']
        artifacts.append(item)
    value={key:inputs[key] for key in ['rule_digest','rubric_digest','decision_digest','requirements_digest','sources_digest','skill_version']}
    value.update(schema=1,phase='original_results_frozen',created=datetime.now(timezone.utc).isoformat(),producer=record['producer'],reviewer=record['reviewer'],input_freeze=model.proof(record['input_freeze']),original_artifacts=artifacts[:-1],original_review=artifacts[-1])
    contracts.validate(value,'evaluation-result-freeze.schema.json');save(folder/'result-freeze.json',value);return value

def compare(old_file,new_file):
    records=[contracts.validate(contracts.load(f),'evaluation-result-freeze.schema.json') for f in [old_file,new_file]]
    if any(v.get('phase')!='original_results_frozen' for v in records):raise ValueError('比较前先冻结各自原始产物和独立评价')
    for record in records:
        for item in record['original_artifacts']+[record['original_review'],record['input_freeze']]:
            if not Path(item['path']).is_file() or model.sha(item['path'])!=item['sha256']:raise ValueError('冻结的原始结果发生变化')
    keys=model.rules()['comparison_requirements']+['sources_digest'];different=[k for k in keys if records[0].get(k)!=records[1].get(k)]
    by_role=[{v['artifact_role']:v for v in r['original_artifacts'] if v.get('artifact_role')} for r in records]
    roles=set(by_role[0])|set(by_role[1]);comparisons=[{'artifact_role':role,'status':'comparable' if not different and all(role in r for r in by_role) else 'not_comparable','reason':'同类载体与评估口径齐备' if not different and all(role in r for r in by_role) else '缺对应产物或评估口径不同','files':[r.get(role) for r in by_role]} for role in sorted(roles)]
    artifact_status='not_comparable' if not comparisons or any(v['status']!='comparable' for v in comparisons) else 'comparable'
    return {'status':'not_comparable' if different else 'comparable','comparison_scope':'input_basis','artifact_status':artifact_status,'artifact_comparisons':comparisons,'untyped_artifacts':[v for r in records for v in r['original_artifacts'] if not v.get('artifact_role')],'differences':different,'original_reviews':[v['original_review'] for v in records],'aligned_reassessment':None,'conclusion':'输入口径单独核对；仅同类且两边齐备的产物可比较。未登记载体的历史产物或缺少对应文件时无法比较该项。原始评价保留原样。'}

def execute(command,work,project,args):
    if command in ['eval-freeze','eval-result'] and (not args.file or not args.destination):raise ValueError(command+' 需要 --file 与新目录 --destination')
    if command=='eval-freeze':return freeze_inputs(work,project,args.file,args.destination)
    if command=='eval-result':return freeze_result(args.file,args.destination)
    if not args.file or not args.report:raise ValueError('eval-compare 使用 --file OLD_FREEZE --report NEW_FREEZE')
    return compare(args.file,args.report)
