"""Rebuild the SOP catalog and source tables from an explicitly supplied Markdown.
Never edits the source or infers a source from an author's machine paths.
"""
import argparse,copy,hashlib,json,re
from pathlib import Path
import contracts

def split_row(line):return [x.strip().replace('\\|','|') for x in re.split(r'(?<!\\)\|',line.strip().strip('|'))]
def parse(text):
    sections=[];current=None;lines=text.splitlines();i=0
    while i<len(lines):
        line=lines[i].strip()
        if re.match(r'^#+ ',line):current={'title':line.lstrip('# '),'blocks':[]};sections.append(current)
        elif line:
            if current is None:current={'title':'metadata','blocks':[]};sections.append(current)
            if line.startswith('|') and i+1<len(lines) and re.match(r'^\|[ :|\-]+\|$',lines[i+1].strip()):
                cols=split_row(line);rows=[];i+=2
                while i<len(lines) and lines[i].strip().startswith('|'):
                    values=split_row(lines[i])
                    if len(values)!=len(cols):raise ValueError('Markdown 表格列数不一致 '+lines[i])
                    rows.append(dict(zip(cols,values)));i+=1
                current['blocks'].append({'kind':'table','columns':cols,'rows':rows});continue
            if line.startswith('```'):
                lang=line[3:];code=[];i+=1
                while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
                current['blocks'].append({'kind':'diagram' if lang=='mermaid' else 'code','language':lang,'source':'\n'.join(code)})
            elif re.match(r'^(\d+\. |[-*] )',line):current['blocks'].append({'kind':'item','text':re.sub(r'^(\d+\. |[-*] )','',line)})
            else:current['blocks'].append({'kind':'text','text':line})
        i+=1
    return sections

def schema(value):
    if isinstance(value,dict):return {'type':'object','properties':{k:schema(v) for k,v in value.items()},'required':list(value),'additionalProperties':False}
    if isinstance(value,list):
        shapes=[]
        for v in value:
            s=schema(v)
            if s not in shapes:shapes.append(s)
        return {'type':'array','items':shapes[0] if len(shapes)==1 else {'anyOf':shapes} if shapes else {}}
    if isinstance(value,bool):return {'type':'boolean'}
    if isinstance(value,(int,float)):return {'type':'number'}
    if value is None:return {'type':'null'}
    return {'type':'string'}
def save(name,value):
    file=contracts.ROOT/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def table(sections,prefix):
    return next(b['rows'] for s in sections if s['title'].startswith(prefix) for b in s['blocks'] if b['kind']=='table')

def sync(source,templates=None):
    text=Path(source).read_text();sections=parse(text);version=contracts.policy()['sop_version'];catalog={'sop_version':version,'sections':sections};contracts.validate(catalog,'sop-catalog.schema.json');save('contracts/sop-catalog.json',catalog)
    checks=contracts.checklist();definitions=checks['checks'];tasks=[]
    for row in table(sections,'7.2 '):
        ident=row['检查 ID'];prior=definitions[ident];fields=re.findall(r'F\d{2}',row['底稿字段']);refs=re.findall(r'\d{2}',row['建议书面章节'])
        definitions[ident]={**prior,'criterion':row['检查语义与完成条件'],'fields':fields,'source':'§7.2'};tasks.append({'id':ident,'title':prior['title'],'fields':fields,'check':ident,'section_refs':refs,'location_kind':'section/page'})
    for prefix in ['11.1 ','11.2 ']:
        for row in table(sections,prefix):
            ident,title=row['检查 ID'].split(' ',1);prior=definitions.get(ident,{})
            if prefix=='11.2 ':value={'title':title,'criterion':row['可判定阈值'],'method':row['检查方法'],'thresholds_ref':'policy.json#/visual','source':'§11.2'}
            else:value={**prior,'title':title,'criterion':row['通过标准'],'evidence':row['检查证据'],'source':'§11.1'}
            definitions[ident]=value
    for row in table(sections,'10.1 '):
        ident,title=row['SOW 章节'].split(' ',1)
        definitions[ident]={**definitions[ident],'title':title,'criterion':row['完成标准／主稿对应'],'source':'§10.1'}
    checks['content_tasks']=tasks;save('contracts/checks.json',checks)
    written=contracts.load(contracts.ROOT/'contracts/written-proposal.json')
    prior={c['id']:c for c in written['chapter_baseline']};baseline=[]
    for row in table(sections,'7. '):
        ident,title=row['节与通用标题'].split(' ',1)
        baseline.append({**prior[ident],'generic_title':title,'purpose':row['目的'],'required_content':row['必答内容'],'evidence_and_tables':row['证据／表格'],'recommended_body_pages':row['建议 A4 正文页']})
    written['chapter_baseline']=baseline;save('contracts/written-proposal.json',written)
    ws=contracts.load(contracts.ROOT/'schemas/written-proposal.schema.json');ws['properties']['chapter_baseline']=schema(baseline);save('schemas/written-proposal.schema.json',ws)
    blueprint=contracts.load(contracts.ROOT/'assets/document-plan.json')
    for chapter in blueprint['chapters']:chapter['title']=next(c['generic_title'] for c in baseline if c['id']==chapter['section_id'])
    save('assets/document-plan.json',blueprint)
    cs=contracts.load(contracts.ROOT/'schemas/checks.schema.json')
    for ident,value in definitions.items():cs['properties']['checks']['properties'][ident]=schema(value)
    cs['properties']['checks']['required']=list(definitions);save('schemas/checks.schema.json',cs)
    policy=contracts.policy()
    for ident in ['V08','V09']:
        for group in ['common_checks','nonwaivable_checks']:
            if ident not in policy['workflow'][group]:policy['workflow'][group].append(ident)
    save('contracts/policy.json',policy)
    source_record={'skill_version':policy['version'],'sop_version':version,'source':Path(source).name,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'generation':'scripts/sync_sop.py; Markdown headings, tables, lists and code parsed deterministically','templates':{}}
    if templates:
        for path in sorted(Path(templates).glob('*.md')):
            source_record['templates'][path.name]={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
            # The common semantic model and story graph use their dedicated v2
            # schemas; human form tables do not replace those runtime models.
            if path.name not in ['04-confirmation-packet.md','05-delivery-note.md']:continue
            stem=path.stem;data={'template':stem,'template_version':policy['version'],'sections':parse(path.read_text())};name='templates/'+stem+'.schema.json';old=contracts.load(contracts.ROOT/'schemas'/name);new={'$schema':'https://json-schema.org/draft/2020-12/schema',**schema(data)}
            # Keep explicit historical records readable without broadening any
            # individual table's strict fields.
            variants=[]
            for variant in old.get('anyOf',[old])+[new]:
                if variant not in variants:variants.append(variant)
            new={'$schema':'https://json-schema.org/draft/2020-12/schema','anyOf':variants}
            save('assets/templates/'+stem+'.json',data);save('schemas/'+name,new)
    save('references/sop-source.json',source_record)
    return {'version':version,'source_sha256':source_record['source_sha256'],'sections':len(sections),'content_tasks':len(tasks),'visual_check_ids':[k for k in definitions if re.fullmatch(r'V\d+',k)],'catalog_sha256':hashlib.sha256((contracts.ROOT/'contracts/sop-catalog.json').read_bytes()).hexdigest()}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source',type=Path,required=True);parser.add_argument('--templates',type=Path);args=parser.parse_args();print(json.dumps(sync(args.source,args.templates),ensure_ascii=False,indent=2))
