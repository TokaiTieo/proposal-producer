"""Client projection and observable text checks; editorial decisions stay independent."""
import copy,json,re
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET
import contracts,proposal_model as model

def rules():return contracts.validate(contracts.load(contracts.ROOT/'contracts/client-content.json'),'client-content.schema.json')
def active(project):return project.get('schema',0)>=7 and project.get('client_content_policy') in rules()['supported_project_markers']
def annotations(work):return model.base(work).get('content_annotations',[])
def roots(work,project):
    result={'project':project,'content_base':model.base(work)}
    for key,field,name in [('document_plan','document_plan','document-plan.json'),('presentation_plan','presentation_plan','presentation-plan.json')]:
        file=model.resolve(work,project.get(field) or name)
        if file.is_file():result[key]=contracts.load(file)
    return result
def annotation(work,source,pointer):
    found=[a for a in annotations(work) if a['source']==source and (pointer==a['pointer'] or pointer.startswith(a['pointer']+'/'))]
    return max(found,key=lambda a:len(a['pointer'])) if found else None
def is_client(work,source,pointer):
    a=annotation(work,source,pointer);return not a or a['visibility']=='client'
def unit_pointer(work,unit):
    return '/semantic_units/'+str(next(i for i,u in enumerate(model.base(work)['semantic_units']) if u['id']==unit['id']))
def client_unit(work,project,unit):return not active(project) or is_client(work,'content_base',unit_pointer(work,unit))
def narrative_values(value):
    if isinstance(value,str):yield value
    elif isinstance(value,list):
        for item in value:yield from narrative_values(item)
    elif isinstance(value,dict):
        for k,v in value.items():
            if k not in ['id','field_refs','fact_refs','mechanism_refs','evidence_refs']:yield from narrative_values(v)

def input_issues(work,project,sow_only=False):
    if not active(project):return []
    issues=[];data=roots(work,project);seen=set();content=data['content_base'];units=content['semantic_units']
    for a in annotations(work):
        key=(a['source'],a['pointer'])
        if sow_only and a['source']!='project':continue
        if key in seen:issues.append('CC01: annotation 重复 '+str(key))
        seen.add(key)
        try:value=model.pointer(data[a['source']],a['pointer'])
        except (KeyError,ValueError,IndexError,TypeError):issues.append('CC01: annotation 定位已失效 '+str(key));continue
        category=a.get('content_category')
        if project.get('client_content_policy')==rules()['version'] and not category:issues.append('CC01: 编写前需明确内容类别 '+str(key))
        if category in ['internal_production','excessive_defense'] and a['visibility']!='internal':issues.append('CC01: 禁止内容不能作为客户文字 '+str(key))
        conversion=a.get('conversion')
        if conversion:
            try:
                raw=model.pointer(data[conversion['from_source']],conversion['from_pointer'])
                if isinstance(raw,str) and isinstance(value,str) and raw.strip() and model.normalize(raw) in model.normalize(value):issues.append('CC01: 客户转换结果仍直接使用内部来源状态 '+str(key))
            except (KeyError,ValueError,IndexError,TypeError):issues.append('CC01: 写作转换来源定位失效 '+str(key))
            source_meta=annotation(work,conversion['from_source'],conversion['from_pointer'])
            if not source_meta or source_meta['visibility']!='internal':issues.append('CC01: 来源状态应留在内部 '+str(key))
            if a['visibility']!='client' or category!='necessary_business':issues.append('CC01: 转换结果需是客户业务表达 '+str(key))
            if conversion['kind']=='missing_input' and (not a['action'] or not a['owner']):issues.append('CC02: 缺失输入的业务转换需解决动作和责任人 '+str(key))
        if a['purpose']=='production_record' and a['visibility']!='internal':issues.append('CC01: 制作记录必须保存在内部 '+str(key))
        if a['visibility']=='internal' and a['placement']!='internal':issues.append('CC01: 内部内容披露位置不一致 '+str(key))
        if a['visibility']=='client' and a['placement']=='internal':issues.append('CC02: 客户内容需要客户位置 '+str(key))
        if a['visibility']=='client' and a['placement'] not in ['near_claim','source'] and not a['locations']:issues.append('CC02: 披露缺明确位置 '+str(key))
        if a['visibility']=='client' and a['purpose']=='evidence' and a['placement']!='source':issues.append('CC02: 来源说明应登记为 source '+str(key))
    if sow_only:return issues
    for i,u in enumerate(units):
        pointer='/semantic_units/'+str(i);a=annotation(work,'content_base',pointer)
        if not a or a['pointer']!=pointer:issues.append('CC01: 论证单元缺 visibility/purpose '+u['id']);continue
        if a['visibility']=='internal':
            if u['required_for_decision']:issues.append('CC01: 决策必需内容被标为内部 '+u['id'])
            continue
        if not is_client(work,'content_base',pointer+'/claim'):issues.append('CC01: 客户单元的主张被标为内部 '+u['id'])
        for ref in u['fact_refs']:
            if ref.startswith('/') and not is_client(work,'project',ref):issues.append('CC01: 客户主张引用内部字段 '+u['id']+'/'+ref)
        for field in ['assumptions','conditions','validation']:
            values=enumerate(u[field]) if isinstance(u[field],list) else [(None,u[field])]
            for idx,value in values:
                if not value:continue
                p=pointer+'/'+field+('/'+str(idx) if idx is not None else '');meta=annotation(work,'content_base',p)
                if not meta or meta['pointer']!=p:issues.append('CC02: 假设、条件或验证安排缺可见性及位置 '+u['id']+'/'+field)
        for role in ['proposal_docx','proposal_pdf','pptx','ppt_pdf']:
            for row in model.projection_rows(project,role):
                if u['id'] in row['source_refs']:
                    for ref in u['evidence_refs']:
                        if not any(e['evidence_id']==ref and e['location'] for e in content['evidence_sources']):issues.append('CC02: 主张来源缺可定位引用 '+ref)
    internal={u['id'] for u in units if not client_unit(work,project,u)}
    for row in project['artifact_projection']:
        if internal & set(row['source_refs']):issues.append('CC01: 客户投影引用内部单元 '+row['section_or_page'])
    for key,seq,refkey in [('document_plan',data.get('document_plan',{}).get('chapters',[]),'source_refs'),('presentation_plan',data.get('presentation_plan',{}).get('pages',[]),'source_refs')]:
        for row in seq:
            if internal & set(row.get(refkey,[])):issues.append('CC01: 客户计划引用内部单元 '+str(row.get('section_id') or row.get('page_id')))
    for index,page in enumerate(data.get('presentation_plan',{}).get('pages',[])):
        if page.get('copy',{}).get('source_note'):
            pointer='/pages/'+str(index)+'/copy/source_note';a=annotation(work,'presentation_plan',pointer)
            if not a or a['purpose']!='evidence' or a['placement']!='source':issues.append('CC02: 来源栏需要依据用途和来源位置 '+page['page_id'])
            refs=[e for u in units if u['id'] in page['source_refs'] for e in u['evidence_refs']]
            expected='; '.join(citations(work,refs))
            if model.normalize(page['copy']['source_note'])!=model.normalize(expected):issues.append('CC02: 来源栏只能由可定位证据派生 '+page['page_id'])
    return list(dict.fromkeys(issues))

def customer_view(work,project,source,value):
    """Only an explicit customer projection is supplied to text emitters."""
    if not active(project):return copy.deepcopy(value)
    omitted=object()
    def walk(v,p=''):
        a=annotation(work,source,p)
        if a and a['visibility']=='internal':return omitted
        if isinstance(v,dict):
            result={k:walk(item,p+'/'+k.replace('~','~0').replace('/','~1')) for k,item in v.items()}
            return {k:v for k,v in result.items() if v is not omitted}
        if isinstance(v,list):
            values=[walk(item,p+'/'+str(i)) for i,item in enumerate(v)]
            # Project fact references retain stable JSON Pointer array indexes.
            return [('' if x is omitted else x) for x in values] if source=='project' else [x for x in values if x is not omitted]
        return v
    view=walk(value)
    if source=='project':
        # Keep renderer controls outside the narrative projection. These fields
        # are never narrative sources; methods explicitly access client fields.
        client={k:view.get(k) for k in rules()['project_client_fields'] if k in view}
        controls={k:copy.deepcopy(view[k]) for k in rules()['renderer_control_fields'] if k in view}
        view={**controls,**client}
    return view

def business_content(work,project):
    content=customer_view(work,project,'content_base',model.base(work));content.pop('content_annotations',None)
    ids={u['id'] for u in content['semantic_units']}
    for module in content['modules']:module['unit_refs']=[r for r in module['unit_refs'] if r in ids]
    content['modules']=[m for m in content['modules'] if m['unit_refs'] or m['applicability']=='not_applicable']
    story=copy.deepcopy(model.story(work));story['connections']=[e for e in story['connections'] if e['from'] in ids and e['to'] in ids];story['decision_unit_refs']=[r for r in story['decision_unit_refs'] if r in ids]
    return {'content':content,'story':story}

def unit_texts(work,project,unit,summary=None,role=None,location=None):
    if not client_unit(work,project,unit):raise ValueError('CC01: 客户生成器拒绝内部单元 '+unit['id'])
    pointer=unit_pointer(work,unit);result=[model.resolve_text(project,summary or unit['claim'])]
    meta=annotation(work,'content_base',pointer)
    if not meta or meta['pointer']!=pointer:raise ValueError('CC01: 论证单元缺客户可见性 '+unit['id'])
    if not is_client(work,'content_base',pointer+'/claim'):raise ValueError('CC01: 客户生成器拒绝内部主张 '+unit['id'])
    for field in ['assumptions','conditions','validation']:
        values=enumerate(unit[field]) if isinstance(unit[field],list) else [(None,unit[field])]
        for idx,value in values:
            if not value:continue
            p=pointer+'/'+field+('/'+str(idx) if idx is not None else '');a=annotation(work,'content_base',p)
            if not a or a['pointer']!=p:raise ValueError('CC02: 缺披露规则 '+p)
            if a['visibility']=='client' and a['placement']=='near_claim' and (not a['locations'] or role is None or {'artifact_role':role,'section_or_page':location} in a['locations']):result.append(model.resolve_text(project,value))
    return list(dict.fromkeys(result))

def located_disclosures(work,project,role,location):
    result=[];data=roots(work,project)
    for a in annotations(work):
        if a['visibility']=='client' and a['placement'] not in ['near_claim','source'] and {'artifact_role':role,'section_or_page':location} in a['locations']:
            value=model.pointer(data[a['source']],a['pointer'])
            if isinstance(value,str):result.append(model.resolve_text(project,value))
    return list(dict.fromkeys(result))

def citations(work,refs):
    sources={e['evidence_id']:e for e in model.base(work)['evidence_sources']};result=[]
    for ref in dict.fromkeys(refs):
        if ref not in sources:raise ValueError('CC02: 未登记来源 '+ref)
        e=sources[ref];name=e.get('client_reference') or Path(e['source']['path']).name
        result.append(name+' · '+e['location'])
    return result

def extract(file,role):
    """Location-preserving extraction of text, chart text, comments and notes."""
    file=Path(file);rows=[]
    if file.suffix.lower() in ['.docx','.pptx']:
        with ZipFile(file) as z:
            for name in z.namelist():
                isword=name=='word/document.xml' or re.fullmatch(r'word/(?:header\d+|footer\d+|comments|footnotes|endnotes)\.xml',name)
                isdeck=re.fullmatch(r'ppt/(?:slides/slide\d+|notesSlides/notesSlide\d+)\.xml',name)
                graphic=re.fullmatch(r'(?:word|ppt)/(?:charts|diagrams)/[^/]+\.xml',name)
                if not (isword or isdeck or graphic):continue
                tree=ET.fromstring(z.read(name));surface='notes' if any(s in name for s in ['comments','footnotes','endnotes','notesSlide']) else 'header' if 'header' in name else 'footer' if 'footer' in name else 'graphic_text' if graphic else 'body'
                parents={c:p for p in tree.iter() for c in p};covered_nodes=set()
                for index,node in enumerate(n for n in tree.iter() if n.tag.endswith('}p')):
                    owned=[]
                    for n in node.iter():
                        if not n.tag.endswith(('}t','}v')):continue
                        owner=parents.get(n)
                        while owner is not None and not owner.tag.endswith('}p'):owner=parents.get(owner)
                        if owner is node:owned.append(n);covered_nodes.add(n)
                    text=''.join(n.text or '' for n in owned)
                    if not text.strip():continue
                    path=[];p=node
                    while p in parents:p=parents[p];path.append(p.tag.rsplit('}',1)[-1])
                    kind='table' if any(n in path for n in ['tbl','tc']) else 'graphic_text' if any(n in path for n in ['txbxContent','graphic']) else surface
                    styles=[(n.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val') or '').lower() for n in node.iter() if n.tag.endswith('}pStyle')]
                    if 'caption' in styles:kind='caption'
                    if 'source' in styles:kind='source'
                    if isdeck:
                        shape=node
                        while shape in parents and not shape.tag.endswith('}sp'):shape=parents[shape]
                        names=[n.get('name','') for n in shape.iter() if n.tag.endswith('}cNvPr')]
                        if 'business-source' in names:kind='source'
                        elif 'shared-facts' in names:kind='footer'
                    rows.append({'surface':kind,'location':name+'#p'+str(index+1),'text':text})
                for index,node in enumerate(tree.iter()):
                    if graphic and node not in covered_nodes and node.tag.endswith(('}t','}v')) and node.text:rows.append({'surface':'graphic_text','location':name+'#text'+str(index),'text':node.text})
                    if node.tag.endswith('}delText') and node.text:rows.append({'surface':'notes','location':name+'#deleted'+str(index),'text':node.text})
                    for attr in ['descr','title']:
                        if node.get(attr):rows.append({'surface':'graphic_text','location':name+'#alt'+str(index),'text':node.get(attr)})
            images=[n for n in z.namelist() if re.match(r'(word|ppt)/media/',n)]
    elif file.suffix.lower()=='.pdf':
        from proposal import inspect
        info=inspect(file,role)
        rows=[{'surface':'body','location':'page '+str(i+1)+'#line'+str(j+1),'text':line} for i,text in enumerate(info['blocks'][:info['pages']]) for j,line in enumerate(text.splitlines()) if line.strip()]
        from pypdf import PdfReader
        for i,p in enumerate(PdfReader(file).pages):
            for a in p.get('/Annots',[]):
                val=a.get_object().get('/Contents')
                if val:rows.append({'surface':'notes','location':'page '+str(i+1)+' annotation','text':str(val)})
        images=['pdf_visual_review']
    else:
        rows=[{'surface':'body','location':'text','text':file.read_text()}];images=[]
    return {'segments':rows,'images':images}

def files(work,project,state):
    result={r:v for r,v in state.get('files',{}).items() if r in project['outputs']}
    manifest=Path(work)/'render-manifest.json'
    if manifest.is_file():
        data=contracts.load(manifest)
        for r,v in data.get('source_files',{}).items():
            if r in project['outputs'] and r not in result:result[r]=v
        for r,v in data.get('exports',{}).items():
            if r in project['outputs'] and r not in result:result[r]=v['file']
    record=Path(work)/(project.get('production_chain') or 'production-chain.json')
    if record.is_file():
        sow=contracts.load(record).get('sow')
        if sow:result['upstream_sow']=sow['file']
    for item in project.get('supplementary_artifacts',[]):
        if item['customer_selected']:result['supporting:'+item['id']]={**item['source'],'path':str(model.resolve(work,item['source']['path']))}
    return result

def input_digest(work,project,state):
    sources=roots(work,project)
    return model.digest({'policy':rules(),'sources':sources,'files':{r:model.proof(v['path']) for r,v in files(work,project,state).items() if Path(v['path']).is_file()}})

def signals(role,file,observed):
    """Candidates only: repeated language and keyword matches never decide guilt."""
    result=[];groups={};proof=model.proof(file);config=rules();patterns=[re.compile(p) for p in config['hint_patterns']]
    def add(kind,rows):
        first=rows[0];payload={'kind':kind,'artifact_role':role,'file':proof,'surface':first['surface'],'location':first['location'],'quote':first['text'],'occurrences':[{'location':r['location'],'surface':r['surface']} for r in rows]}
        payload['id']='SIG-'+model.digest(payload)[:24];result.append(payload)
    for row in observed['segments']:
        if any(p.search(row['text']) for p in patterns):add('context', [row])
        normalized=model.normalize(row['text'])
        if len(normalized)>=config['repetition_detection']['min_normalized_characters']:groups.setdefault(normalized,[]).append(row)
    for rows in groups.values():
        if len(rows)>1:add('exact_repetition',rows)
    return result

def check(work,project,state):
    if not active(project):return {'status':'not_applicable','issues':[],'findings':[],'hints':[]}
    findings=[];hints=[];issues=input_issues(work,project);data=roots(work,project);units=data['content_base']['semantic_units'];actual=files(work,project,state);observed={};inspected={};located={};queue=[];patterns=[re.compile(p) for p in rules()['hint_patterns']]
    def location_text(role,location):
        from proposal import inspect
        key=(role,location);effective='sow_docx' if role=='upstream_sow' else role
        if role not in inspected:inspected[role]=inspect(actual[role]['path'],effective)
        if key not in located:located[key]=model.actual_location(work,project,effective,location,inspected[role],state)
        return located[key]
    for role,item in actual.items():
        path=Path(item['path'])
        if not path.is_file():issues.append('CC01: 文件缺失 '+role);continue
        if model.sha(path)!=item['sha256']:issues.append('CC01: 文件已变化 '+role)
        try:observed[role]=extract(path,role)
        except Exception as exc:issues.append('CC01: 无法抽取 '+role+': '+str(exc));continue
        for row in observed[role]['segments']:
            if any(p.search(row['text']) for p in patterns):hints.append({'artifact_role':role,**row,'action':'editorial_context_review'})
        queue+=signals(role,path,observed[role])
        for a in annotations(work):
            if a['visibility']!='internal':continue
            try:value=model.pointer(data[a['source']],a['pointer'])
            except (KeyError,ValueError,IndexError,TypeError):continue
            texts=[value['claim']] if a['source']=='content_base' and re.fullmatch(r'/semantic_units/\d+',a['pointer']) and isinstance(value,dict) else list(narrative_values(value))
            for text in texts:
                if not isinstance(text,str) or not text.strip():continue
                try:text=model.resolve_text(project,text)
                except (KeyError,ValueError,TypeError,IndexError):continue
                for row in observed[role]['segments']:
                    if model.normalize(text) in model.normalize(row['text']):findings.append({'check':'CC01','artifact_role':role,'location':row['location'],'quote':text,'source':a['source']+a['pointer']})
        if path.suffix=='.docx':
            with ZipFile(path) as z:
                tree=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                for p in tree.findall('.//w:p',ns):
                    codes=' '.join(n.text or '' for n in p.findall('.//w:instrText',ns))
                    if re.search(r'REF _proposal_(table|figure)_',codes):
                        text=''.join(n.text or '' for n in p.findall('.//w:t',ns))
                        expected=bool(re.search(r'(?:Table|Figure|表|图)\s*\d+\s*\S+',text))
                        if expected and any(model.normalize(c['text']) in model.normalize(text) for c in observed[role]['segments'] if c['surface']=='caption'):findings.append({'check':'CC03','artifact_role':role,'location':'word/document.xml REF','quote':text,'source':'cross_reference'})
        if role=='proposal_pdf':
            text=model.normalize('\n'.join(s['text'] for s in observed[role]['segments']));numbers={'table':0,'figure':0}
            for chapter in data.get('document_plan',{}).get('chapters',[]):
                for block in chapter['blocks']:
                    kind=block['kind']
                    if kind not in numbers:continue
                    numbers[kind]+=1
                    if not block.get('cross_reference'):continue
                    label=('表' if kind=='table' else '图') if model.client_language(work)=='zh' else ('Table' if kind=='table' else 'Figure')
                    caption=label+' '+str(numbers[kind])+' '+model.resolve_text(project,block['caption'])
                    for prefix in ['See ','见']:
                        if model.normalize(prefix+caption) in text:findings.append({'check':'CC03','artifact_role':role,'location':chapter['section_id']+' exported reference','quote':prefix+caption,'source':'PDF cross_reference'})
    # Exact locations are verified through the existing section projection reader.
    from proposal import inspect
    for a in annotations(work):
        if a['visibility']!='client' or a['placement']=='source':continue
        try:value=model.pointer(data[a['source']],a['pointer'])
        except (KeyError,IndexError,ValueError,TypeError):continue
        if not isinstance(value,str):continue
        for location in a['locations']:
            role=location['artifact_role']
            if role not in actual:continue
            text=location_text(role,location['section_or_page'])
            if model.normalize(model.resolve_text(project,value)) not in model.normalize(text):findings.append({'check':'CC02','artifact_role':role,'location':location['section_or_page'],'quote':value,'source':a['source']+a['pointer']})
    for row in project.get('artifact_projection',[]):
        role=row['artifact_role']
        if role not in actual or role not in observed:continue
        refs=[e for u in units if u['id'] in row['source_refs'] for e in u['evidence_refs']]
        if not refs:continue
        text=location_text(role,row['section_or_page'])
        for citation in citations(work,refs):
            if model.normalize(citation) not in model.normalize(text):findings.append({'check':'CC02','artifact_role':role,'location':row['section_or_page'],'quote':citation,'source':'evidence_refs'})
    issues += [v['check']+': '+v['artifact_role']+'/'+v['location'] for v in findings]
    return {'status':'blocked' if issues else 'passed','issues':list(dict.fromkeys(issues)),'findings':findings,'hints':hints,'signals':queue,'files':{r:{'file':model.proof(actual[r]['path']),'surfaces':sorted({s['surface'] for s in o['segments']}),'images':o['images']} for r,o in observed.items()},'scope':'Program status covers deterministic projection and engine errors only. Every signal needs an itemized contextual decision; all six editorial checks and image review remain necessary.'}

def starter(work,project,state,reviewer):
    report=check(work,project,state)
    checks=[c for c in rules()['checks'] if c['layer']=='editorial']
    return {'schema':rules()['review_schema'],'policy_version':rules()['version'],'input_digest':input_digest(work,project,state),'reviewer':reviewer,'result':'not_evaluated','artifact_reviews':[{'artifact_role':r,'file':v['file'],'surfaces':{s:'pending' for s in rules()['surfaces']},'result':'not_evaluated','checks':[{'id':c['id'],'result':'not_evaluated','observation':'Pending: '+c['name'],'evidence':[]} for c in checks],'decision_conditions_preserved':False,'observation':'Pending independent review of actual file and rendered pages.','visual_evidence':[]} for r,v in report['files'].items()],'findings':[{'id':s['id'],'signal_refs':[s['id']],'check_id':'CE03' if s['kind']=='exact_repetition' else 'CE01','category':'undetermined','determination':'pending','artifact_role':s['artifact_role'],'surface':s['surface'],'observed_file':s['file'],'location':s['location'],'quote':s['quote'],'quote_verification':'extracted','decision_impact':'Pending contextual determination, including whether this is necessary business content.','disposition':'unresolved','resolution':None,'necessity':None,'final_verification':None,'evidence':[]} for s in report.get('signals',[])]}

def review_issues(work,project,state):
    if not active(project):return []
    path=Path(work)/rules()['client_review_file']
    if not path.is_file():return ['CE01: 缺客户正文独立编辑复核']
    try:record=contracts.validate(contracts.load(path),'client-content-review.schema.json')
    except ValueError as exc:return ['CE01: 编辑记录需要当前逐项协议；保留原记录并重新复核: '+str(exc)]
    issues=[];actual=files(work,project,state);report=check(work,project,state);issues+=report['issues']
    if record['reviewer']==state['producer'] or record['reviewer']!=state.get('review',{}).get('reviewer'):issues.append('CE01: 使用现有实际独立检查者')
    if record['input_digest']!=input_digest(work,project,state):issues.append('CE01: 客户文字、投影、文件或规则已变化')
    if record['result']!='acceptable':issues.append('CE01: 正文表达缺陷未解决或未复核')
    entries={e['artifact_role']:e for e in record['artifact_reviews']}
    if len(entries)!=len(record['artifact_reviews']) or set(entries)!=set(actual):issues.append('CE01: 实际文件复核覆盖不完整')
    for role,v in actual.items():
        e=entries.get(role)
        if not e:continue
        if e['file']!=model.proof(v['path']) or e['result']!='acceptable' or not e['decision_conditions_preserved']:issues.append('CE01: 载体复核或必要条件保留未通过 '+role)
        for c in e['checks']:
            if c['result']!='acceptable':issues.append(c['id']+': 独立检查未通过 '+role)
            for evidence in c['evidence']:
                file=model.resolve(work,evidence['path'])
                if not file.is_file() or model.sha(file)!=evidence['sha256']:issues.append(c['id']+': 检查证据变化 '+role)
        if any(s=='pending' for s in e['surfaces'].values()):issues.append('CE01: 文字区域仍待判定 '+role)
        for s in report.get('files',{}).get(role,{}).get('surfaces',[]):
            if e['surfaces'].get(s)!='reviewed':issues.append('CE01: 未查看实际文字面 '+role+'/'+s)
        if report.get('files',{}).get(role,{}).get('images') and (e['surfaces'].get('graphic_text')!='reviewed' or not e['visual_evidence']):issues.append('CE01: 图内文字缺实际视觉复核证据 '+role)
        for evidence in e['visual_evidence']:
            file=model.resolve(work,evidence['path'])
            if not file.is_file() or model.sha(file)!=evidence['sha256']:issues.append('CE01: 视觉证据变化 '+role)
            elif file.suffix.lower() not in rules()['visual_evidence_formats']:issues.append('CE01: 视觉证据需要实际页面或图中文字截图 '+role)
            else:
                try:
                    from PIL import Image
                    with Image.open(file) as image:image.verify()
                except Exception:issues.append('CE01: 视觉证据不是有效图片 '+role)
    covered={};ids=set();signal_map={s['id']:s for s in report.get('signals',[])};remaining=set();extracted={};signal_sets={};valid_original={}
    def content(file,role):
        key=(role,str(Path(file).resolve()))
        if key not in extracted:extracted[key]=extract(file,role)
        return extracted[key]
    for f in record['findings']:
        label=f['check_id']+': '+f['id'];role=f['artifact_role'];original=model.resolve(work,f['observed_file']['path'])
        if f['id'] in ids:issues.append(label+' 检查发现 ID 重复')
        ids.add(f['id'])
        if role not in actual:issues.append(label+' 未对应实际文件');continue
        if f['disposition']=='unresolved' or f['determination']=='pending':issues.append(label+' 未解决表达缺陷')
        if f['determination']=='confirmed_violation' and f['disposition']=='necessary_business':issues.append(label+' 已判违规不能以理由保留')
        if f['disposition']=='necessary_business' and f['necessity']['duplicates_elsewhere']:
            need=f['necessity'];locations=[d['location'] for d in need['duplicate_uses']]
            if len(locations)!=len(set(locations)) or set(locations)!={f['location'],*need['other_locations']}:issues.append(label+' 重复限定缺逐处独立业务用途')
        key=(str(original),f['observed_file']['sha256'])
        if key not in valid_original:valid_original[key]=original.is_file() and model.sha(original)==f['observed_file']['sha256']
        if not valid_original[key]:issues.append(label+' 原文文件证据变化')
        else:
            observed=content(original,role)
            if f['quote_verification']=='extracted' and not any(model.normalize(f['quote']) in model.normalize(row['text']) for row in observed['segments']):issues.append(label+' 原文不在已绑定文件中')
            if f['quote_verification']=='visual' and (f['surface']!='graphic_text' or not f['evidence']):issues.append(label+' 图内原文缺视觉核查证据')
            signal_key=(role,*key)
            if signal_key not in signal_sets:signal_sets[signal_key]={s['id'] for s in signals(role,original,observed)}
            original_signals=signal_sets[signal_key]
            for ref in f['signal_refs']:
                if ref not in original_signals:issues.append(label+' 疑点引用不属于已绑定原文文件')
        for ref in f['signal_refs']:
            covered.setdefault(ref,[]).append(f)
            signal=signal_map.get(ref)
            if signal and (signal['artifact_role']!=role or signal['file']!=f['observed_file'] or signal['location']!=f['location'] or signal['quote']!=f['quote']):issues.append(label+' 扫描疑点的原文或位置被替换')
            if signal and signal['kind']=='exact_repetition' and f['disposition']=='necessary_business':
                need=f['necessity']
                locations={o['location'] for o in signal['occurrences'][1:]}
                if not need or not need['duplicates_elsewhere'] or not locations<=set(need['other_locations']):issues.append(label+' 重复限定缺逐处独立业务用途')
        current=f['final_verification']
        if current:
            target=model.proof(actual[role]['path'])
            if current['file']!=target:issues.append(label+' 修改后复核未绑定当前文件')
            if current['residual_present']:issues.append(label+' 已确认违规仍有残留');remaining.add(f['id'])
            output=content(actual[role]['path'],role)
            joined=model.normalize('\n'.join(r['text'] for r in output['segments']))
            if f['category'] in rules()['verbatim_removal_categories'] and f['disposition'] in ['delete','rewrite','move_internal'] and f['quote_verification']=='extracted' and model.normalize(f['quote']) in joined:issues.append(label+' 原违规文字仍在当前文件');remaining.add(f['id'])
            if f['disposition']=='necessary_business' and f['quote_verification']=='extracted' and model.normalize(f['quote']) not in joined:issues.append(label+' 必要商务内容已丢失')
            if current['text'] and f['quote_verification']=='extracted' and model.normalize(current['text']) not in joined:issues.append(label+' 改写或保留文字不在当前文件')
        elif f['disposition']!='unresolved':issues.append(label+' 缺当前文件重新核对')
        extra=(current or {}).get('evidence',[])
        for e in extra:
            file=model.resolve(work,e['path'])
            if not file.is_file() or model.sha(file)!=e['sha256']:issues.append(label+' 当前文件复核证据变化')
        for e in f['evidence']:
            file=model.resolve(work,e['path'])
            if not file.is_file() or model.sha(file)!=e['sha256']:issues.append('CE01: 缺陷处理证据变化 '+f['id'])
    for ref in signal_map:
        if len(covered.get(ref,[]))!=1:issues.append('CE01: 待判定疑点必须逐项处置且只处置一次 '+ref)
    counts={
        'confirmed_internal_production':sum(f['determination']=='confirmed_violation' and f['category']=='internal_production' and (f['id'] in remaining or not f['final_verification'] or f['disposition']=='unresolved') for f in record['findings']),
        'confirmed_excessive_defense':sum(f['determination']=='confirmed_violation' and f['category']=='excessive_defense' and (f['id'] in remaining or not f['final_verification'] or f['disposition']=='unresolved') for f in record['findings']),
        'pending_signals':sum(len(covered.get(ref,[]))!=1 or any(f['determination']=='pending' or f['disposition']=='unresolved' for f in covered.get(ref,[])) for ref in signal_map),
        'unresolved_findings':sum(f['determination']=='pending' or f['disposition']=='unresolved' for f in record['findings'])}
    for key,limit in rules()['zero_residual_conditions'].items():
        if counts[key]>limit:issues.append('CE01: 零残留条件未满足 '+key+'='+str(counts[key]))
    return list(dict.fromkeys(issues))
