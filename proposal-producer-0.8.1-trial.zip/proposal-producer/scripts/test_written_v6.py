"""Written-default regressions. Synthetic artifacts are protocol evidence only."""
import copy,importlib.util,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from docx import Document
from docx.shared import Mm,Pt
import contracts,proposal as api,proposal_model as model,render_adapter as render,presentation,gates
import written_proposal as written
from written_fixtures import prepare_written

class Defaults(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def cli(self,*args,code=0):
        p=subprocess.run([sys.executable,str(contracts.ROOT/'scripts/proposal.py'),*args],capture_output=True,text=True)
        self.assertEqual(p.returncode,code,p.stdout+p.stderr);return json.loads(p.stdout or p.stderr)
    def test_all_three_types_initialize_written_pair_only(self):
        for kind in ['quote','opportunity','product']:
            w=self.root/kind;self.cli('init','--workdir',str(w),'--kind',kind,'--producer','TEST-DEFAULTS')
            p=api.load(w/'project.json');self.assertEqual(p['outputs'],['proposal_docx','proposal_pdf']);self.assertFalse(p['presentation_requested']);self.assertFalse(p['sow_required']);self.assertTrue((w/'document-plan.json').is_file());self.assertFalse((w/'presentation-plan.json').exists());self.assertFalse((w/'calibration.json').exists())
    def test_deck_requires_explicit_flag_and_is_additional(self):
        self.cli('init','--workdir',str(self.root/'bad'),'--producer','TEST','--outputs','pptx,ppt_pdf',code=2)
        w=self.root/'optional';self.cli('init','--workdir',str(w),'--producer','TEST','--presentation-requested');p=api.load(w/'project.json')
        self.assertEqual(p['outputs'],['proposal_docx','proposal_pdf','pptx','ppt_pdf']);self.assertTrue((w/'presentation-plan.json').is_file())
    def test_sow_requires_flag_and_does_not_replace_proposal(self):
        self.cli('init','--workdir',str(self.root/'bad'),'--producer','TEST','--outputs','sow_docx',code=2)
        w=self.root/'sow';self.cli('init','--workdir',str(w),'--producer','TEST','--sow-required');self.assertEqual(api.load(w/'project.json')['outputs'],['proposal_docx','proposal_pdf','sow_docx'])
    def test_schema_rejects_optional_roles_without_flags(self):
        for role in ['pptx','ppt_pdf','sow_docx','sow_pdf']:
            p=contracts.load(contracts.ROOT/'assets/project.json');p['outputs'].append(role)
            with self.assertRaises(ValueError):contracts.validate(p,'project.schema.json')
    def test_explicit_output_requirement_cannot_mislabel_sow_as_complete_proposal(self):
        p,c,plan=prepare_written(self.root/'p',sow=True);p['outputs']=['sow_docx']
        with self.assertRaises(ValueError):contracts.validate(p,'project.schema.json')
        self.assertTrue(any('完整书面' in v for v in written.form_issues(p)))
        p['task_scope']='partial_artifact';contracts.validate(p,'project.schema.json');self.assertEqual(written.form_issues(p),[])
    def test_handoff_carries_form_flags_and_metadata(self):
        p,c,plan=prepare_written(self.root/'p');h=model.handoff(self.root/'p',p)
        self.assertFalse(h['project_context']['presentation_requested']);self.assertEqual(h['project_context']['document_metadata'],p['document_metadata'])
    def test_default_checks_are_written_and_sow_checks_conditional(self):
        p,c,plan=prepare_written(self.root/'p');ids=contracts.applicable(p)
        self.assertTrue({'V01','V02','V05','V08','V09'}<=set(ids));self.assertFalse(any(v.startswith(('PV','S')) for v in ids));self.assertNotIn('ppt_aspect',contracts.policy()['visual'])
        p['sow_required']=True;p['outputs'].append('sow_docx');self.assertTrue(set('S'+str(i).zfill(2) for i in range(1,14))<=set(contracts.applicable(p)))
    def test_written_depth_is_a4_advisory_not_deck_limits(self):
        for entry in contracts.policy()['depth'].values():self.assertIn('A4',entry['page_unit']);self.assertTrue(entry['advisory']);self.assertIn('min_words',entry)
        self.assertEqual(contracts.policy()['depth']['standard']['min_pages'],11)
    def test_doctor_does_not_require_presentation_module_for_default(self):
        p,c,plan=prepare_written(self.root/'p');original=importlib.util.find_spec
        with patch.object(render.importlib.util,'find_spec',side_effect=lambda n:None if n=='pptx' else original(n)),patch.object(render,'font_map',return_value=({'body':{'available':True},'title':{'available':True}},{})):
            report=render.doctor(self.root/'p',p)
        self.assertTrue(report['native_build']);self.assertNotIn('pptx',report['required_modules'])

class WrittenFiles(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.work=Path(self.temp.name);self.p,self.c,self.plan=prepare_written(self.work)
        self.fonts={r:{'requested':'Arial','actual_family':'Arial','file':None,'available':True} for r in ['body','title']};self.mock=patch.object(render,'font_map',return_value=(self.fonts,{}));self.mock.start()
    def tearDown(self):self.mock.stop();self.temp.cleanup()
    def build(self):return render.build(self.work,self.p,None,self.work/'candidate')
    def check(self,file):return written.check_file(file,self.p)
    def test_native_document_has_hierarchy_toc_fields_captions_metadata_and_a4(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);r=self.check(file)
        self.assertEqual(r['issues'],[],r);m=r['measurements'];self.assertEqual(len(m['heading1_text']),12);self.assertTrue(m['toc_field']);self.assertEqual(len(m['pageref_fields']),12);self.assertTrue(m['page_field']);self.assertEqual(m['metadata']['creator'],'Synthetic Proposal Team');self.assertEqual(m['table_count'],1);self.assertEqual(m['caption_count'],1)
    def test_no_slide_plan_is_opened_on_default_branch(self):
        (self.work/'presentation-plan.json').write_text('invalid optional file')
        self.assertEqual(presentation.production_issues(self.work,self.p,'SYNTHETIC-PRODUCER'),[])
        self.assertEqual(self.build()['pages'],[])
    def test_document_plan_is_separate_and_adaptable(self):
        original=api.load(contracts.ROOT/'assets/presentation-plan.json');self.plan['chapters'].append({**self.plan['chapters'][-1],'section_id':'13','title':'Additional dependencies'})
        api.save(self.work/'document-plan.json',self.plan);self.assertEqual(written.plan_issues(self.work,self.p),[]);self.assertEqual(api.load(contracts.ROOT/'assets/presentation-plan.json'),original)
    def test_wrong_size_margin_or_body_font_is_rejected(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);d=Document(file);d.sections[0].page_width=Mm(300);d.sections[0].left_margin=Mm(10);d.styles['Normal'].font.size=Pt(8);d.save(file)
        r=self.check(file);self.assertTrue(any('A4' in v for v in r['issues']));self.assertTrue(any('边距' in v for v in r['issues']));self.assertTrue(any('字号' in v for v in r['issues']))
    def test_wrong_metadata_is_rejected(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);d=Document(file);d.core_properties.title='Other project';d.core_properties.comments='generated by python-docx';d.save(file);self.assertTrue(any('元数据' in v for v in self.check(file)['issues']))
    def test_missing_toc_and_page_field_fail(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);d=Document(file)
        for node in list(d.element.xpath('.//w:instrText')):node.getparent().remove(node)
        for sec in d.sections:
            for node in list(sec.footer._element.xpath('.//w:instrText')):node.getparent().remove(node)
        d.save(file);r=self.check(file);self.assertTrue(any('目录' in v for v in r['issues']));self.assertTrue(any('页码' in v for v in r['issues']))
    def test_sow_argument_cannot_replace_required_written_argument(self):
        observed={'proposal_docx':{'text':'No required value here'},'proposal_pdf':{'text':'No required value here'},'sow_docx':{'text':'\n'.join(model.unit_texts(self.p,u,work=self.work)[0] for u in self.c['semantic_units'])}}
        self.p['outputs'].append('sow_docx');self.p['sow_required']=True
        self.p['artifact_projection'] += [{**r,'artifact_role':'sow_docx'} for r in self.p['artifact_projection'] if r['artifact_role']=='proposal_docx']
        self.assertTrue(model.projection_check(self.work,self.p,observed)['missing_unit_ids'])
    def test_present_optional_content_is_not_reported_as_an_omission(self):
        report=self.build();info=api.inspect(report['source_files']['proposal_docx']['path'],'proposal_docx')
        self.p['artifact_projection']=[r for r in self.p['artifact_projection'] if r['artifact_role']=='proposal_docx']
        self.p['artifact_projection'] += [{**r,'artifact_role':'sow_docx'} for r in self.p['artifact_projection']]
        self.p['outputs'].append('sow_docx');self.p['sow_required']=True
        result=model.projection_check(self.work,self.p,{'proposal_docx':info,'sow_docx':info})
        self.assertEqual(result['status'],'passed');self.assertEqual(result['artifact_gaps'],{})
    def test_toc_does_not_masquerade_as_actual_chapter(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);info=api.inspect(file,'proposal_docx');actual=model.actual_location(self.work,self.p,'proposal_docx','08',info)
        self.assertIn('Earlier visibility',actual);self.assertIn('Validation:',actual)
    def test_new_client_proposal_target_requires_business_and_expression(self):
        from model_fixtures import register_report
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);self.p['outputs']=['proposal_docx'];self.p['task_scope']='partial_artifact';self.p['artifact_projection']=[r for r in self.p['artifact_projection'] if r['artifact_role']=='proposal_docx'];api.save(self.work/'project.json',self.p);model.handoff(self.work,self.p)
        self.p['request_requirements'][0]['affected_outputs']=['proposal_docx']
        selection=copy.deepcopy(self.p['request_requirements'][0]);selection.update(id='RQ-EXPLICIT-OUTPUT',scope='outputs',affected_outputs=['proposal_docx']);self.p['request_requirements'].append(selection);api.save(self.work/'project.json',self.p);model.handoff(self.work,self.p)
        state,record=register_report(self.work,self.p,{'proposal_docx':file});record['proposal_reviews'][0]['result']='gap';api.save(self.work/'quality-review.json',record)
        state['production']=presentation.production_record(self.work,self.p,state);self.assertEqual(state['production']['issues'],[]);state['production']['time']='synthetic'
        issues,quality=presentation.release_issues(self.work,self.p,state,api.candidate(self.work,self.p,state));self.assertFalse(quality['target_met']);self.assertTrue(any('交付目标未达到' in v for v in issues))
    def test_a4_measurements_fit_the_actual_check_record_schema(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);m=self.check(file)['measurements']
        values={'body_min_pt':m['body_min_pt'],'heading1_min_pt':m['heading_min_pt']['1'],'heading2_min_pt':m['heading_min_pt']['2'],'heading3_min_pt':m['heading_min_pt']['3'],'line_spacing_min':min(m['line_spacing_values']),'line_spacing_max':max(m['line_spacing_values'])}
        record={'schema':1,'candidate_digest':'0'*64,'items':[{'id':'V01','status':'pass','location':'Native A4 styles','artifact_role':'proposal_docx','section_or_page':'01','reviewer':'TEST-CHECKER','reason':None,'evidence':[model.proof(file)],'measurements':values}]}
        contracts.validate(record,'check-records.schema.json');api.save(self.work/'checks.json',record)
        issues=gates.evidence_issues(self.work,self.p,{'producer':'TEST-PRODUCER'},'0'*64,api.filehash);self.assertFalse(any(v.startswith('V01:') for v in issues),issues)
    def test_native_table_reference_and_pagination_controls_are_written(self):
        plan=api.load(self.work/'document-plan.json');plan['chapters'][8]['blocks'][-1]['cross_reference']=True;api.save(self.work/'document-plan.json',plan)
        report=self.build();doc=Document(report['source_files']['proposal_docx']['path'])
        self.assertTrue(any('REF _proposal_table_1' in (n.text or '') for n in doc.element.xpath('.//w:instrText')))
        self.assertTrue(all(row._tr.xpath('./w:trPr/w:cantSplit') for table in doc.tables for row in table.rows))
        self.assertTrue(all(p.paragraph_format.keep_with_next for p in doc.tables[0].rows[0].cells[0].paragraphs))
        self.assertTrue(next(p for p in doc.paragraphs if p.style.name=='Caption').paragraph_format.keep_with_next)
    def test_pdf_running_metadata_does_not_break_a_cross_page_paragraph(self):
        unit=self.c['semantic_units'][0];claim=unit['claim'];left,right=claim.split('decision',1)
        body='01 Executive Summary\n'+left+'\n2026-10-27 | 3\nWorkflow Pilot Proposal | fixture-0.5\ndecision'+right+'\n02 Next chapter'
        info={'text':body};actual=model.actual_location(self.work,self.p,'proposal_pdf','01',info)
        self.assertIn(model.normalize(claim),model.normalize(actual))
        bad=model.actual_location(self.work,self.p,'proposal_pdf','01',{'text':body.replace('need','lose')})
        self.assertNotIn(model.normalize(claim),model.normalize(bad))
    def test_pdf_text_has_one_reading_order_and_separate_table_blocks(self):
        from reportlab.pdfgen import canvas
        import pdfplumber
        file=self.work/'reading-order.pdf';pdf=canvas.Canvas(str(file))
        pdf.drawString(60,780,'01 Executive Summary')
        pdf.drawString(60,750,'One complete decision paragraph.')
        for y in [700,675,650]:pdf.line(60,y,400,y)
        for x in [60,160,400]:pdf.line(x,650,x,700)
        pdf.drawString(65,682,'Item');pdf.drawString(165,682,'Basis')
        pdf.drawString(65,657,'Pilot');pdf.drawString(165,657,'Bounded scope')
        pdf.showPage();pdf.save()
        info=api.inspect(file,'proposal_pdf')
        with pdfplumber.open(file) as document:expected='\n'.join(page.extract_text() or '' for page in document.pages)
        self.assertEqual(info['text'],expected)
        self.assertEqual(info['text'].count('One complete decision paragraph.'),1)
        self.assertIn('Pilot | Bounded scope',info['blocks'])
    def test_authorized_word_font_override_is_applied_and_ppt_measurement_stays_separate(self):
        self.p['threshold_overrides']={'body_min_pt':12};self.p['threshold_override_evidence']='Synthetic existing template selection';api.save(self.work/'project.json',self.p);model.handoff(self.work,self.p)
        report=self.build();self.assertEqual(self.check(report['source_files']['proposal_docx']['path'])['measurements']['body_min_pt'],12)
        self.p['presentation_requested']=True
        record={'schema':1,'candidate_digest':'0'*64,'items':[{'id':'PV01','status':'pass','location':'Optional reporting page','reviewer':'TEST-CHECKER','reason':None,'evidence':[model.proof(Path(report['source_files']['proposal_docx']['path']))],'measurements':{'body_min_pt':12,'title_min_pt':28,'source_min_pt':10}}]};api.save(self.work/'checks.json',record)
        issues=gates.evidence_issues(self.work,self.p,{'producer':'TEST-PRODUCER'},'0'*64,api.filehash);self.assertTrue(any(v.startswith('PV01: body_min_pt') for v in issues),issues)

if __name__=='__main__':unittest.main(verbosity=2)
