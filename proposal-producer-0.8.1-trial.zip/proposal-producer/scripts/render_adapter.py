"""Portable, local PPTX/SOW/export adapter. Optional image providers use a JSON stdio protocol."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

import contracts
import facts
import proposal_model as model

ROOT=Path(__file__).resolve().parents[1]
def load(p):return contracts.load(p)
def save(p,data):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def proof(p):return {'path':str(Path(p).resolve()),'sha256':sha(p)}
def path(work,name):
    p=Path(name);return (p if p.is_absolute() else Path(work)/p).resolve()
def policy():return contracts.validate(load(ROOT/'contracts/visual-policy.json'),'visual-policy.schema.json')
def normalize(s):return ''.join(str(s).split()).replace(',','').replace('，','')

def task_config(work,project,presentation=False):
    work=Path(work).resolve()
    a=path(work,project.get('visual_profile') or 'visual-profile.json')
    b=path(work,project.get('render_policy') or 'render-policy.json')
    profile=contracts.validate(load(a) if a.is_file() else load(ROOT/'assets/visual-profile.json'),'visual-profile.schema.json')
    route=contracts.validate(load(b) if b.is_file() else load(ROOT/'assets/render-policy.json'),'render-policy.schema.json')
    if presentation and project.get('schema',0)>=7:
        import ppt_image_method
        route=ppt_image_method.task_route(work,route)
    return profile,route,a,b

def tool(name,route):
    if route.get('tools',{}).get(name):
        p=Path(route['tools'][name]).expanduser()
        if p.is_file() and os.access(p,os.X_OK):return str(p.resolve())
        return None
    found=shutil.which(name)
    if found:return found
    for base in list(Path(sys.executable).resolve().parents)[:4]:
        for suffix in policy()['runtime_relative_tool_dirs']:
            p=base/suffix/name
            if p.is_file() and os.access(p,os.X_OK):return str(p)
    if name=='soffice' and sys.platform=='darwin':
        p=Path('/Applications/LibreOffice.app/Contents/MacOS/soffice')
        if p.is_file():return str(p)
    return None

def font_environment(folder):
    """Isolate writable font caches and discover standard platform font roots."""
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);cache=folder/'cache';cache.mkdir(exist_ok=True)
    roots=[Path('/System/Library/Fonts'),Path('/Library/Fonts'),Path.home()/'Library/Fonts',Path('/usr/share/fonts'),Path('/usr/local/share/fonts'),Path.home()/'.local/share/fonts']
    if os.environ.get('WINDIR'):roots.append(Path(os.environ['WINDIR'])/'Fonts')
    root=ET.Element('fontconfig')
    for directory in roots:
        if directory.is_dir():ET.SubElement(root,'dir').text=str(directory)
    ET.SubElement(root,'cachedir').text=str(cache)
    config=folder/'fonts.conf';ET.ElementTree(root).write(config,encoding='utf-8',xml_declaration=True)
    env=os.environ.copy();env['FONTCONFIG_FILE']=str(config);env['XDG_CACHE_HOME']=str(folder)
    return env

def run(argv,**kwargs):
    result=subprocess.run([str(v) for v in argv],capture_output=True,text=True,timeout=kwargs.pop('timeout',90),**kwargs)
    if result.returncode:raise ValueError('工具执行失败 '+str(argv[0])+': '+(result.stderr or result.stdout)[-1800:])
    return result.stdout

def font_map(profile,route,folder):
    env=font_environment(folder);matcher=tool('fc-match',route);mapped={}
    choices=policy()['font_candidates']['zh' if profile['language'].startswith('zh') else 'other']
    for role in ['title','body']:
        requested=profile['fonts'][role]
        family=requested or choices[0];file=None;verified=False
        if matcher:
            for candidate in ([requested] if requested else choices):
                try:
                    output=run([matcher,'-f','%{family}\n%{file}\n',candidate],env=env,timeout=25).strip().splitlines()
                    if len(output)>=2:
                        family,file=output[0].split(',')[0],output[1]
                        matched=normalize(candidate).lower() in normalize(output[0]).lower()
                        verified=Path(file).is_file() and matched and 'LastResort' not in family
                        if verified:break
                except (ValueError,subprocess.TimeoutExpired):pass
        mapped[role]={'requested':requested,'actual_family':family,'file':file,'available':verified}
    return mapped,env

def doctor(work,project):
    profile,route,_,_=task_config(work,project)
    with tempfile.TemporaryDirectory(prefix='proposal-fonts-') as temp:
        fonts,_=font_map(profile,route,temp)
    modules={name:bool(importlib.util.find_spec(name)) for name in ['pptx','docx','PIL','pypdf','pdfplumber','jsonschema']}
    tools={name:tool(name,route) for name in policy()['tool_names']}
    required=[n for n in modules if n!='pptx' or model.has_ppt(project)]
    return {'python':sys.executable,'modules':modules,'required_modules':required,'tools':tools,'fonts':fonts,'native_build':all(modules[n] for n in required) and all(f['available'] for f in fonts.values()),'pdf_export':bool(tools['soffice']),'page_render':bool(tools['pdftoppm']),'image_provider':{'configured':bool(route['image_provider_command']),'authorization_recorded':bool(route.get('image_provider_authorization')),'status':'task_adapter' if route['image_provider_command'] else 'not_configured'},'host_hook':'not_assumed_installed'}

def mode_for(page,route):return route['page_modes'].get(page['page_id'],route['default_mode'])
def mode_issues(plan,route):
    issues=[];known={p['page_id'] for p in plan['pages']}
    if set(route['page_modes'])-known:issues.append('渲染路线引用未知页')
    for page in plan['pages']:
        mode=mode_for(page,route)
        if mode=='full_image':
            choice=route['full_image_choice']
            if not choice or page['page_id'] not in choice['page_ids']:issues.append(page['page_id']+': 整页图像需要已有的明确选择依据')
            if route['editable_text'] or route['editable_relations']:issues.append(page['page_id']+': 整页图像与逐对象编辑约定冲突')
    return issues

def catalog():return contracts.validate(load(ROOT/'assets/visual-kit/catalog.json'),'visual-catalog.schema.json')
def resource(ident):
    record=next((v for v in catalog()['assets'] if v['id']==ident),None)
    if record is None:raise ValueError('未知视觉资源 '+ident)
    p=(ROOT/record['path']).resolve()
    if not p.is_relative_to(ROOT) or not p.is_file() or sha(p)!=record['sha256']:raise ValueError('视觉资源路径或哈希无效 '+ident)
    return p

def frozen_copy(page):
    copy=page.get('copy',{})
    words=[copy.get('headline') or page['takeaway']]
    if copy.get('subtitle'):words.append(copy['subtitle'])
    words+=copy.get('body',[])
    if copy.get('source_note'):words.append(copy['source_note'])
    words += [v['label'] for v in page['objects']]+[v['meaning'] for v in page['relations']]
    table=copy.get('table')
    if table:words+=table['columns']+[cell for row in table['rows'] for cell in row]
    words+=list(page.get('visual',{}).get('time_labels',{}).values())
    return words

def _color(value):
    from pptx.dml.color import RGBColor
    return RGBColor.from_string(value.lstrip('#'))
def _wrap(text,width,height,pt):
    """Wrap the literal text without deleting words; return an overflow signal."""
    capacity=max(4,width*72/pt)
    lines=[]
    for raw in str(text).split('\n'):
        buf='';used=0
        for c in raw:
            import unicodedata
            cost=1 if unicodedata.east_asian_width(c) in ['W','F'] else .52
            if used+cost>capacity and buf:lines.append(buf);buf='';used=0
            buf+=c;used+=cost
        lines.append(buf)
    return '\n'.join(lines),len(lines)*pt*1.18/72>height

def text(slide,value,rect,font,pt,color,bold=False,name=None):
    from pptx.util import Inches,Pt
    box=slide.shapes.add_textbox(*(Inches(v) for v in rect));box.name=name or 'text'
    wrapped,overflow=_wrap(value,rect[2],rect[3],pt)
    frame=box.text_frame;frame.clear();frame.word_wrap=False
    frame.margin_left=frame.margin_right=0;frame.margin_top=frame.margin_bottom=0
    for index,line in enumerate(wrapped.split('\n')):
        paragraph=frame.paragraphs[0] if index==0 else frame.add_paragraph()
        paragraph.text=line;paragraph.font.name=font;paragraph.font.size=Pt(pt);paragraph.font.bold=bold;paragraph.font.color.rgb=_color(color)
        paragraph.space_after=Pt(0)
    return box,overflow

def clear_effects(shape):
    for item in shape._element.xpath('.//a:effectRef'):item.set('idx','0')

def icon(slide,ident,x,y,size,color):
    """Use original SVG geometry as editable shapes/lines; no raster icon dependency."""
    from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
    from pptx.util import Inches,Pt
    source=resource(ident)
    if source.suffix.lower()!='.svg':raise ValueError('原生图标使用 SVG 几何资源；Word 栅格变体不能用于原生图标 '+ident)
    tree=ET.parse(source).getroot();created=[]
    for item in tree:
        kind=item.tag.split('}')[-1];segments=[]
        if kind in ['circle','ellipse','rect']:
            if kind=='rect':rx,ry,w,h=[float(item.get(k,0)) for k in ['x','y','width','height']]
            else:
                rx=float(item.get('r') or item.get('rx'));ry=float(item.get('r') or item.get('ry'))
                w,h=rx*2,ry*2;rx=float(item.get('cx'))-rx;ry=float(item.get('cy'))-ry
            shape=slide.shapes.add_shape(MSO_SHAPE.OVAL if kind!='rect' else MSO_SHAPE.ROUNDED_RECTANGLE,Inches(x+rx/24*size),Inches(y+ry/24*size),Inches(w/24*size),Inches(h/24*size))
            shape.fill.background();shape.line.color.rgb=_color(color);shape.line.width=Pt(1.4);created.append(shape.shape_id)
        elif kind=='line':segments=[((float(item.get('x1')),float(item.get('y1'))),(float(item.get('x2')),float(item.get('y2'))))]
        elif kind in ['polyline','polygon']:
            points=[tuple(map(float,p.split(','))) for p in item.get('points').split()]
            if kind=='polygon':points.append(points[0])
            segments=list(zip(points,points[1:]))
        elif kind=='path':
            # The one curved person path is represented by editable shoulder segments.
            segments=[((5,21),(5,17)),((5,17),(8,13)),((8,13),(16,13)),((16,13),(19,17)),((19,17),(19,21))]
        for start,end in segments:
            shape=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x+start[0]/24*size),Inches(y+start[1]/24*size),Inches(x+end[0]/24*size),Inches(y+end[1]/24*size));shape.line.color.rgb=_color(color);shape.line.width=Pt(1.4);created.append(shape.shape_id)
    return created

def layout(page,width,height):
    """Composition varies by relation type; explicit task positions take precedence."""
    objects=page['objects'];n=max(1,len(objects));form=page.get('visual',{}).get('composition',page['visual_form'])
    explicit=page.get('visual',{}).get('positions',{})
    result={};x0=.65;top=2.0;usable=width-1.3
    if page.get('_model_version')==2 and form=='comparison' and n==2:
        for i,item in enumerate(objects):result[item['object_id']]=[x0+i*usable/2,2.1,usable/2-.35,2.3]
    elif page.get('_model_version')==2 and form=='value_chain' and n<=3:
        for i,item in enumerate(objects):result[item['object_id']]=[x0+i*usable/n,2.75-i*.4,usable/n-.45,1.0]
    elif form=='interaction_architecture' and n<=4:
        for i,item in enumerate(objects):result[item['object_id']]=[width/2-1.9,1.9+i*1.25,3.8,.8]
    elif form in ['interaction_architecture','value_chain']:
        cols=min(3,n);rows=math.ceil(n/cols);w=min(3.4,(usable-.7*(cols-1))/cols);h=min(1.05,3.5/rows)
        for i,item in enumerate(objects):result[item['object_id']]=[x0+(i%cols)*(usable/cols),top+(i//cols)*(3.5/rows),w,h]
    elif form in ['comparison','scene']:
        cols=min(2,n);rows=math.ceil(n/cols);w=usable/cols-.5
        for i,item in enumerate(objects):result[item['object_id']]=[x0+(i%cols)*(usable/cols),top+(i//cols)*1.4,w,1.0]
    elif form in ['timeline','journey','workflow']:
        cols=min(5,n);rows=math.ceil(n/cols);w=usable/cols-.35
        for i,item in enumerate(objects):result[item['object_id']]=[x0+(i%cols)*(usable/cols),top+(i//cols)*1.65,w,1.1]
    else:
        cols=min(3,n);rows=math.ceil(n/cols)
        for i,item in enumerate(objects):result[item['object_id']]=[x0+(i%cols)*usable/cols,top+(i//cols)*1.4,usable/cols-.45,1.0]
    result.update({k:[r[0]*13.333333,r[1]*height,r[2]*13.333333,r[3]*height] for k,r in explicit.items()})
    return result

def image_asset(work,plan,ident):
    from PIL import Image
    item=next((v for v in plan.get('visual_assets',[]) if v['asset_id']==ident),None)
    if item is None:raise ValueError('图片素材未登记 '+str(ident))
    file=path(work,item['source']['path'])
    if not file.is_file() or sha(file)!=item['source']['sha256']:raise ValueError('图片素材缺失或变化 '+ident)
    with Image.open(file) as im:dimensions=list(im.size);im.verify()
    return file,dimensions,item

def build(work,project,plan,destination,calibration=False,page_ids=None,stage=None):
    if project.get('schema',0)>=7:
        import production_chain
        production_chain.enforce(work,project,'presentation' if calibration or stage=='presentation' else 'proposal')
        if not calibration and stage!='presentation':
            import written_proposal
            return written_proposal.build(work,project,destination)
    if model.active(project) and not model.has_ppt(project):
        import document_adapter
        return document_adapter.build(work,project,destination)
    destination=Path(destination).resolve()
    if destination.exists():raise ValueError('候选目录已存在，使用新版本位置')
    try:return _build(work,project,plan,destination,calibration,page_ids)
    except Exception as exc:
        if destination.is_dir():save(destination/'failure.json',{'status':'failed','error':str(exc),'candidate_directory':str(destination)})
        raise

def _build(work,project,plan,destination,calibration=False,page_ids=None):
    if model.active(project) and plan.get('schema')==2:plan=model.materialized_plan(work,project,plan)
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
    from pptx.util import Inches,Pt
    from pptx.oxml.xmlchemy import OxmlElement
    work=Path(work).resolve();destination=Path(destination).resolve()
    if destination.exists():raise ValueError('候选目录已存在，使用新版本位置；保留原候选')
    destination.mkdir(parents=True)
    profile,route,profile_path,route_path=task_config(work,project,presentation=True)
    problems=mode_issues(plan,route)
    if problems:raise ValueError('；'.join(problems))
    palettes=profile['palette'] or policy()['fallback_palette'];thresholds=contracts.visual_limits(presentation=True)
    fonts,_=font_map(profile,route,destination/'font-environment')
    if not all(v['available'] for v in fonts.values()):raise ValueError('所选字体未匹配可用字体；先运行 doctor 并在任务配置中选择实际字体')
    body_font=fonts['body']['actual_family'];title_font=fonts['title']['actual_family']
    deck=Presentation();deck.slide_width=Inches(13.333333);deck.slide_height=Inches(7.5)
    selected=[p for p in plan['pages'] if (p['key_page'] if calibration and not page_ids else True) and (not page_ids or p['page_id'] in page_ids)]
    if not selected:raise ValueError('未选中可制作页面')
    image_method_evidence=None
    if project.get('schema',0)>=7:
        import ppt_image_method
        image_method_evidence=ppt_image_method.evidence(work,project,plan,selected)
        deck.slide_width,deck.slide_height=ppt_image_method.rules()['canvas_emu']
    report={'schema':1,'plan_sha256':sha(path(work,project.get('presentation_plan') or 'presentation-plan.json')),'profile_sha256':sha(profile_path) if profile_path.is_file() else hashlib.sha256(json.dumps(profile,sort_keys=True).encode()).hexdigest(),'render_policy_sha256':sha(route_path) if route_path.is_file() else hashlib.sha256(json.dumps(route,sort_keys=True).encode()).hexdigest(),'project_sha256':sha(work/'project.json'),'directory':str(destination),'source_files':{},'pages':[],'exports':{},'runtime':{'fonts':fonts,'python':sys.version.split()[0]},'status':'partial' if calibration else 'candidate'}
    if model.active(project):
        report['model_digest']=model.digest({'base':model.base(work),'story':model.story(work)})
        report['runtime']['catalogue']=proof(ROOT/'assets/visual-kit/catalog.json')
    from proposal import calculate
    calculation=calculate(project)
    if calculation['issues']:raise ValueError('；'.join(calculation['issues']))
    if not calibration:
        source_issues=facts.project_issues(project)
        if source_issues:raise ValueError('；'.join(source_issues))
    import client_content
    footers=([v['text'] for v in facts.expected(project,calculation,work)['facts'] if v['id'] in ['date','version']] if client_content.active(project) else facts.fact_texts(project,calculation,work))
    for page in selected:
        slide=deck.slides.add_slide(deck.slide_layouts[6]);slide.background.fill.solid();slide.background.fill.fore_color.rgb=_color(palettes['background'])
        spec=page.get('visual',{});copy=page.get('copy',{});mode=mode_for(page,route);form=spec.get('composition',page['visual_form'])
        if model.active(project):
            spec=dict(spec);feature=profile.get('feature_use',{})
            if feature.get('icons')=='off':spec['icon_ids']={}
            elif not spec.get('icon_ids'):
                required=feature.get('icons')=='required' or any(r['feature']=='icons' and r['expectation']=='required' and r['section_or_page']==page['page_id'] and r['artifact_role'] in ['pptx','ppt_pdf'] for r in project.get('requirement_realizations',[]))
                if page['objects'] and (required or 'icon_ids' not in spec):
                    obj=page['objects'][0];unit=plan.get('_shared_units',{}).get(obj['semantic_ref'],{});fields=set(unit.get('field_refs',[]))
                    ident='person' if obj['semantic_ref'].startswith('SC') else 'settings' if obj['semantic_ref'].startswith('ME') or 'F09' in fields else 'chart' if obj['semantic_ref'].startswith('VA') or 'F14' in fields else 'document'
                    spec['icon_ids']={obj['object_id']:ident}
        record={'page_id':page['page_id'],'slide_number':len(deck.slides),'mode':mode,'composition':form,'frozen_text':frozen_copy(page),'objects':[],'relations':[],'assets':[],'overflow':[],'native_text_editable':mode!='full_image','native_relations_editable':mode!='full_image','visual_review':'pending'}
        if mode=='full_image':
            record['frozen_text']+=footers
            asset_id=spec.get('background_asset_id')
            if asset_id is None:
                if not route['image_provider_command']:raise ValueError(page['page_id']+': 需要已有整页图像或任务图像生成适配器')
                if not route.get('image_provider_authorization'):raise ValueError('任务图像生成适配器缺已有调用授权依据')
                reply=json.loads(run(route['image_provider_command'],input=json.dumps({'page':page,'visual_profile':profile,'output_directory':str(destination)},ensure_ascii=False)))
                generated=path(destination,reply['path'])
                # Provider metadata never substitutes for actual image inspection.
                from PIL import Image
                with Image.open(generated) as im:dimensions=list(im.size);im.verify()
                item={'identity':'illustrative_generated','source_description':'task image provider','rights':reply.get('rights','task authorization')}
                file=generated
            else:file,dimensions,item=image_asset(work,plan,asset_id)
            ratio=dimensions[0]/dimensions[1];w=min(13.333333,7.5*ratio);h=w/ratio
            picture=slide.shapes.add_picture(str(file),Inches((13.333333-w)/2),Inches((7.5-h)/2),width=Inches(w),height=Inches(h));picture.name='full-image:'+page['page_id']
            record['image']=proof(file);record['image_size']=dimensions;record['image_shape_id']=picture.shape_id;record['crop']=[0,0,0,0]
            regions=spec.get('image_regions',{})
            for kind,key in [('objects','object_id'),('relations','relation_id')]:
                for original in page[kind]:
                    ident=original[key]
                    if ident not in regions:raise ValueError(page['page_id']+': 图像缺可定位区域 '+ident)
                    record[kind].append({key:ident,'region':regions[ident]})
        else:
            title,overflow=text(slide,copy.get('headline') or page['takeaway'],[.6,.38,12.1,.9],title_font,thresholds['title_min_pt'],palettes['text'],True,'headline')
            if overflow:record['overflow'].append('headline')
            if copy.get('subtitle'):_,over=text(slide,copy['subtitle'],[.62,1.26,12.0,.5],body_font,thresholds['body_min_pt'],palettes['muted'],name='subtitle');record['overflow']+=['subtitle'] if over else []
            asset_ids=spec.get('asset_ids',[]) if mode=='hybrid' else []
            if model.active(project):
                registry={a['asset_id']:a for a in plan.get('visual_assets',[])}
                asset_ids=[ident for ident in asset_ids if profile.get('feature_use',{}).get(spec.get('asset_uses',{}).get(ident,'output_examples' if registry[ident]['identity']=='product_screenshot' else 'scene_assets'))!='off']
            for index,ident in enumerate(asset_ids):
                file,dimensions,item=image_asset(work,plan,ident)
                slot_h=3.6/max(1,len(asset_ids));image_rect=[8.8,2.0+index*slot_h,3.9,max(.2,slot_h-.12)];ratio=dimensions[0]/dimensions[1];w=min(image_rect[2],image_rect[3]*ratio);h=w/ratio
                pic=slide.shapes.add_picture(str(file),Inches(image_rect[0]),Inches(image_rect[1]),width=Inches(w),height=Inches(h));pic.name='asset:'+ident
                record['assets'].append({'asset_id':ident,'shape_id':pic.shape_id,'source':proof(file),'dimensions':dimensions,'identity':item['identity'],'crop':[0,0,0,0],'feature':spec.get('asset_uses',{}).get(ident,'output_examples' if item['identity']=='product_screenshot' else 'scene_assets')})
            positions=layout(page,8.6 if asset_ids else 13.333333,7.5);shapes={}
            table=copy.get('table')
            if table:
                from pptx.enum.text import MSO_ANCHOR
                rows,cols=len(table['rows']),len(table['columns'])
                if rows>thresholds['table_max_data_rows'] or cols>thresholds['table_max_columns']:raise ValueError('表格超出默认阈值，请调整页计划或放入 SOW')
                shape=slide.shapes.add_table(rows+1,cols,Inches(.65),Inches(2.0),Inches(12.0),Inches(min(3.5,.5*(rows+1))));shape.name='business-table'
                for i,row in enumerate([table['columns']]+table['rows']):
                    if len(row)!=cols:raise ValueError('表格行列不一致')
                    for j,value in enumerate(row):
                        cell=shape.table.cell(i,j);cell.text=str(value);cell.vertical_anchor=MSO_ANCHOR.MIDDLE
                        cell.fill.solid();cell.fill.fore_color.rgb=_color(palettes['primary'] if i==0 else palettes['surface'])
                        for para in cell.text_frame.paragraphs:para.font.name=body_font;para.font.size=Pt(thresholds['table_cell_min_pt']);para.font.color.rgb=_color(palettes['background'] if i==0 else palettes['text'])
                record['table_shape_id']=shape.shape_id
                # Semantic objects still have visible native labels alongside the table.
                for i,item in enumerate(page['objects']):positions[item['object_id']]=[.65+i*12/max(1,len(page['objects'])),5.5,12/max(1,len(page['objects']))-.25,.55]
            for index,item in enumerate(page['objects']):
                rect=positions.get(item['object_id'])
                if rect is None:raise ValueError('构图缺对象位置 '+item['object_id'])
                x,y,w,h=rect
                round_node=form in ['timeline','journey','workflow'] and not table
                shape_type=MSO_SHAPE.OVAL if round_node else MSO_SHAPE.ROUNDED_RECTANGLE
                drawn=[x+w/2-.3,y+.35,.6,.6] if round_node else rect
                outcome=(form in ['value_chain','comparison'] and item['semantic_ref'] in {v['value_id'] for v in plan['values']}) or item['object_id'] in spec.get('emphasis_ids',[])
                shape=slide.shapes.add_shape(shape_type,*(Inches(v) for v in drawn));shape.name='object:'+item['object_id'];shape.fill.solid();shape.fill.fore_color.rgb=_color(palettes['primary'] if outcome else palettes['surface']);shape.line.color.rgb=_color(palettes['primary']);shape.line.width=Pt(1.3);clear_effects(shape)
                label_rect=[x,y+1.02,w,.55] if round_node else [x+.12,y+.12,w-.24,h-.24]
                label,over=text(slide,item['label'],label_rect,body_font,thresholds['diagram_label_min_pt'],palettes['background'] if outcome else palettes['text'],True,'label:'+item['object_id'])
                from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
                label.text_frame.vertical_anchor=MSO_ANCHOR.MIDDLE
                for para in label.text_frame.paragraphs:para.alignment=PP_ALIGN.CENTER
                if over:record['overflow'].append(item['object_id'])
                shapes[item['object_id']]=shape
                entry={'object_id':item['object_id'],'shape_id':shape.shape_id,'label_shape_id':label.shape_id,'rect':[drawn[0]/13.333333,drawn[1]/7.5,drawn[2]/13.333333,drawn[3]/7.5]}
                ident=spec.get('icon_ids',{}).get(item['object_id'])
                if ident:entry['icon_shape_ids']=icon(slide,ident,drawn[0]+.12 if round_node else x+.08,drawn[1]+.12 if round_node else y-.4,.35,palettes['primary'])
                elif round_node:
                    number,_=text(slide,str(index+1),[drawn[0],drawn[1]+.12,.6,.3],body_font,thresholds['diagram_label_min_pt'],palettes['primary'],True)
                    for para in number.text_frame.paragraphs:para.alignment=PP_ALIGN.CENTER
                record['objects'].append(entry)
            if model.active(project) and form=='timeline' and len(record['objects'])>1:
                axis=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(.9),Inches(4.2),Inches(12.4),Inches(4.2));axis.line.color.rgb=_color(palettes['muted']);axis.line.width=Pt(1);record['composition_shape_ids']=[axis.shape_id]
                for obj in record['objects']:
                    shape=shapes[obj['object_id']];cx=shape.left+shape.width/2
                    tick=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,cx,Inches(4.06),cx,Inches(4.34));tick.line.color.rgb=_color(palettes['primary']);record['composition_shape_ids'].append(tick.shape_id)
                    value=spec.get('time_labels',{}).get(obj['object_id'])
                    if value:
                        label,over=text(slide,value,[cx/914400-1.15,4.5,2.3,.45],body_font,thresholds['diagram_label_min_pt'],palettes['primary'],True);record['composition_shape_ids'].append(label.shape_id)
                        if over:record['overflow'].append('time:'+obj['object_id'])
            for original in page['relations']:
                a,b=shapes[original['from']],shapes[original['to']]
                connector=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,0,0,1,1);connector.name='relation:'+original['relation_id']
                oval_a=a.auto_shape_type==MSO_SHAPE.OVAL;oval_b=b.auto_shape_type==MSO_SHAPE.OVAL
                vertical=abs((a.top+a.height/2)-(b.top+b.height/2))>abs((a.left+a.width/2)-(b.left+b.width/2))
                # python-pptx computes four rectangular ports; ellipse XML has eight.
                connector.begin_connect(a,2 if vertical else 3);connector.end_connect(b,0 if vertical else 1)
                start_site=(4 if vertical else 6) if oval_a else (2 if vertical else 3)
                end_site=0 if vertical else (2 if oval_b else 1)
                connector._element.xpath('.//a:stCxn')[0].set('idx',str(start_site));connector._element.xpath('.//a:endCxn')[0].set('idx',str(end_site))
                connector.line.color.rgb=_color(palettes['accent']);connector.line.width=Pt(1.6);clear_effects(connector)
                end=OxmlElement('a:tailEnd');end.set('type','triangle');connector._element.spPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ln').append(end)
                ax,ay,aw,ah=positions[original['from']];bx,by,bw,bh=positions[original['to']]
                label_y=min(ay,by)-.25 if oval_a and oval_b else max(ay,by)+max(ah,bh)+.12
                center=(a.left+a.width+b.left)/2/914400
                label_rect=[max(ax+aw,bx+bw)+.25,(ay+ah+by)/2-.25,2.4,.6] if vertical else [center-1.15,label_y,2.3,.55]
                label,over=text(slide,original['meaning'],label_rect,body_font,thresholds['diagram_label_min_pt'],palettes['muted'],name='relation-label:'+original['relation_id'])
                for para in label.text_frame.paragraphs:para.alignment=PP_ALIGN.CENTER
                if over:record['overflow'].append(original['relation_id'])
                record['relations'].append({'relation_id':original['relation_id'],'shape_id':connector.shape_id,'label_shape_id':label.shape_id,'from_shape_id':a.shape_id,'to_shape_id':b.shape_id,'from_site':start_site,'to_site':end_site})
            if copy.get('body'):
                body_rect=[.65,6.25,12.0,.45]
                if model.active(project) and not table:body_rect=[.65,5.65,12.0,1.05]
                if spec.get('body_position'):body_rect=[spec['body_position'][0]*13.333333,spec['body_position'][1]*7.5,spec['body_position'][2]*13.333333,spec['body_position'][3]*7.5]
                _,over=text(slide,'\n'.join(copy['body']),body_rect,body_font,thresholds['body_min_pt'],palettes['text'],name='body')
                if over:record['overflow'].append('body')
            if copy.get('source_note'):text(slide,copy['source_note'],[.65,6.8,12,.22],body_font,thresholds['source_min_pt'],palettes['muted'],name='business-source')
            if footers:
                text(slide,'   '.join(footers),[.65,7.04,12,.25],body_font,thresholds['source_min_pt'],palettes['muted'],name='shared-facts')
            text(slide,str(record['slide_number']),[12.6,7.04,.25,.25],body_font,thresholds['source_min_pt'],palettes['muted'],name='page-number')
        report['pages'].append(record)
    ppt=destination/'proposal.pptx';deck.save(ppt);report['source_files']['pptx']=proof(ppt)
    if image_method_evidence is not None:
        image_method_evidence['files'].append(ppt_image_method.validate_deck(work,project,plan,ppt,destination,selected))
        report['runtime']['ppt_image_render']=image_method_evidence
    # A parse/edit/save/reopen round trip tests OOXML editability, not a particular GUI application.
    reopened=Presentation(ppt);copy_file=destination/'reopen-check.pptx';reopened.save(copy_file);Presentation(copy_file);copy_file.unlink()
    report['runtime']['source_reopen']='python-pptx round trip'
    if {'sow_docx','sow_pdf'} & set(project['outputs']) and not calibration and not model.written(project):
        sow=destination/'sow.docx';build_sow(project,plan,sow,profile,fonts,calculation,asset_bindings=report['runtime'].setdefault('asset_bindings',[]));report['source_files']['sow_docx']=proof(sow)
    if project.get('schema',0)>=7 and not calibration:
        import production_chain
        _,upstream=production_chain.written_manifest(work,project)
        report['source_files'].update(deepcopy(upstream['source_files']))
        report['exports'].update(deepcopy(upstream['exports']))
        report['runtime'].update(production_stage='presentation',document_plan_sha256=upstream['runtime']['document_plan_sha256'])
        report['runtime'].setdefault('asset_bindings',[]).extend(upstream['runtime'].get('asset_bindings',[]))
    elif model.written(project) and not calibration:
        import written_proposal
        written_proposal.add_sources(work,project,destination,report,profile,fonts,calculation)
    if model.active(project) and not model.written(project) and not calibration:
        if {'proposal_docx','proposal_pdf'}&set(project['outputs']):
            file=destination/'written-proposal.docx';build_sow(project,plan,file,profile,fonts,calculation,role='proposal_docx',asset_bindings=report['runtime'].setdefault('asset_bindings',[]));report['source_files']['proposal_docx']=proof(file)
        if 'proposal_md' in project['outputs']:
            units={v['id']:v for v in model.base(work)['semantic_units']};parts=['# '+str(project.get('project_label') or project['audience'])]+facts.fact_texts(project,calculation,work)
            for row in model.projection_rows(project,'proposal_md'):
                parts.append('## '+row['section_or_page'])
                for ref in row['source_refs']:parts+=model.unit_texts(project,units[ref],model.projection_summary(row),work)
            file=destination/'proposal.md';file.write_text('\n\n'.join(parts)+'\n');report['source_files']['proposal_md']=proof(file)
    report['status']='failed' if any(p['overflow'] for p in report['pages']) else report['status']
    save(destination/'render-manifest.json',report)
    if not calibration:save(work/'render-manifest.json',report)
    return report

def add_document_assets(document,heading,project,plan,file,profile,role,anchor,index,bindings):
    """Insert declared images and same-family icons into actual Word content."""
    from docx.shared import Inches
    from PIL import Image
    work=Path(plan['_workdir']);file=Path(file);folder=file.parent/(file.stem+'-assets');folder.mkdir(exist_ok=True)
    pdf_role='sow_pdf' if role=='sow_docx' else 'proposal_pdf'
    rows=[r for r in project.get('requirement_realizations',[]) if r['artifact_role'] in [role,pdf_role] and r['section_or_page']==anchor]
    features=profile.get('feature_use',{})
    wanted_icons=any(r['feature']=='icons' and r['expectation']=='required' for r in rows) or (index==0 and features.get('icons')=='required')
    if wanted_icons and features.get('icons')!='off':
        projection=next((r for r in model.projection_rows(project,role) if r['section_or_page']==anchor),None)
        unit_fields={f for ref in (projection or {}).get('source_refs',[]) for f in plan['_shared_units'][ref]['field_refs']}
        ident='chart' if 'F14' in unit_fields else 'settings' if 'F09' in unit_fields else 'document'
        original=resource(ident+'-raster');image=Image.open(original).convert('RGBA');color=(profile['palette'] or policy()['fallback_palette'])['primary']
        tinted=Image.new('RGBA',image.size,color);tinted.putalpha(image.getchannel('A'));target=folder/(anchor.split()[0]+'-'+ident+'.png');tinted.save(target)
        heading.add_run().add_picture(str(target),width=Inches(.25))
        if bindings is not None:bindings.append({'artifact_role':role,'section_or_page':anchor,'asset_id':ident,'feature':'icons','source':proof(target),'catalogue_source':proof(original)})
    row=next((r for r in model.projection_rows(project,role) if r['section_or_page']==anchor),None)
    for ident in (row or {}).get('asset_refs',[]):
        source,dimensions,item=image_asset(work,{'visual_assets':project.get('visual_assets',[])},ident)
        feature=next((r['feature'] for r in rows if ident in r.get('asset_refs',[]) and r['feature'] in ['scene_assets','output_examples']),'output_examples' if item['identity']=='product_screenshot' else 'scene_assets')
        if features.get(feature)=='off':continue
        import client_content
        if client_content.active(project) and not item.get('client_caption'):raise ValueError('CC02: 客户图片需要 client_caption '+ident)
        document.add_picture(str(source),width=Inches(4.8))
        if client_content.active(project):
            import written_proposal as written
            caption=document.add_paragraph(style='Caption');written.field(caption,'SEQ Figure \\* ARABIC',str(len(document.inline_shapes)));caption.add_run(' '+item['client_caption'])
        else:document.add_paragraph(item['source_description'])
        if bindings is not None:bindings.append({'artifact_role':role,'section_or_page':anchor,'asset_id':ident,'feature':feature,'identity':item['identity'],'source':proof(source),'dimensions':dimensions})

def build_sow(project,plan,file,profile,fonts,calculation,role='sow_docx',asset_bindings=None):
    from docx import Document
    from docx.shared import Pt,Mm
    work=Path(plan['_workdir']) if plan.get('_workdir') else None
    document=Document();thresholds=contracts.visual_limits(project);section=document.sections[0]
    section.top_margin=section.bottom_margin=section.left_margin=section.right_margin=Mm(thresholds['sow_margin_min_mm'])
    style=document.styles['Normal'];style.font.name=fonts['body']['actual_family'];style.font.size=Pt(thresholds['sow_body_min_pt'])
    from docx.oxml.ns import qn
    from docx.shared import RGBColor
    colors=profile['palette'] or policy()['fallback_palette']
    def set_font(style,name):
        style.font.name=name
        rpr=style.element.get_or_add_rPr();rfonts=rpr.rFonts
        for attr in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:
            rfonts.attrib.pop(qn('w:'+attr),None)
        for attr in ['ascii','hAnsi','eastAsia','cs']:rfonts.set(qn('w:'+attr),name)
    for name in ['Normal','Title','Heading 1','Heading 2','Heading 3']:
        style=document.styles[name];set_font(style,fonts['body']['actual_family'])
        style.font.color.rgb=RGBColor.from_string(colors['text' if name=='Normal' else 'primary'].lstrip('#'))
        for border in style.element.xpath('.//w:pBdr/*'):
            border.attrib.pop(qn('w:themeColor'),None)
            border.set(qn('w:color'),colors['primary'].lstrip('#'))
    document.add_heading(plan.get('project_label') or project.get('audience') or 'Proposal',0)
    for value in facts.fact_texts(project,calculation,work):document.add_paragraph(value)
    packages=project.get('work_packages',[]);sections=project.get('sow_sections',[])
    if role=='proposal_docx':sections=[{'anchor':r['section_or_page'],'title':''} for r in model.projection_rows(project,role)]
    if not sections:sections=[{'anchor':'S01','title':'Scope and objectives'},{'anchor':'S02','title':'Deliverables and acceptance'},{'anchor':'S03','title':'Commercial terms and next decision'}]
    for index,entry in enumerate(sections):
        heading=document.add_heading((entry['anchor']+' '+entry['title']).strip(),1)
        if model.active(project):add_document_assets(document,heading,project,plan,file,profile,role,entry['anchor'],index,asset_bindings)
        for paragraph in entry.get('paragraphs',[]):document.add_paragraph(paragraph)
        if model.active(project):
            units=plan.get('_shared_units',{})
            for row in model.projection_rows(project,role):
                if row['section_or_page']==entry['anchor']:
                    for ref in row['source_refs']:
                        for value in model.unit_texts(project,units[ref],model.projection_summary(row),work):document.add_paragraph(value)
        for package in packages:
            if package['sow_anchor']==entry['anchor']:document.add_paragraph(package['id']+' — '+package['title'])
        selected=set(entry.get('source_fields',[]))
        if not selected and role=='sow_docx' and (project.get('schema',0)<7 or 'source_fields' not in entry):selected={'scope','deliverables','acceptance','milestones'} if index==0 else {'pricing','requirements','decision'} if index==len(sections)-1 else set()
        if 'scope' in selected:
            for value in project['scope']:document.add_paragraph(value)
        if 'deliverables' in selected:
            entries=project.get('deliverable_details') or [{'id':d['deliverable_id'],**d} for d in plan['deliverables']]
            for item in entries:
                name=document.add_paragraph(item['id']+' — '+item['name']+(' — '+item['owner'] if item.get('owner') else ''));name.paragraph_format.keep_with_next=True
                document.add_paragraph(item['acceptance'])
        if 'acceptance' in selected:
            for value in project['acceptance']:document.add_paragraph(value)
        if 'milestones' in selected:
            for milestone in facts.expected(project,calculation)['milestones']:
                document.add_paragraph(milestone['title']);document.add_paragraph(milestone['text']);document.add_paragraph(milestone['trigger'])
        if 'pricing' in selected:
            for item in plan['fee_value_mappings']:
                document.add_paragraph(item['fee_id']+': '+', '.join(item['work_package_ids'])+' → '+', '.join(item['deliverable_ids'])+'; '+item['coverage_period'])
        if 'requirements' in selected:
            expected=facts.expected(project,calculation)
            if expected['mappings']:
                import client_content
                if client_content.active(project):
                    import written_proposal as written
                    caption=document.add_paragraph(style='Caption');caption.paragraph_format.keep_with_next=True
                    caption.add_run('表 ' if model.client_language(work)=='zh' else 'Table ');written.field(caption,'SEQ Table \\* ARABIC',str(len(document.tables)+1));caption.add_run(' '+('需求与工作包对应' if model.client_language(work)=='zh' else 'Requirements and work packages'))
                table=document.add_table(rows=1,cols=4);table.style='Table Grid'
                for cell,value in zip(table.rows[0].cells,['Requirement','Priority','Work package','Section']):cell.text=value
                from docx.oxml import OxmlElement
                header=OxmlElement('w:tblHeader');header.set(qn('w:val'),'true');table.rows[0]._tr.get_or_add_trPr().append(header)
                for item in expected['mappings']:
                    for cell,value in zip(table.add_row().cells,[item['requirement_id'],item['priority'],item['work_package_id'],item['sow_anchor']]):cell.text=value
                for index_row,row in enumerate(table.rows):
                    row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
                    if index_row==0:
                        for cell in row.cells:
                            for paragraph in cell.paragraphs:paragraph.paragraph_format.keep_with_next=True
        if 'business_terms' in selected:
            for name,value in project.get('business',{}).get('contract_terms',{}).items():
                document.add_paragraph(name+': '+str(value))
        if 'decision' in selected:document.add_paragraph(project['decision'] or '')
    # Explicit run fonts also cover tables and template-inherited theme fonts.
    paragraphs=list(document.paragraphs)+[p for t in document.tables for row in t.rows for cell in row.cells for p in cell.paragraphs]
    for paragraph in paragraphs:
        for run in paragraph.runs:set_font(run,fonts['body']['actual_family'])
    document.save(file)
    from docx import Document as Reopen
    reopened=Reopen(file);reopened.save(file);Reopen(file)

def pdf_fonts(file):
    from pypdf import PdfReader
    result=[]
    for page in PdfReader(file).pages:
        fonts=page.get('/Resources',{}).get('/Font',{})
        for item in fonts.values():
            font=item.get_object();desc=font.get('/DescendantFonts');font=desc[0].get_object() if desc else font
            descriptor=font.get('/FontDescriptor');descriptor=descriptor.get_object() if descriptor else {}
            result.append({'name':str(font.get('/BaseFont','')),'embedded':any(k in descriptor for k in ['/FontFile','/FontFile2','/FontFile3'])})
    return list({(v['name'],v['embedded']):(v) for v in result}.values())

def document_asset_issues(report):
    """Check actual Word embeddings as well as their immutable source proofs."""
    from zipfile import ZipFile
    issues=[]
    for role,entry in report['source_files'].items():
        file=Path(entry['path'])
        if not role.endswith('_docx') or not file.is_file():continue
        with ZipFile(file) as archive:embedded={hashlib.sha256(archive.read(n)).hexdigest() for n in archive.namelist() if n.startswith('word/media/')}
        for binding in report['runtime'].get('asset_bindings',[]):
            if binding['artifact_role']!=role:continue
            if binding['source']['sha256'] not in embedded:issues.append(role+': 文稿中缺实际资源 '+binding['asset_id'])
            for key in ['source','catalogue_source']:
                evidence=binding.get(key)
                if evidence and (not Path(evidence['path']).is_file() or sha(evidence['path'])!=evidence['sha256']):issues.append(role+': 资源来源变化 '+binding['asset_id'])
    evidence=report['runtime'].get('catalogue')
    if evidence and (not Path(evidence['path']).is_file() or sha(evidence['path'])!=evidence['sha256']):issues.append('视觉资源目录已变化')
    return issues

def export(work,project,manifest_file):
    from pypdf import PdfReader
    work=Path(work).resolve();manifest_file=Path(manifest_file).resolve();report=contracts.validate(load(manifest_file),'render-manifest.schema.json')
    profile,route,_,_=task_config(work,project);folder=Path(report['directory']);env=font_environment(folder/'font-environment')
    converter=tool('soffice',route);raster=tool('pdftoppm',route)
    if not converter:raise ValueError('未发现 PDF 导出工具 soffice；在任务 render-policy.tools 中登记可用工具')
    exported=folder/('exports-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));exported.mkdir(exist_ok=False)
    version=run([converter,'--version'],env=env,timeout=30).strip()
    with tempfile.TemporaryDirectory(prefix='office-profile-',dir=folder) as temp:
        for role,entry in report['source_files'].items():
            if role=='proposal_md':continue
            if report['runtime'].get('production_stage')=='presentation' and role!='pptx':
                target='proposal_pdf' if role=='proposal_docx' else 'sow_pdf'
                if target not in report['exports'] or sha(entry['path'])!=entry['sha256'] or sha(report['exports'][target]['file']['path'])!=report['exports'][target]['file']['sha256']:raise ValueError('PPT 引用的上游文档或 PDF 已变化 '+role)
                continue
            source=Path(entry['path'])
            if sha(source)!=entry['sha256']:raise ValueError('源稿变化，先重新制作候选 '+role)
            run([converter,'-env:UserInstallation='+Path(temp).as_uri(),'--headless','--convert-to','pdf','--outdir',exported,source],env=env,timeout=120)
            pdf=exported/(source.stem+'.pdf')
            if not pdf.is_file():raise ValueError('导出未生成 PDF '+role)
            target='ppt_pdf' if role=='pptx' else 'proposal_pdf' if role=='proposal_docx' else 'sow_pdf'
            record={'file':proof(pdf),'pages':len(PdfReader(pdf).pages),'fonts':pdf_fonts(pdf),'tool':converter,'tool_version':version,'font_mapping':report['runtime']['fonts']}
            if model.written(project) and role in ['proposal_docx','sow_docx']:
                import written_proposal
                record=written_proposal.finalize_export(work,project,role,source,record,converter,exported,env)
                report['source_files'][role]=proof(source);record['fonts']=pdf_fonts(record['file']['path'])
            if raster:
                renders=exported/(role+'-pages');renders.mkdir(exist_ok=True)
                run([raster,'-png','-r','120',pdf,renders/'page'],env=env,timeout=120)
                images=sorted(renders.glob('page-*.png'),key=lambda p:int(p.stem.rsplit('-',1)[1]))
                record['renders']=[proof(p) for p in images]
                if role=='pptx':
                    for page,image in zip(report['pages'],images):page['render']=proof(image)
            report['exports'][target]=record
    report['runtime']['export_tool']=converter
    report['runtime']['export_tool_version']=version
    if report['status'] not in ['failed','partial']:report['status']='candidate'
    save(manifest_file,report)
    current=work/'render-manifest.json'
    if current.is_file() and load(current).get('directory')==report['directory']:save(current,report)
    if project.get('schema',0)>=7 and report['runtime'].get('production_stage')=='proposal':save(work/'proposal-source-manifest.json',report)
    return report

def verify(work,project,manifest_file=None):
    work=Path(work).resolve();manifest_file=path(work,manifest_file or project.get('render_manifest') or 'render-manifest.json')
    if not manifest_file.is_file():return {'status':'not_evaluated','issues':['未登记实际渲染清单'],'pages':[]}
    if project.get('schema',0)>=7:
        import production_chain
        chain_issues=production_chain.issues(work,project,'presentation' if load(manifest_file)['runtime'].get('production_stage')!='proposal' else 'proposal')
        if chain_issues:return {'status':'blocked','issues':chain_issues,'pages':[]}
        if load(manifest_file)['runtime'].get('production_stage')=='proposal':
            import document_adapter
            return document_adapter.verify(work,project,manifest_file)
    if model.active(project) and not model.has_ppt(project):
        import document_adapter
        return document_adapter.verify(work,project,manifest_file)
    from pptx import Presentation
    report=contracts.validate(load(manifest_file),'render-manifest.schema.json');issues=[]
    if project.get('schema',0)>=7:
        import ppt_image_method
        evidence=report['runtime'].get('ppt_image_render')
        if not evidence:issues.append('PPT 缺内置 ppt-image-render 制作证据')
        else:issues+=ppt_image_method.recorded_issues(evidence)
    plan=load(path(work,project.get('presentation_plan') or 'presentation-plan.json'));planned={p['page_id']:p for p in plan['pages']}
    if model.active(project):
        if report.get('model_digest')!=model.digest({'base':model.base(work),'story':model.story(work)}):issues.append('共同论证或 story map 已变化')
        plan=model.materialized_plan(work,project,plan);planned={p['page_id']:p for p in plan['pages']}
    if report['plan_sha256']!=sha(path(work,project.get('presentation_plan') or 'presentation-plan.json')):issues.append('页计划已变化')
    if report['project_sha256']!=sha(work/'project.json'):issues.append('项目字段已变化')
    profile,route,a,b=task_config(work,project,presentation=True)
    for field,file in [('profile_sha256',a),('render_policy_sha256',b)]:
        if file.is_file() and report[field]!=sha(file):issues.append('视觉配置已变化 '+file.name)
    issues+=mode_issues(plan,route)
    for role,item in report['source_files'].items():
        if not Path(item['path']).is_file() or sha(item['path'])!=item['sha256']:issues.append('成品源文件缺失或变化 '+role)
    ppt=Path(report['source_files']['pptx']['path'])
    if not ppt.is_file():return {'status':'blocked','issues':issues,'pages':[]}
    deck=Presentation(ppt)
    if len(deck.slides)!=len(report['pages']):issues.append('实际幻灯片数量与渲染清单不符')
    seen=[p['page_id'] for p in report['pages']]
    if len(seen)!=len(set(seen)):issues.append('渲染清单页 ID 重复')
    if report['status']!='partial' and seen!=[p['page_id'] for p in plan['pages']]:issues.append('全稿未按页计划完整制作')
    for page in report['pages']:
        ident=page['page_id'];source=planned.get(ident)
        if source is None:issues.append('未知成品页 '+ident);continue
        if page['slide_number']>len(deck.slides):continue
        slide=deck.slides[page['slide_number']-1];shapes={s.shape_id:s for s in slide.shapes}
        planned_objects={o['object_id'] for o in source['objects']};planned_relations={r['relation_id'] for r in source['relations']}
        if {o['object_id'] for o in page['objects']}!=planned_objects:issues.append(ident+': 成品对象清单与计划不符')
        if {r['relation_id'] for r in page['relations']}!=planned_relations:issues.append(ident+': 成品关系清单与计划不符')
        if page['overflow']:issues.append(ident+': 制作器检测到文字溢出 '+','.join(page['overflow']))
        if any(i not in shapes for i in page.get('composition_shape_ids',[])):issues.append(ident+': 构图轴线或时间标注缺失')
        if page['mode']=='full_image':
            picture=shapes.get(page['image_shape_id'])
            if picture is None or not hasattr(picture,'image') or hashlib.sha256(picture.image.blob).hexdigest()!=page['image']['sha256']:issues.append(ident+': 整页图像与实际 PPT 图片不符')
            elif any(abs(v)>1e-6 for v in [picture.crop_left,picture.crop_top,picture.crop_right,picture.crop_bottom]):issues.append(ident+': 实际整页图像发生裁切')
            if picture is not None and hasattr(picture,'image') and list(picture.image.size)!=page['image_size']:issues.append(ident+': 实际图片尺寸与记录不符')
            for entry in page['objects']+page['relations']:
                x,y,w,h=entry['region']
                if x+w>1 or y+h>1 or w<=0 or h<=0:issues.append(ident+': 图像定位区域越界')
            audit=page.get('literal_audit')
            if not audit or not page.get('render') or audit.get('render_sha256')!=page['render']['sha256']:issues.append(ident+': 整页图像待实际字面核对')
            else:
                evidence=Path(audit['evidence']['path'])
                if not evidence.is_file() or sha(evidence)!=audit['evidence']['sha256']:issues.append(ident+': 字面核对证据缺失或变化')
                if audit['method']=='manual' and (work/'state.json').is_file() and audit['reviewer']==load(work/'state.json')['producer']:issues.append(ident+': 整页文字人工核对需独立检查者')
                if not all(normalize(word) in normalize(audit.get('transcription','')) for word in page['frozen_text']):issues.append(ident+': 图像文字与冻结内容不一致')
        else:
            actual='\n'.join(shape.text for shape in slide.shapes if shape.has_text_frame)
            actual+='\n'+'\n'.join(cell.text for shape in slide.shapes if shape.has_table for row in shape.table.rows for cell in row.cells)
            for word in page['frozen_text']:
                if normalize(word) not in normalize(actual):issues.append(ident+': 实际文字缺失或改变 '+word)
            for entry in page['objects']:
                if entry['shape_id'] not in shapes or entry['label_shape_id'] not in shapes:issues.append(ident+': 原生对象或标签缺失 '+entry['object_id'])
                else:
                    actual=shapes[entry['shape_id']];wanted=entry['rect']
                    measured=[actual.left/deck.slide_width,actual.top/deck.slide_height,actual.width/deck.slide_width,actual.height/deck.slide_height]
                    if any(abs(x-y)>.001 for x,y in zip(wanted,measured)):issues.append(ident+': 对象位置与登记成品不符 '+entry['object_id'])
                    original=next((o for o in source['objects'] if o['object_id']==entry['object_id']),None)
                    if original and normalize(shapes[entry['label_shape_id']].text)!=normalize(original['label']):issues.append(ident+': 对象标签与计划不符 '+entry['object_id'])
                if any(i not in shapes for i in entry.get('icon_shape_ids',[])):issues.append(ident+': 图标图形缺失 '+entry['object_id'])
            for entry in page['relations']:
                shape=shapes.get(entry['shape_id'])
                if shape is None:issues.append(ident+': 原生关系线缺失 '+entry['relation_id']);continue
                original=next((r for r in source['relations'] if r['relation_id']==entry['relation_id']),None)
                objects={o['object_id']:o['shape_id'] for o in page['objects']}
                if original and (objects.get(original['from'])!=entry['from_shape_id'] or objects.get(original['to'])!=entry['to_shape_id']):issues.append(ident+': 成品连线未对应计划对象 '+entry['relation_id'])
                starts=shape._element.xpath('.//a:stCxn');ends=shape._element.xpath('.//a:endCxn')
                if not starts or not ends or int(starts[0].get('id'))!=entry['from_shape_id'] or int(ends[0].get('id'))!=entry['to_shape_id']:issues.append(ident+': 连线端点与计划不符 '+entry['relation_id'])
                elif int(starts[0].get('idx'))!=entry.get('from_site',int(starts[0].get('idx'))) or int(ends[0].get('idx'))!=entry.get('to_site',int(ends[0].get('idx'))):issues.append(ident+': 连线端口改变 '+entry['relation_id'])
                if entry['label_shape_id'] not in shapes:issues.append(ident+': 连线标签缺失')
                elif original and normalize(shapes[entry['label_shape_id']].text)!=normalize(original['meaning']):issues.append(ident+': 连线标签与计划不符 '+entry['relation_id'])
            body=next((s for s in slide.shapes if s.name=='body'),None)
            if body:
                for entry in page['objects']:
                    label=shapes.get(entry['label_shape_id'])
                    if label and min(body.left+body.width,label.left+label.width)>max(body.left,label.left) and min(body.top+body.height,label.top+label.height)>max(body.top,label.top):issues.append(ident+': 对象标签与正文区域重叠 '+entry['object_id'])
            for entry in page['assets']:
                pic=shapes.get(entry['shape_id'])
                if pic is None or not hasattr(pic,'image') or hashlib.sha256(pic.image.blob).hexdigest()!=entry['source']['sha256']:issues.append(ident+': 实际素材与登记来源不符 '+entry['asset_id'])
        if page.get('render'):
            file=Path(page['render']['path'])
            if not file.is_file() or sha(file)!=page['render']['sha256']:issues.append(ident+': 实际渲染证据变化')
        elif project.get('schema',0)>=4:issues.append(ident+': 缺实际导出页面')
    if project.get('schema',0)>=4:
        for role in ['ppt_pdf','sow_pdf','proposal_pdf']:
            if role in project['outputs'] and role not in report['exports'] and report['status']!='partial':issues.append('缺所选 PDF 导出 '+role)
    for role,entry in report['exports'].items():
        file=Path(entry['file']['path'])
        if not file.is_file() or sha(file)!=entry['file']['sha256']:issues.append('PDF 缺失或变化 '+role)
        if any(not f['embedded'] for f in entry['fonts']):issues.append('PDF 字体未嵌入 '+role)
        if role=='ppt_pdf' and entry['pages']!=len(deck.slides):issues.append('PDF 页数与 PPT 源稿不符')
    if model.active(project):issues+=model.visual_requirements(work,project,report)+document_asset_issues(report)
    if model.written(project) and report['status']!='partial':
        import written_proposal
        extra,_=written_proposal.verify_exports(work,project,report);issues+=extra
    return {'status':'blocked' if issues else 'passed','issues':issues,'pages':[{'page_id':p['page_id'],'mode':p['mode'],'composition':p['composition'],'render':p.get('render'),'visual_review':p['visual_review']} for p in report['pages']],'scope':'actual file structure, literal content and evidence; aesthetic and business judgments remain independent'}

def actual_checks(work,project):
    file=path(work,project.get('render_manifest') or 'render-manifest.json')
    if project.get('schema',0)<4 and not file.is_file():return {'status':'not_applicable','issues':[]}
    return verify(work,project,file)

def audited_text(work,project):
    file=path(work,project.get('render_manifest') or 'render-manifest.json')
    if not file.is_file():return ''
    report=load(file)
    return '\n'.join(p.get('literal_audit',{}).get('transcription','') for p in report['pages'] if p['mode']=='full_image')

def audit_images(work,project,manifest_file,transcription_file=None,reviewer=None):
    work=Path(work).resolve();manifest_file=Path(manifest_file).resolve();report=load(manifest_file)
    profile,route,_,_=task_config(work,project)
    pages=[p for p in report['pages'] if p['mode']=='full_image']
    if not pages:return {'status':'not_applicable','pages':[]}
    if any(not p.get('render') for p in pages):raise ValueError('先实际导出并渲染图像页')
    folder=Path(report['directory'])/'text-audits';folder.mkdir(exist_ok=True)
    if transcription_file:
        if not reviewer:raise ValueError('人工字面核对需登记实际检查者')
        raw_file=Path(transcription_file).resolve();reply=load(raw_file);method='manual'
    elif route['ocr_command']:
        payload={'language':profile['language'],'pages':[{'page_id':p['page_id'],'image':p['render']['path']} for p in pages]}
        reply=json.loads(run(route['ocr_command'],input=json.dumps(payload,ensure_ascii=False),timeout=120));raw_file=folder/('ocr-'+datetime.now(timezone.utc).strftime('%H%M%S%f')+'.json');save(raw_file,reply);reviewer='configured_ocr_adapter';method='ocr'
    elif tool('tesseract',route):
        results=[]
        for page in pages:
            language='chi_sim+eng' if profile['language'].startswith('zh') else 'eng'
            value=run([tool('tesseract',route),page['render']['path'],'stdout','-l',language],timeout=90)
            results.append({'page_id':page['page_id'],'transcription':value,'render_sha256':page['render']['sha256']})
        reply={'pages':results};raw_file=folder/('tesseract-'+datetime.now(timezone.utc).strftime('%H%M%S%f')+'.json');save(raw_file,reply);reviewer='tesseract';method='ocr'
    else:raise ValueError('未发现 OCR 能力；由独立检查者查看实际图像并提供字面转写 JSON')
    entries={p['page_id']:p for p in reply['pages']}
    for page in pages:
        entry=entries.get(page['page_id'])
        if not entry or not entry.get('transcription'):raise ValueError('缺实际字面转写 '+page['page_id'])
        if method=='manual' and entry.get('render_sha256')!=page['render']['sha256']:raise ValueError('人工转写未绑定当前实际画面')
        page['literal_audit']={'render_sha256':page['render']['sha256'],'transcription':entry['transcription'],'method':method,'reviewer':reviewer,'evidence':proof(raw_file)}
    save(manifest_file,report)
    current=work/'render-manifest.json'
    if current.is_file() and load(current).get('directory')==report['directory']:save(current,report)
    return verify(work,project,manifest_file)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('command',choices=['doctor','build','export','verify']);parser.add_argument('--workdir',type=Path,required=True);parser.add_argument('--destination',type=Path);parser.add_argument('--manifest',type=Path);parser.add_argument('--calibration',action='store_true');parser.add_argument('--pages')
    args=parser.parse_args();work=args.workdir.resolve();project=load(work/'project.json')
    try:
        if args.command=='doctor':result=doctor(work,project)
        elif args.command=='verify':result=verify(work,project,args.manifest)
        elif args.command=='export':result=export(work,project,args.manifest or work/'render-manifest.json')
        else:
            plan=contracts.validate(load(path(work,project.get('presentation_plan') or 'presentation-plan.json')),'presentation-plan.schema.json') if model.has_ppt(project) else None
            destination=args.destination or work/'candidates'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            result=build(work,project,plan,destination,args.calibration,args.pages.split(',') if args.pages else None)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        if result.get('status') in ['failed','blocked']:sys.exit(2)
    except (ValueError,KeyError,OSError,subprocess.TimeoutExpired) as exc:
        print(json.dumps({'error':str(exc)},ensure_ascii=False),file=sys.stderr);sys.exit(2)
