"""Observable client projection behavior; fixtures are not customer approvals."""
import copy,json,tempfile,unittest
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from unittest.mock import patch
from docx import Document
from pptx import Presentation
import contracts,proposal as api,proposal_model as model,client_content as client
import written_proposal as written,render_adapter as render,production_chain as chain,gates
from test_chain_v7 import prepare_chain

FONTS={r:{'requested':'Arial','actual_family':'Arial','file':None,'available':True} for r in ['body','title']}
def annotation(pointer,visibility='client',purpose='argument',placement='near_claim',source='content_base',locations=None):
    return {'source':source,'pointer':pointer,'visibility':visibility,'content_category':'necessary_business' if visibility=='client' else 'internal_production','purpose':purpose,'placement':placement,'decision_impact':'Supports the current bounded decision' if visibility=='client' else 'Internal execution state only','action':None,'owner':None,'locations':locations or []}
def prepare_client(work,kind='quote',presentation=False,sow=False):
    p,c,plan=prepare_chain(work,presentation,sow,kind);p['client_content_policy']='client-2'
    c['content_annotations']=[]
    for i,u in enumerate(c['semantic_units']):
        c['content_annotations'].append(annotation('/semantic_units/'+str(i)))
        if u['validation']:c['content_annotations'].append(annotation('/semantic_units/'+str(i)+'/validation',purpose='assumption'))
    for name,v in [('project.json',p),('content-base.json',c)]:api.save(Path(work)/name,v)
    model.handoff(work,p);return p,c,plan

class ClientContent(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name);self.p,self.c,self.plan=prepare_client(self.work)
        self.fonts=patch.object(render,'font_map',return_value=(FONTS,{}));self.fonts.start()
    def tearDown(self):self.fonts.stop();self.tmp.cleanup()
    def save(self):
        for name,v in [('project.json',self.p),('content-base.json',self.c),('document-plan.json',self.plan)]:api.save(self.work/name,v)
        model.handoff(self.work,self.p)
    def build(self):
        self.save();chain.build_sow(self.work,self.p,self.work/'sow','TEST-PRODUCER');chain.proposal_brief(self.work,self.p);chain.record_proposal(self.work,self.p,'TEST-PRODUCER')
        report=written.build(self.work,self.p,self.work/'candidate');file=Path(report['source_files']['proposal_docx']['path']);state=api.load(self.work/'state.json');state['files']={'proposal_docx':model.proof(file)}
        return file,state
    def test_new_default_enables_extension_and_old_projects_retain_protocol(self):
        self.assertEqual(contracts.load(contracts.ROOT/'assets/project.json')['client_content_policy'],'client-2')
        old=copy.deepcopy(self.p);old.pop('client_content_policy');self.assertEqual(client.check(self.work,old,{} )['status'],'not_applicable')
    def test_missing_visibility_is_rejected_before_customer_authoring(self):
        self.c['content_annotations']=[];self.save();self.assertTrue(any('visibility' in s for s in client.input_issues(self.work,self.p)))
    def test_internal_unit_not_projected_and_internal_condition_is_not_emitted(self):
        u=self.c['semantic_units'][0];u['conditions']=['Production queue still awaits a replacement input spreadsheet.'];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));self.save()
        self.assertNotIn(u['conditions'][0],'\n'.join(model.unit_texts(self.p,u,work=self.work)))
        file,state=self.build();self.assertNotIn(u['conditions'][0],api.inspect(file,'proposal_docx')['text']);self.assertEqual(client.check(self.work,self.p,state)['issues'],[])
    def test_project_internal_record_cannot_leak_via_sow_paragraph(self):
        self.p['sow_sections'][0]['paragraphs'].append('Producer changed the spreadsheet version after a failed font test.')
        self.c['content_annotations'].append(annotation('/sow_sections/0/paragraphs/1','internal','production_record','internal','project'));self.save()
        report=chain.build_sow(self.work,self.p,self.work/'sow','TEST-PRODUCER');text=api.inspect(report['file']['path'],'sow_docx')['text'];self.assertNotIn('failed font test',text)
        self.assertIn(self.p['sow_sections'][0]['paragraphs'][0],text)
    def test_essential_unit_cannot_be_hidden(self):
        self.c['content_annotations'][0].update(visibility='internal',placement='internal');self.save();issues=client.input_issues(self.work,self.p)
        self.assertTrue(any('决策必需' in s for s in issues));self.assertTrue(any('投影引用内部' in s for s in issues))
    def test_missing_disclosure_metadata_blocks_rather_than_appends_everything(self):
        self.c['semantic_units'][0]['conditions']=['Curator supplies lawful samples before kickoff.'];self.save();self.assertTrue(any(s.startswith('CC02:') for s in client.input_issues(self.work,self.p)))
        with self.assertRaises(ValueError):model.unit_texts(self.p,self.c['semantic_units'][0],work=self.work)
    def test_disclosure_moves_to_implementation_and_remains_in_actual_file(self):
        text='The client curator supplies lawful sample records before kickoff.';self.c['semantic_units'][0]['conditions']=[text]
        self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0',purpose='dependency',placement='implementation',locations=[{'artifact_role':r,'section_or_page':'09'} for r in ['proposal_docx','proposal_pdf']]))
        file,state=self.build();info=api.inspect(file,'proposal_docx');self.assertNotIn(text,model.actual_location(self.work,self.p,'proposal_docx','01',info,state));self.assertIn(text,model.actual_location(self.work,self.p,'proposal_docx','09',info,state));self.assertEqual(client.check(self.work,self.p,state)['issues'],[])
    def test_disclosure_cannot_be_moved_to_a_nonexistent_location(self):
        self.c['semantic_units'][0]['conditions']=['A specific condition matters to the decision.'];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0',purpose='dependency',placement='implementation',locations=[{'artifact_role':'proposal_docx','section_or_page':'missing'}]));file,state=self.build()
        self.assertTrue(any('CC02' in i for i in client.check(self.work,self.p,state)['issues']))
    def test_default_table_has_one_caption_and_no_invented_reference_paragraph(self):
        file,state=self.build();doc=Document(file);text=api.inspect(file,'proposal_docx')['text'];self.assertEqual(text.count('Pilot deliverables and review'),1);self.assertFalse(any('REF _proposal_table' in (n.text or '') for n in doc.element.xpath('.//w:instrText')))
    def test_explicit_reference_points_to_number_without_repeating_caption(self):
        self.plan['chapters'][8]['blocks'][-1]['cross_reference']=True;file,state=self.build();text=api.inspect(file,'proposal_docx')['text'];self.assertEqual(text.count('Pilot deliverables and review'),1);self.assertIn('See Table 1.',text);self.assertEqual(client.check(self.work,self.p,state)['issues'],[])
    def test_internal_text_is_found_in_headers_footers_comments_tables_and_drawing_text(self):
        text='An internal production replacement is still waiting for a source upload.'
        self.c['semantic_units'][0]['conditions']=[text];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));self.save()
        for surface in ['body','table','caption','source','header','footer','notes','graphic_text']:
            with self.subTest(surface=surface):
                f=self.work/(surface+'.docx');d=Document()
                if surface=='table':d.add_table(rows=1,cols=1).cell(0,0).text=text
                elif surface in ['header','footer']:getattr(d.sections[0],surface).paragraphs[0].text=text
                elif surface=='caption':d.add_paragraph(text,style='Caption')
                elif surface=='source':
                    from docx.enum.style import WD_STYLE_TYPE
                    d.styles.add_style('Source',WD_STYLE_TYPE.PARAGRAPH);d.add_paragraph(text,style='Source')
                else:d.add_paragraph(text)
                d.save(f)
                if surface in ['notes','graphic_text']:
                    with ZipFile(f) as z:parts={n:z.read(n) for n in z.namelist()}
                    parts['word/comments.xml' if surface=='notes' else 'word/charts/chart1.xml']=('<w:comments xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:r><w:t>'+text+'</w:t></w:r></w:p></w:comments>').encode()
                    with ZipFile(f,'w',ZIP_DEFLATED) as z:
                        for n,b in parts.items():z.writestr(n,b)
                report=client.check(self.work,self.p,{'files':{'proposal_docx':model.proof(f)}});self.assertTrue(any(row['check']=='CC01' for row in report['findings']),report)
    def test_ppt_notes_and_chart_text_are_extracted(self):
        text='A private production note waiting for input.';self.c['semantic_units'][0]['conditions']=[text];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));self.p['outputs']+=['pptx'];self.save()
        deck=Presentation();s=deck.slides.add_slide(deck.slide_layouts[6]);s.notes_slide.notes_text_frame.text=text;f=self.work/'notes.pptx';deck.save(f)
        report=client.check(self.work,self.p,{'files':{'pptx':model.proof(f)}});self.assertTrue(any(r['location'].startswith('ppt/notesSlides') for r in report['findings']))
    def test_business_approvals_negation_and_unknown_terms_only_produce_hints(self):
        d=Document();d.add_paragraph('Registrar review and customer approval are required. The pilot is not guaranteed to save cash. Payment split is 未确认 and 审核 remains a human responsibility.');f=self.work/'business.docx';d.save(f)
        report=client.check(self.work,self.p,{'files':{'proposal_docx':model.proof(f)}});self.assertEqual(report['issues'],[]);self.assertTrue(report['hints'])
    def test_same_words_rephrased_require_context_not_an_automatic_failure(self):
        self.c['semantic_units'][0]['conditions']=['We are still waiting for a customer upload.'];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));self.save();d=Document();d.add_paragraph('Production status: the requester has yet to place the file in the shared folder.');f=self.work/'rephrased.docx';d.save(f)
        report=client.check(self.work,self.p,{'files':{'proposal_docx':model.proof(f)}});self.assertEqual(report['issues'],[]);self.assertTrue(report['hints'])
    def test_locatable_evidence_is_emitted_and_missing_citation_is_detected(self):
        source=self.work/'internal-evidence-name.txt';source.write_text('A supplied observation about the pilot workflow.')
        self.c['evidence_sources']=[{'evidence_id':'E1','source':model.proof(source),'location':'paragraph 1','client_reference':'Pilot process interview'}];self.c['semantic_units'][0]['evidence_refs']=['E1'];file,state=self.build();text=api.inspect(file,'proposal_docx')['text'];self.assertIn('Pilot process interview · paragraph 1',text);self.assertNotIn('[E1]',text);self.assertNotIn(str(self.work),text)
        d=Document(file)
        for p in d.paragraphs:
            if 'Pilot process interview' in p.text:p.text=''
        d.save(file);state['files']['proposal_docx']=model.proof(file);self.assertTrue(any(i.startswith('CC02') for i in client.check(self.work,self.p,state)['issues']))
    def test_changed_project_projection_invalidates_sow(self):
        self.save();chain.build_sow(self.work,self.p,self.work/'sow','TEST-PRODUCER');self.c['content_annotations'].append(annotation('/sow_sections/0/paragraphs/0','internal','production_record','internal','project'));self.save();self.assertTrue(chain.issues(self.work,self.p,'sow'))
    def test_semantic_review_cannot_be_replaced_by_schema_validity_or_self_review(self):
        file,state=self.build();state['producer']='A';state['review']={'reviewer':'B'};record=client.starter(self.work,self.p,state,'A');contracts.validate(record,'client-content-review.schema.json');api.save(self.work/'client-content-review.json',record)
        self.assertTrue(any('实际独立检查者' in s for s in client.review_issues(self.work,self.p,state)));self.assertTrue(any('未复核' in s for s in client.review_issues(self.work,self.p,state)))
    def test_open_editorial_defects_block_even_if_overall_marked_acceptable(self):
        file,state=self.build();state['producer']='A';state['review']={'reviewer':'B'};record=client.starter(self.work,self.p,state,'B');record['result']='acceptable'
        api.save(self.work/'client-content-review.json',record);self.assertTrue(any('未解决表达' in s for s in client.review_issues(self.work,self.p,state)))
    def test_review_bound_to_actual_file_and_shared_facts(self):
        file,state=self.build();state['producer']='A';state['review']={'reviewer':'B'};record=client.starter(self.work,self.p,state,'B');record['result']='acceptable'
        from test_client_editorial_v2 import complete_synthetic_record
        complete_synthetic_record(self.work,self.p,state,record)
        api.save(self.work/'client-content-review.json',record);self.assertEqual(client.review_issues(self.work,self.p,state),[])
        self.p['scope'].append('A newly proposed work package');self.assertTrue(any('已变化' in s for s in client.review_issues(self.work,self.p,state)))
    def test_amount_scope_owner_and_benefit_nature_survive_expression_cleanup(self):
        self.c['semantic_units'][0]['conditions']=['Internal tool operation completed.'];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));snapshot=copy.deepcopy({k:self.p[k] for k in ['pricing','scope','deliverable_details','returns']});file,state=self.build();self.assertEqual(snapshot,{k:self.p[k] for k in snapshot});text=api.inspect(file,'proposal_docx')['text'];self.assertIn('36000',text);self.assertIn('may support',text);self.assertIn('owner',text)
    def test_six_week_fixed_fee_needs_no_invented_integer_months(self):
        self.p['pricing'].update(period_months=None,coverage_period='six weeks');self.p['shared_facts']['period_months']=None
        contracts.validate(self.p,'project.schema.json');calculation=api.calculate(self.p);self.assertEqual(calculation['issues'],[]);self.assertIsNone(calculation['pricing']['period_months']);self.assertEqual(calculation['pricing']['coverage_period'],'six weeks');self.assertEqual(calculation['pricing']['total'],'36000.00')
        import facts
        self.assertEqual(facts.project_issues(self.p),[]);self.assertTrue(any(v['id']=='coverage_period' for v in facts.expected(self.p,calculation)['facts']))
    def test_cross_scenario_native_files_and_contextual_negative_samples(self):
        dataset=contracts.validate(contracts.load(contracts.ROOT/'evals/client-content-cases.json'),'client-content-cases.schema.json')
        for case in dataset['cases']:
            with self.subTest(case=case['id']):
                d=Document();d.add_paragraph(case['client_text']);file=self.work/(case['id']+'.docx');d.save(file)
                p=copy.deepcopy(self.p);p['kind']=case['kind'];p['audience']=case['audience']
                c=copy.deepcopy(self.c);c['semantic_units'][0]['conditions']=[case['internal_source']]
                c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));api.save(self.work/'content-base.json',c)
                result=client.check(self.work,p,{'files':{'proposal_docx':model.proof(file)}})
                self.assertEqual(result['status']=='blocked',case['structural_result']=='blocked')
                if case['structural_result']=='hint_only':self.assertTrue(result['hints'])
    def test_internal_record_edit_does_not_create_a_business_reapproval(self):
        u=self.c['semantic_units'][0];u['conditions']=['Producer awaits an updated spreadsheet.'];self.c['content_annotations'].append(annotation('/semantic_units/0/conditions/0','internal','production_record','internal'));self.save();before=api.critical(self.p,self.work)
        u['conditions'][0]='Producer received a replacement spreadsheet and ran a local check.';self.save();self.assertEqual(api.critical(self.p,self.work),before)
        self.p['scope'].append('Additional customer work');self.save();self.assertNotEqual(api.critical(self.p,self.work),before)
    def test_figure_caption_is_not_repeated_by_automatic_reference_or_source_description(self):
        from PIL import Image
        asset=self.work/'figure.png';Image.new('RGB',(400,200),'white').save(asset)
        self.p['visual_assets']=[{'asset_id':'FIG1','source':model.proof(asset),'identity':'illustrative_diagram','source_description':'Internal rendering description that is not a caption.','rights':'Test fixture','purpose':'Explain a relation','client_caption':'Record processing and human review'}]
        self.plan['chapters'][4]['blocks']=[{'kind':'figure','asset_ref':'FIG1','caption':'Record processing and human review','cross_reference':True}]
        file,state=self.build();text=api.inspect(file,'proposal_docx')['text'];self.assertEqual(text.count('Record processing and human review'),1);self.assertIn('See Figure 1.',text);self.assertNotIn('Internal rendering description',text)
        for p in Document(file).paragraphs:
            if p.style.name=='Caption' and 'Record processing' in p.text:
                before_end=[]
                for node in p._p:
                    if node.tag.endswith('}bookmarkEnd'):break
                    before_end += [n.text or '' for n in node.iter() if n.tag.endswith('}t')]
                self.assertNotIn('Record processing',''.join(before_end))
    def test_exported_pdf_cannot_expand_number_reference_back_to_full_caption(self):
        from reportlab.pdfgen.canvas import Canvas
        self.plan['chapters'][8]['blocks'][-1]['cross_reference']=True;self.save();file=self.work/'expanded.pdf';canvas=Canvas(str(file));canvas.drawString(40,750,'See Table 1 Pilot deliverables and review.');canvas.drawString(40,720,'Table 1 Pilot deliverables and review');canvas.save()
        report=client.check(self.work,self.p,{'files':{'proposal_pdf':model.proof(file)}});self.assertTrue(any(f['check']=='CC03' for f in report['findings']),report)
    def test_tables_allocate_real_content_width_and_visible_cell_boundaries(self):
        self.plan['chapters'][8]['blocks'][-1].update(columns=['Deliverable','Completion criterion','Owner'],rows=[['Mapping','Both input formats are listed with a destination for each agreed record field','Curator']]);file,state=self.build();table=Document(file).tables[0]
        self.assertGreater(table.columns[1].width,table.columns[2].width)
        for row in table.rows:
            for cell in row.cells:self.assertTrue(cell._tc.xpath('./w:tcPr/w:tcMar'));self.assertTrue(cell._tc.xpath('./w:tcPr/w:tcBorders'))
        self.assertTrue(table.rows[0].cells[0]._tc.xpath('./w:tcPr/w:shd'))

if __name__=='__main__':unittest.main(verbosity=2)
