"""Actual Office/Markdown mutations and isolated evaluation provenance regressions."""
import copy,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
from PIL import Image
from pptx import Presentation
import contracts,proposal as api,proposal_model as model,proposal_quality as quality
import render_adapter as render,document_adapter,evaluation,presentation
from model_fixtures import prepare,slide_inputs,register_report

class ArtifactBehavior(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.work=Path(self.temp.name);self.p,self.c=prepare(self.work,outputs=['proposal_docx'])
        self.fonts={r:{'requested':'Arial','actual_family':'Arial','file':None,'available':True} for r in ['title','body']}
        self.mock=patch.object(render,'font_map',return_value=(self.fonts,{}));self.mock.start()
    def tearDown(self):self.mock.stop();self.temp.cleanup()
    def write(self):api.save(self.work/'project.json',self.p);model.handoff(self.work,self.p)
    def build(self,name='candidate'):self.write();return document_adapter.build(self.work,self.p,self.work/name)
    def requirement(self,feature,role='proposal_docx',asset_refs=None):
        r=copy.deepcopy(self.p['request_requirements'][0]);r.update(id='VIS-'+feature,scope='visual');self.p['request_requirements'].append(r)
        self.p['requirement_realizations'].append({'requirement_id':r['id'],'artifact_role':role,'section_or_page':'S01','feature':feature,'expectation':'required','method':'Task-specific resources',**({'asset_refs':asset_refs} if asset_refs else {})})
    def test_docx_uses_actual_icon_and_scene_and_output_assets(self):
        for ident,identity in [('SCENE','illustrative_diagram'),('OUTPUT','product_screenshot')]:
            file=self.work/(ident+'.png');Image.new('RGB',(100,60),'white' if ident=='SCENE' else 'navy').save(file)
            self.p['visual_assets'].append({'asset_id':ident,'source':model.proof(file),'identity':identity,'source_description':'Synthetic diagram, not a customer result','rights':'Self-created test fixture','purpose':'Protocol regression'})
        self.p['artifact_projection'][0]['asset_refs']=['SCENE','OUTPUT']
        self.requirement('icons');self.requirement('scene_assets',asset_refs=['SCENE']);self.requirement('output_examples',asset_refs=['OUTPUT'])
        report=self.build();self.assertEqual(model.visual_requirements(self.work,self.p,report),[])
        with ZipFile(report['source_files']['proposal_docx']['path']) as z:self.assertGreaterEqual(len([n for n in z.namelist() if n.startswith('word/media/')]),3)
        self.assertEqual(render.verify(self.work,self.p)['issues'],[])
        # Rebind the file hash after deletion: actual embedding must still fail.
        file=Path(report['source_files']['proposal_docx']['path'])
        with ZipFile(file) as z:parts={n:z.read(n) for n in z.namelist() if not n.startswith('word/media/')}
        with ZipFile(file,'w') as z:
            for n,b in parts.items():z.writestr(n,b)
        report['source_files']['proposal_docx']=model.proof(file);api.save(self.work/'render-manifest.json',report)
        self.assertTrue(any('缺实际资源' in v for v in render.verify(self.work,self.p)['issues']))
    def test_explicit_off_does_not_insert_icons(self):
        profile=api.load(self.work/'visual-profile.json');profile['feature_use']['icons']='off';api.save(self.work/'visual-profile.json',profile)
        report=self.build();self.assertFalse(report['runtime'].get('asset_bindings'))
    def test_english_client_conditions_and_metadata_are_english(self):
        profile=api.load(self.work/'visual-profile.json');profile['language']='en';api.save(self.work/'visual-profile.json',profile)
        report=self.build();text=api.inspect(Path(report['source_files']['proposal_docx']['path']),'proposal_docx')['text']
        self.assertIn('Validation:',text);self.assertIn('Date:',text);self.assertNotIn('验证安排',text)
        self.assertEqual(model.projection_check(self.work,self.p,{'proposal_docx':{'text':text}})['issues'],[])
    def test_format_path_or_quality_label_does_not_reapprove_business(self):
        before=api.critical(self.p,self.work)
        self.p.update(visual_profile='another-style.json',presentation_plan='other-layout.json',quality_target='review_draft',draft_mode=not self.p['draft_mode'])
        self.assertEqual(api.critical(self.p,self.work),before)
        self.p['decision_context']['commitment_scope']='binding';self.assertNotEqual(api.critical(self.p,self.work),before)
    def test_no_ppt_cli_production_saves_readable_state(self):
        self.p['outputs']=['proposal_md'];self.p['request_requirements'][0]['affected_outputs']=self.p['outputs'];self.p['artifact_projection']=[{**r,'artifact_role':'proposal_md'} for r in self.p['artifact_projection']];self.write()
        p=subprocess.run([sys.executable,str(contracts.ROOT/'scripts/proposal.py'),'production-check','--workdir',str(self.work)],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr+p.stdout);api.context(self.work)
        self.assertIsNone(api.load(self.work/'state.json')['production']['plan_sha256'])
    def test_pdf_only_selection_uses_internal_docx_without_slide_plan(self):
        for role in ['proposal_pdf','sow_pdf']:
            p,c=prepare(self.work/role,'quote',[role]);contracts.validate(p,'project.schema.json')
            report=document_adapter.build(self.work/role,p,self.work/role/'candidate')
            self.assertTrue(report['source_files']);self.assertFalse((self.work/role/'presentation-plan.json').exists())
            if role=='sow_pdf':self.assertIn('S13',contracts.applicable(p))
    def test_projection_moving_or_adding_assets_keeps_business_confirmation(self):
        before=api.critical(self.p,self.work);self.p['artifact_projection'][0]['section_or_page']='NEW-SECTION';self.p['artifact_projection'][0]['asset_refs']=['NEW-ASSET']
        self.assertEqual(before,api.critical(self.p,self.work))
        self.c['semantic_units'][0]['conditions'].append('New decision condition');api.save(self.work/'content-base.json',self.c)
        self.assertNotEqual(before,api.critical(self.p,self.work))
    def test_multi_unit_summary_cannot_cover_absent_argument(self):
        self.p['artifact_projection'][0]['summary_and_conditions']='Nice generic slogan';self.write()
        observed={'proposal_docx':{'text':'S01\nNice generic slogan\nS02\nNice generic slogan'}}
        self.assertTrue(model.projection_check(self.work,self.p,observed)['missing_unit_ids'])
    def test_same_business_judgment_survives_image_only_change(self):
        report=self.build();file=Path(report['source_files']['proposal_docx']['path']);state,review=register_report(self.work,self.p,{'proposal_docx':file});old=quality.business_digest(self.work,self.p,state)
        from docx import Document
        image=self.work/'pure-decoration.png';Image.new('RGB',(15,15),'blue').save(image);d=Document(file);d.add_picture(str(image));d.save(file)
        self.assertEqual(quality.business_digest(self.work,self.p,state),old)
        result=quality.summary(self.work,self.p,state,api.candidate(self.work,self.p,state));self.assertEqual(result['business_argument'],'acceptable');self.assertEqual(result['artifact_quality']['proposal_docx'],'not_evaluated')
    def test_actual_sow_supplies_argument_missing_from_summary(self):
        work=self.work/'complement';p,c=prepare(work,'product',['sow_docx','proposal_md']);report=document_adapter.build(work,p,work/'candidate')
        markdown=Path(report['source_files']['proposal_md']['path']);markdown.write_text('# Weak summary\n\nS01\nBrief summary only\n\nS02\nDecision omitted\n')
        state,review=register_report(work,p,{'sow_docx':Path(report['source_files']['sow_docx']['path']),'proposal_md':markdown})
        result=quality.summary(work,p,state,api.candidate(work,p,state))
        self.assertEqual(result['business_argument'],'acceptable');self.assertEqual(result['artifact_quality']['proposal_md'],'gap');self.assertFalse(result['target_met'])
    def test_native_comparison_value_chain_and_timeline_have_different_geometry(self):
        p,c=prepare(self.work/'slides','product',['pptx']);plan=slide_inputs(self.work/'slides',p)
        profile=api.load(self.work/'slides/visual-profile.json');profile['feature_use']['icons']='required';api.save(self.work/'slides/visual-profile.json',profile)
        for form in ['comparison','value_chain','timeline']:
            page=plan['pages'][0];page['visual']['composition']=form
            if form=='timeline':page['visual']['time_labels']={'A':'Before pilot','B':'Pilot review'}
            api.save(self.work/'slides/presentation-plan.json',plan)
            report=render.build(self.work/'slides',p,plan,self.work/form,calibration=True,page_ids=['P1'])
            native=report['pages'][0];self.assertTrue(any(o.get('icon_shape_ids') for o in native['objects']))
            if form=='comparison':self.assertGreater(native['objects'][0]['rect'][3],.25)
            if form=='value_chain':self.assertNotEqual(native['objects'][0]['rect'][1],native['objects'][1]['rect'][1])
            if form=='timeline':self.assertGreaterEqual(len(native['composition_shape_ids']),5)
    def test_native_raster_variant_has_actionable_error(self):
        deck=Presentation();slide=deck.slides.add_slide(deck.slide_layouts[6])
        with self.assertRaisesRegex(ValueError,'SVG'):render.icon(slide,'document-raster',0,0,1,'#222222')

class EvaluationBoundary(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name);self.p,self.c=prepare(self.work)
    def tearDown(self):self.tmp.cleanup()
    def freeze(self,name):
        f=self.work/'sources.json';api.save(f,[{'role':'user_instructions','path':str(self.work/'original-brief.txt')}]);evaluation.freeze_inputs(self.work,self.p,f,self.work/name);return self.work/name/'input-freeze.json'
    def result(self,inputs,name,producer='REAL-TEST-PRODUCER',reviewer='REAL-TEST-REVIEWER'):
        artifact=self.work/'artifact.md';artifact.write_text('Original test result');review=self.work/'original-review.md';review.write_text('Original independent test judgment')
        record=self.work/'result-input.json';api.save(record,{'input_freeze':str(inputs),'producer':producer,'reviewer':reviewer,'artifacts':[model.proof(artifact)],'review':model.proof(review)})
        evaluation.freeze_result(record,self.work/name);return self.work/name/'result-freeze.json'
    def test_same_standard_comparison_preserves_originals(self):
        inputs=self.freeze('inputs');a=self.result(inputs,'run-a');b=self.result(inputs,'run-b');self.assertEqual(evaluation.compare(a,b)['status'],'comparable')
        data=api.load(b);data['rubric_digest']='0'*64;api.save(b,data);self.assertEqual(evaluation.compare(a,b)['status'],'not_comparable');self.assertIsNone(evaluation.compare(a,b)['aligned_reassessment'])
    def test_comparison_requires_matching_artifact_roles(self):
        inputs=self.freeze('typed-inputs');a=self.result(inputs,'typed-a');b=self.result(inputs,'typed-b')
        for path in [a,b]:
            data=api.load(path);data['original_artifacts'][0]['artifact_role']='proposal_md';api.save(path,data)
        result=evaluation.compare(a,b);self.assertEqual(result['artifact_status'],'comparable');self.assertEqual(result['artifact_comparisons'][0]['artifact_role'],'proposal_md')
        data=api.load(b);data['original_artifacts'][0].pop('artifact_role');api.save(b,data);result=evaluation.compare(a,b)
        self.assertEqual(result['artifact_status'],'not_comparable');self.assertEqual(result['artifact_comparisons'][0]['status'],'not_comparable')
    def test_changed_original_or_skill_snapshot_blocks_result_freeze(self):
        inputs=self.freeze('inputs');value=api.load(inputs);(Path(value['skill_snapshot']['path'])/'SKILL.md').write_text('Mutated snapshot')
        with self.assertRaisesRegex(ValueError,'skill'):self.result(inputs,'run')
    def test_changed_frozen_result_blocks_comparison(self):
        inputs=self.freeze('inputs');a=self.result(inputs,'run-a');b=self.result(inputs,'run-b');Path(api.load(a)['original_review']['path']).write_text('Changed rating')
        with self.assertRaisesRegex(ValueError,'原始结果'):evaluation.compare(a,b)
    def test_wrong_original_requirement_source_is_rejected(self):
        wrong=self.work/'wrong.txt';wrong.write_text('Truncated brief');sources=self.work/'sources.json';api.save(sources,[{'role':'user_instructions','path':str(wrong)}])
        with self.assertRaisesRegex(ValueError,'原文'):evaluation.freeze_inputs(self.work,self.p,sources,self.work/'inputs')
    def test_same_producer_cannot_freeze_independent_review(self):
        inputs=self.freeze('inputs')
        with self.assertRaisesRegex(ValueError,'独立'):self.result(inputs,'run','SAME','SAME')
    def test_nested_migration_is_rejected_before_copy(self):
        with self.assertRaisesRegex(ValueError,'之外'):model.migrate(self.work,{'schema':4},self.work/'nested','REAL-TEST-PRODUCER')

if __name__=='__main__':unittest.main(verbosity=2)
