"""Text/SOW-only generation using the shared model and existing Office adapter."""
from pathlib import Path
import contracts
import proposal_model as model

def build(work,project,destination):
    if model.written(project):
        import written_proposal
        return written_proposal.build(work,project,destination)
    import render_adapter as render
    from proposal import calculate
    work=Path(work).resolve();destination=Path(destination).resolve()
    if destination.exists():raise ValueError('候选目录已存在，选择新版本位置')
    problems=model.model_issues(work,project)
    if problems:raise ValueError('；'.join(problems))
    calculation=calculate(project)
    if calculation['issues']:raise ValueError('；'.join(calculation['issues']))
    destination.mkdir(parents=True)
    try:
        profile,route,a,b=render.task_config(work,project)
        need_doc=bool({'sow_docx','sow_pdf','proposal_docx','proposal_pdf'}&set(project['outputs']))
        fonts={}
        if need_doc:
            fonts,_=render.font_map(profile,route,destination/'font-environment')
            if not all(f['available'] for f in fonts.values()):raise ValueError('所选文稿字体未匹配；运行 doctor 并选择可用字体')
        content=model.base(work)
        report={'schema':1,'plan_sha256':model.sha(work/'content-base.json'),'profile_sha256':model.sha(a),'render_policy_sha256':model.sha(b),'project_sha256':model.sha(work/'project.json'),'model_digest':model.digest({'base':content,'story':model.story(work)}),'directory':str(destination),'source_files':{},'pages':[],'exports':{},'runtime':{'fonts':fonts,'planning_source':'content-base.json','source_reopen':'python-docx round trip; Markdown UTF-8 readback'},'status':'candidate'}
        report['runtime']['catalogue']=render.proof(render.ROOT/'assets/visual-kit/catalog.json')
        view={'project_label':project.get('project_label') or project['audience'],'deliverables':[],'fee_value_mappings':content['fee_value_mappings'],'_shared_units':{v['id']:v for v in content['semantic_units']},'_workdir':str(work)}
        for role in ['sow_docx','proposal_docx']:
            pdf='sow_pdf' if role=='sow_docx' else 'proposal_pdf'
            if role not in project['outputs'] and pdf not in project['outputs']:continue
            file=destination/('sow.docx' if role=='sow_docx' else 'written-proposal.docx')
            render.build_sow(project,view,file,profile,fonts,calculation,role=role,asset_bindings=report['runtime'].setdefault('asset_bindings',[]));report['source_files'][role]=render.proof(file)
        if 'proposal_md' in project['outputs']:
            units={u['id']:u for u in content['semantic_units']};parts=['# '+(project.get('project_label') or project['audience'])]
            import facts
            parts+=facts.fact_texts(project,calculation,work)
            for row in model.projection_rows(project,'proposal_md'):
                parts.append('## '+row['section_or_page'])
                for ref in row['source_refs']:parts+=model.unit_texts(project,units[ref],model.projection_summary(row),work)
            file=destination/'proposal.md';file.write_text('\n\n'.join(parts)+'\n');file.read_text(encoding='utf-8');report['source_files']['proposal_md']=render.proof(file)
        render.save(destination/'render-manifest.json',report);render.save(work/'render-manifest.json',report)
        return report
    except Exception as exc:
        render.save(destination/'failure.json',{'status':'failed','error':str(exc)});raise

def verify(work,project,manifest_file):
    import render_adapter as render
    report=contracts.validate(contracts.load(manifest_file),'render-manifest.schema.json');issues=[]
    if project.get('schema',0)>=7:
        import production_chain
        if report['runtime'].get('source_business_digest')!=production_chain.business_digest(project):issues.append('书面 Proposal 的业务输入已变化')
    elif report['project_sha256']!=model.sha(Path(work)/'project.json'):issues.append('项目字段已变化')
    source=Path(work)/'content-base.json'
    if model.written(project):
        import written_proposal
        source=written_proposal.plan_path(work,project) if written_proposal.has_proposal(project) else source
    if report['plan_sha256']!=model.sha(source) or report.get('model_digest')!=model.digest({'base':model.base(work),'story':model.story(work)}):issues.append('章节计划、共同论证或 story map 已变化')
    _,_,a,b=render.task_config(work,project)
    if report['profile_sha256']!=model.sha(a) or report['render_policy_sha256']!=model.sha(b):issues.append('制作配置已变化')
    for role,entry in report['source_files'].items():
        file=Path(entry['path'])
        if not file.is_file() or model.sha(file)!=entry['sha256']:issues.append(role+': 实际源稿缺失或变化')
        elif role.endswith('_docx'):
            from zipfile import ZipFile
            import hashlib
            with ZipFile(file) as archive:embedded={hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('word/media/')}
            for binding in report['runtime'].get('asset_bindings',[]):
                if binding['artifact_role']==role and binding['source']['sha256'] not in embedded:issues.append(role+': 文稿中缺实际资源 '+binding['asset_id'])
    for role in project['outputs']:
        if project.get('schema',0)>=7 and report['runtime'].get('production_stage')=='proposal' and role in ['pptx','ppt_pdf']:continue
        if role.endswith('_pdf'):
            if role not in report['exports']:issues.append(role+': 缺实际 PDF 导出');continue
            entry=report['exports'][role];file=Path(entry['file']['path'])
            if not file.is_file() or model.sha(file)!=entry['file']['sha256']:issues.append(role+': PDF 缺失或变化')
            if any(not f['embedded'] for f in entry['fonts']):issues.append(role+': PDF 字体未嵌入')
            if not entry.get('renders'):issues.append(role+': 缺实际页面渲染')
            for image in entry.get('renders',[]):
                if not Path(image['path']).is_file() or model.sha(image['path'])!=image['sha256']:issues.append(role+': 页面图缺失或变化')
        elif role not in report['source_files']:issues.append(role+': 缺实际源稿')
    issues+=model.visual_requirements(work,project,report)+render.document_asset_issues(report)
    documents={}
    if model.written(project):
        import written_proposal
        issues+=written_proposal.form_issues(project)
        extra,documents=written_proposal.verify_exports(work,project,report);issues+=extra
    return {'status':'blocked' if issues else 'passed','issues':issues,'pages':[],'documents':documents,'scope':'actual written source, A4 layout, metadata, native fields and export evidence; business argument and expression reviewed separately'}
