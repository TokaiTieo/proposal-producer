# 包内 ppt-image-render

用户选择 PPT 后，使用本模块将实际书面 Proposal 提炼为整页图像汇报稿。先完整读取 [原始 skill](methods/ppt-image-render/SKILL.source.md)，再读取其中适用的参考、脚本及资源；本入口说明 Proposal Producer 的交接及宿主适配。版本、包内文件清单、哈希、阈值和必需记录由 [JSON 契约](../contracts/ppt-image-render.json) 定义。

## 集成边界

原件保留其来源及 `internal-use` 标记，未改授为商业论证模块的 CC0 许可证。当前执行使用包内方法及脚本，无需另装 ppt-image-render；来源文件缺失或变化时停止 PPT 分支。

原文中的特定公司、工业平台、模型厂商、Agent 数量、中文标题及配色属于历史项目配置。当前项目采用 `visual-profile.json` 中的语言、品牌、字体、配色和素材要求。初始化脚本复制的历史 overlay 会由准备命令替换为当前配置；内容以当前冻结页稿为准，图片中使用的图标、场景与成果示例应帮助解释本项目。

Proposal 提炼成逐页文稿属于正常写作。冻结逐页 Markdown 后，出图阶段保留该页全部文字、数字和关系；原文的“不删减”从冻结页稿起算，不要求将整份 Word 逐字塞入 PPT。

沿用已有业务确认与图像制作授权，按 Proposal Producer 的确认规则执行；原件中的重复确认、云盘路径和具体宿主工具按本集成的授权及本地目录交接处理。内部脚本执行与核对记录留在制作资料中。原件提及的模型及分辨率上限是历史信息，实际调用记录模型、请求尺寸、原始输出尺寸及后处理；不把放大图声称为原生分辨率。

整页图像可替换整张幻灯片图片，不支持在 PPT 内逐字或逐关系编辑。用户明确要求原生可编辑对象时，说明该路线不满足要求并取得替代路线选择。缺工具时暂停 PPT 部分，书面 Proposal 可继续；不静默切回原生版式。

## 制作交接

1. `presentation-brief` 提供实际 Proposal DOCX／PDF、内置方法与本入口。制作执行者阅读后形成 `presentation-plan.json`，登记来源章节、决策问题、结论、依据、业务对象与关系，运行 `presentation-record`。
2. 运行 `presentation-image-prepare`。该命令实际调用包内 `init_project.py`、`select_path.py`、`build_prompt.py`，生成冻结页稿、当前样式、A／B 选路、高密度标识和逐页提示词，并保存实际命令输出。`--actor` 与 `--evidence` 登记已有的图像路线选择。需要蓝本时，用 `--file` 提供符合 `ppt-image-blueprints.schema.json` 的页 ID → 路径／哈希映射；蓝本会随本次任务复制并绑定版本。
3. 根据真实图像工具能力逐页出图，蓝本路径传入对应参考图；候选落在本次任务 `_staging`，保留失败版本。高密度、分区出图、重试与内容护栏按内置原文执行。拆分内容或修改上屏文字时，更新页计划并建立新制作目录。
4. 独立检查者看实际图片逐字转写，并运行 `ocr_extract.py` 读取实际图片；实际 OCR 环境由宿主配置，依赖未安装则报告未完成。转写与 OCR 不得由预期页稿冒充。转写、OCR 和视觉记录的各页追加 `image_sha256`，绑定实际被审图像。视觉检查沿当前项目样式逐项记录，必要时提供 `layout_verdict.json`。
5. 实际运行 `audit_diff.py`，传入源文、staging、diff、OCR、逐字转写和版面记录。解决失败或警告后，再用 `promote_staging.py` 将通过内容与视觉检查的图片晋级到 `04_output/images`。包内检查另核对必需页记录、图像哈希和晋级路径，防止原脚本的可选字段被当作完整复核。
6. 在 `visual_assets` 中登记实际晋级图片，在各页 `background_asset_id` 中选择图片，并用 `image_regions` 定位计划中的对象与关系；更新 `presentation-record`。这些登记不改变冻结文字。修改文字、样式或蓝本时重新准备并出图。
7. 用 `render_adapter.py build --calibration` 试制关键页，查看实际画面并记录校准。每次构建均检查包内方法、源稿、提示词、逐页审计与实际图片；`production-check` 通过后用 `presentation-build` 生成全稿。打包后实际调用内置 `validate_deck.py` 核对页数、画幅及每页整图，随后实际导出 PDF、逐页查看并沿原有独立复核与放行流程完成交付。

以 `BUNDLE` 表示 `presentation-brief` 提供的方法根目录，以 `JOB` 表示准备命令输出目录。以下调用使用本次实际路径，不依赖用户全局安装：

```sh
PYTHON BUNDLE/scripts/ocr_extract.py --images-dir JOB/04_output/_staging --pages-dir JOB/00_source --out JOB/03_render_report/ocr_extracts.json --engine ACTUAL_OCR_ENGINE
PYTHON BUNDLE/scripts/audit_diff.py --pages-dir JOB/00_source --staging-dir JOB/04_output/_staging --diff-report JOB/03_render_report/diff_report.json --ocr-json JOB/03_render_report/ocr_extracts.json --literal-json JOB/03_render_report/literal_transcription.json --layout-json JOB/03_render_report/layout_verdict.json --audit-out JOB/03_render_report/audit_result.json
PYTHON BUNDLE/scripts/promote_staging.py --staging-dir JOB/04_output/_staging --images-dir JOB/04_output/images --audit-json JOB/03_render_report/audit_result.json --visual-qa-json JOB/03_render_report/visual_qa.json --log-out JOB/03_render_report/promotion_log.json
```

源文件及原脚本的格式不改名；本集成增加当前图像哈希及链路记录。打包脚本、程序检查和独立读图分别提供技术证据、内容核对和实际表达判断。
