# 阶段交接

新任务从 SOW 开始。先填写项目事实和工作约定，运行 `sow-build`，得到可编辑的实际 SOW。该阶段从范围与交付数据生成，不要求先写完 Proposal 的商业论证。内部 SOW 可以处于草案状态，正式对客交付沿用 SOW 检查。

运行 `proposal-brief` 后，读取输出中的实际 SOW 和 [内置商业论证与提案方法](methods/business-case-and-proposal.source.md)。business-case-and-proposal 已作为内部方法模块集成到本 Skill，所有机器都直接读取包内文件，不查找宿主的其他 Skill 库。来源、版本与许可证保留在方法原文及 JSON 契约中。

应用方法完成实际商业论证、story map 及章节计划，再用真实制作实例运行 `proposal-record`。记录绑定 SOW、方法原文和实际写作结果。交接文件表示输入已准备，制作记录表示执行者对已产出文稿的声明；文件哈希核对版本，商业与表达质量由独立复核判断。

运行 `production-check`，沿用原有内容确认后，通过 `build` 生成书面 Proposal，再 `export` 得到实际 PDF。即使已选择 PPT，`build` 也先只制作书面稿。新增商务选项保持“提议、待议定”的身份。

用户选择 PPT 后，运行 `presentation-brief`，读取其中的实际 Proposal 和章节内容，读取包内 ppt-image-render 原文及 [集成入口](ppt-image-render.md)，编排汇报版页计划，再用实际制作实例运行 `presentation-record`。运行 `presentation-image-prepare` 创建图像制作输入，完成实际出图与审计，将晋级图像和对象区域登记回页计划并更新 `presentation-record`。关键页试制使用适配器的 `--calibration`，完成内部校准与 `production-check` 后运行 `presentation-build`。该阶段复用已导出的 Proposal；方法文件及配套脚本校验包内版本，不搜索宿主 skill 目录。

`chain-check` 检查当前阶段来源及版本。记录结构与命令在 JSON 契约和 Schema 中定义；生成记录保留历史版本。变更 SOW 输入、实际文稿或页计划后，重新完成受影响的阶段交接，已有有效业务授权继续沿用。
