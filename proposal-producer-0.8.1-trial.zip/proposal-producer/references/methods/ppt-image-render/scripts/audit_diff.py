#!/usr/bin/env python3
"""
audit_diff.py — Content QA · v2.2 升级为 4 层 QA 入口

v2.0 版本：只有层 1（字符级 diff）· 依赖外部提供的 ocr_extracts.json
v2.2 patch：追加层 0 / 层 2.5 / 层 3 · 一门化 4 层入口

分层：
  层 0 · Literal-Transcription Audit（R15 · 每页必跑）
        · vision LLM ⊕ OCR 交叉判定 verbatim 字段
        · 由 --literal-json 输入 vision LLM 转写、--ocr-json 输入 OCR 结果
        · R15b 语义弱化版：不做双 vision 交叉（gsk 现实约束 · 见 patch-v2.2.md）
        · R15d 关键字符串锁：verbatim_miss 非空 = FAIL
  层 1 · Content QA · 字符级 diff（v2.0 原逻辑 · 逐字符 miss_rate）
  层 2 · File QA · pptx 结构（在 validate_deck.py · 本脚本不做）
  层 2.5 · Resolution consistency（v2.2 新增 · 防 gpt-image-2 auto 退化 1024×1024）
  层 3 · 版面契约五条（v2.2 新增 · SKILL.md §4.3 · 需 --layout-json 输入 agent 侧判定）

输入：
  --pages-dir      00_source/
  --staging-dir    04_output/_staging/
  --diff-report    03_render_report/diff_report.json（已有）
  --ocr-json       03_render_report/ocr_extracts.json（ocr_extract.py 产物 · 层 0 用）
  --literal-json   03_render_report/literal_transcription.json（agent 侧 gsk understand_images
                   产物 · 结构见 `assets/diff_report.schema.json` literal_transcription 字段）
  --layout-json    03_render_report/layout_verdict.json（agent 侧五条契约判定 · 可选）
  --audit-out      03_render_report/audit_result.json
  --threshold-miss 允许的漏字率上限（默认 0.05）
  --strict-l0      层 0 FAIL 是否直接返回非零（默认 True）
  --strict-l25     层 2.5 分辨率一致性 FAIL 是否直接返回非零（默认 True）

设计边界（见 references/patch-v2.2.md 反向意见）：
  - 本脚本不调用任何 LLM · 不调用 OCR 引擎 · 只做纯文本对账 + JSON 归并
  - 层 0 的 LLM 转写 / OCR 由外部产物 JSON 提供 · 出问题不会阻塞本脚本
  - 层 2.5 分辨率通过读取 png header 判定，不依赖外部输入

依赖：
  - Python 标准库 + Pillow（用于层 2.5 读 png 尺寸 · 缺失时降级为跳过 + WARN）
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path
from typing import Iterable

PUNCT_CHARS = ' \t\n\r\u3000\u200b\uFEFF.,，。、；：;:!！?？（）()[]【】《》"\'`~<>—…-'
PUNCT_RE = re.compile('[' + re.escape(PUNCT_CHARS) + ']')


def normalize(text: str) -> str:
    text = text.lower()
    text = PUNCT_RE.sub("", text)
    return text


def char_multiset(text: str) -> dict[str, int]:
    d: dict[str, int] = {}
    for c in text:
        d[c] = d.get(c, 0) + 1
    return d


def diff_counts(source_multi: dict, ocr_multi: dict) -> tuple[int, int]:
    """返回 (source_only_chars, ocr_only_chars)"""
    src_only, ocr_only = 0, 0
    for c, n in source_multi.items():
        m = ocr_multi.get(c, 0)
        if n > m:
            src_only += (n - m)
    for c, n in ocr_multi.items():
        m = source_multi.get(c, 0)
        if n > m:
            ocr_only += (n - m)
    return src_only, ocr_only


def extract_key_terms(source_md: str) -> list[str]:
    """
    提取源文中"必须原样保留"的关键术语：
    - 加粗短语 **X**
    - 数字（含%/年月日）
    - 大写缩写（AI, API, JV 等 2+ 字母全大写）
    """
    terms: list[str] = []
    terms += re.findall(r"\*\*([^*]{2,40})\*\*", source_md)
    terms += re.findall(r"\b\d[\d,]*\s*(?:%|个|天|月|年|页|道|条|次|人)?", source_md)
    terms += re.findall(r"\b[A-Z]{2,}\b", source_md)
    return list({t.strip() for t in terms if t.strip()})


# ============ v2.2 新增：层 2.5 分辨率一致性 ============

EXPECTED_MIN_16_9 = [
    # 常见 16:9 目标尺寸的最小可接受宽度 · 用于识别"是否退化到 1024x1024"
    (1920, 1080),  # 2k
    (3840, 2160),  # 4k
]

def check_resolution(img_path: Path) -> tuple[bool, str, tuple[int, int] | None]:
    """
    返回 (is_ok, msg, (w,h))
    is_ok = False 的两种情形：
      A · 尺寸接近 1:1（|w-h|/max(w,h) < 5%）· 判为退化
      B · 尺寸 < 1920×1080 · 判为不达标
    """
    try:
        from PIL import Image  # type: ignore
    except ImportError:
        return (True, "SKIP · Pillow 未安装 · 跳过分辨率检查（Warning）", None)
    try:
        with Image.open(img_path) as im:
            w, h = im.size
    except Exception as e:
        return (False, f"cannot open image · {type(e).__name__}: {e}", None)

    # A · 近 1:1
    ratio_diff = abs(w - h) / max(w, h)
    if ratio_diff < 0.05:
        return (False,
                f"resolution degraded to ~1:1 ({w}x{h}) · v2.2 层 2.5 FAIL · "
                f"gpt-image-2 auto 模式陷阱 · 见 references/patch-v2.2.md",
                (w, h))
    # B · 不达 2K
    if w < 1920 or h < 1080:
        return (False,
                f"resolution below 1920x1080 ({w}x{h}) · v2.2 层 2.5 FAIL",
                (w, h))
    return (True, f"OK · {w}x{h}", (w, h))


# ============ v2.2 新增：层 0 · vision ⊕ OCR 交叉 ============

def layer0_cross_check(pid: str, literal_data: dict, ocr_data: dict) -> dict:
    """
    交叉判定：
      - literal_data[pid]["fields"]: agent 侧 vision LLM 逐字段转写结果
        形如 {"六大总体架构信息流程图": "六大总体架构信息流程图", ...}
      - ocr_data[pid]["verbatim_hits"] / ["verbatim_miss"]: OCR 侧命中情况

    判定：
      OK  = vision 与 OCR 均命中
      LLM_ONLY = vision 命中 · OCR 未命中（OCR 精度问题 · 记 WARN · 不 FAIL）
      OCR_ONLY = vision 未命中 · OCR 命中（vision 幻觉遗漏 · 记 WARN）
      MISS_BOTH = 两者都未命中 · 记 FAIL（R15d 铁闸）
    """
    lit = literal_data.get(pid, {}) or {}
    ocr = ocr_data.get(pid, {}) or {}
    lit_fields: dict[str, str] = lit.get("fields", {}) or {}
    ocr_hits: dict[str, bool] = ocr.get("verbatim_hits", {}) or {}

    ok_fields: list[str] = []
    llm_only: list[str] = []
    ocr_only: list[str] = []
    miss_both: list[str] = []

    all_keys = set(lit_fields.keys()) | set(ocr_hits.keys())
    for k in all_keys:
        lit_hit = bool(lit_fields.get(k)) and lit_fields.get(k) != "MISSING"
        ocr_hit = bool(ocr_hits.get(k, False))
        if lit_hit and ocr_hit:
            ok_fields.append(k)
        elif lit_hit and not ocr_hit:
            llm_only.append(k)
        elif ocr_hit and not lit_hit:
            ocr_only.append(k)
        else:
            miss_both.append(k)

    verdict = "pass"
    if miss_both:
        verdict = "fail"  # R15d 关键字符串锁
    elif llm_only or ocr_only:
        verdict = "warn"

    return {
        "verdict": verdict,
        "ok_fields": ok_fields,
        "llm_only": llm_only,   # OCR 精度问题 · 不作 FAIL 依据
        "ocr_only": ocr_only,   # vision 幻觉遗漏 · 不作 FAIL 依据
        "miss_both": miss_both, # R15d FAIL 依据
        "cross_check_engine": "vision_llm_XOR_ocr (R15b weak · patch-v2.2)",
    }


# ============ end v2.2 新增 ============


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pages-dir", required=True, type=Path)
    ap.add_argument("--staging-dir", required=True, type=Path)
    ap.add_argument("--diff-report", required=True, type=Path)
    ap.add_argument("--ocr-json", required=True, type=Path)
    ap.add_argument("--literal-json", required=False, type=Path,
                    help="v2.2 新增 · agent 侧 gsk understand_images 逐字段转写结果")
    ap.add_argument("--layout-json", required=False, type=Path,
                    help="v2.2 新增 · agent 侧五条版面契约判定结果")
    ap.add_argument("--audit-out", required=True, type=Path)
    ap.add_argument("--threshold-miss", type=float, default=0.05)
    ap.add_argument("--strict-l0", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--strict-l25", action=argparse.BooleanOptionalAction, default=True)
    args = ap.parse_args()

    diff = json.loads(args.diff_report.read_text(encoding="utf-8"))

    # 兼容两种 --ocr-json 格式：
    #   A · v2.0 老格式：{page: ocr_text}
    #   B · v2.2 ocr_extract.py 产物：{"pages": {pid: {ocr_text, verbatim_hits, ...}}}
    ocr_raw = json.loads(args.ocr_json.read_text(encoding="utf-8")) if args.ocr_json.exists() else {}
    if isinstance(ocr_raw, dict) and "pages" in ocr_raw:
        ocr_pages: dict = ocr_raw["pages"]
        ocrs: dict[str, str] = {p: v.get("ocr_text", "") for p, v in ocr_pages.items()}
    else:
        ocr_pages = {}
        ocrs = ocr_raw if isinstance(ocr_raw, dict) else {}

    # 层 0 · literal-transcription（v2.2 新增 · 可选）
    literal_pages: dict = {}
    if args.literal_json and args.literal_json.exists():
        lit_raw = json.loads(args.literal_json.read_text(encoding="utf-8"))
        literal_pages = lit_raw.get("pages", lit_raw)

    # 层 3 · layout_verdict（v2.2 新增 · 可选）
    layout_verdicts: dict = {}
    if args.layout_json and args.layout_json.exists():
        lay_raw = json.loads(args.layout_json.read_text(encoding="utf-8"))
        layout_verdicts = lay_raw.get("pages", lay_raw)

    results: list[dict] = []
    any_fail = False

    for entry in diff["files"]:
        pid = entry["page"]
        src = (args.pages_dir / f"{pid}.md")
        if not src.exists():
            src = next(args.pages_dir.glob(f"{pid}_*.md"), None)
        if src is None or not src.exists():
            print(f"[WARN] source not found for {pid}", file=sys.stderr)
            continue

        # ---------- 层 1 · 字符级 diff（v2.0 原逻辑） ----------
        source_norm = normalize(src.read_text(encoding="utf-8"))
        ocr_norm = normalize(ocrs.get(pid, ""))
        src_only, ocr_only = diff_counts(char_multiset(source_norm),
                                          char_multiset(ocr_norm))
        miss_rate = src_only / max(len(source_norm), 1)

        terms = extract_key_terms(src.read_text(encoding="utf-8"))
        missing_terms = [t for t in terms if normalize(t) and normalize(t) not in ocr_norm]

        l1_verdict = "pass"
        if miss_rate >= args.threshold_miss or missing_terms:
            l1_verdict = "fail"
            any_fail = True
        elif miss_rate > args.threshold_miss * 0.6:
            l1_verdict = "warn"

        # ---------- 层 0 · vision LLM ⊕ OCR 交叉（v2.2） ----------
        l0_result = layer0_cross_check(pid, literal_pages, ocr_pages)
        if l0_result["verdict"] == "fail" and args.strict_l0:
            any_fail = True

        # ---------- 层 2.5 · 分辨率一致性（v2.2） ----------
        img_path = args.staging_dir / f"{pid}.png"
        if img_path.exists():
            res_ok, res_msg, res_size = check_resolution(img_path)
        else:
            res_ok, res_msg, res_size = True, "no image · skip", None
        l25 = {
            "ok": res_ok,
            "msg": res_msg,
            "size": list(res_size) if res_size else None,
        }
        if not res_ok and args.strict_l25:
            any_fail = True

        # ---------- 层 3 · 版面契约五条（v2.2 · agent 侧输入） ----------
        l3 = layout_verdicts.get(pid, {})
        # 期望结构：{title_ok, underline_ok, margins_ok, safe_zone_ok, footer_ok, verdict}
        if l3.get("verdict") == "fail":
            any_fail = True

        result = {
            "page": pid,
            "layer_0_literal_transcription": l0_result,
            "layer_1_content_qa": {
                "miss_rate": round(miss_rate, 4),
                "source_only_chars": src_only,
                "ocr_only_chars": ocr_only,
                "missing_terms": missing_terms,
                "verdict": l1_verdict,
            },
            "layer_2_5_resolution": l25,
            "layer_3_layout_contract": l3 or {"verdict": "skip",
                                              "note": "no layout-json provided"},
            "verdict": (
                "fail" if (
                    l0_result["verdict"] == "fail"
                    or l1_verdict == "fail"
                    or not res_ok
                    or l3.get("verdict") == "fail"
                )
                else "warn" if (
                    l0_result["verdict"] == "warn"
                    or l1_verdict == "warn"
                    or l3.get("verdict") == "warn"
                )
                else "pass"
            ),
        }
        results.append(result)
        entry["audit"] = result

    args.audit_out.parent.mkdir(parents=True, exist_ok=True)
    args.audit_out.write_text(json.dumps({
        "skill_version": "v2.2",
        "layers_run": ["layer_0", "layer_1", "layer_2_5", "layer_3"],
        "threshold_miss": args.threshold_miss,
        "strict_l0": args.strict_l0,
        "strict_l25": args.strict_l25,
        "total_pages": len(results),
        "pass_count": sum(1 for r in results if r["verdict"] == "pass"),
        "fail_count": sum(1 for r in results if r["verdict"] == "fail"),
        "warn_count": sum(1 for r in results if r["verdict"] == "warn"),
        "results": results,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    args.diff_report.write_text(json.dumps(diff, ensure_ascii=False, indent=2),
                                 encoding="utf-8")
    print(f"[{'FAIL' if any_fail else 'OK'}] 4-layer QA · "
          f"pass={sum(1 for r in results if r['verdict'] == 'pass')}, "
          f"warn={sum(1 for r in results if r['verdict'] == 'warn')}, "
          f"fail={sum(1 for r in results if r['verdict'] == 'fail')}")
    return 1 if any_fail else 0


if __name__ == "__main__":
    sys.exit(main())
