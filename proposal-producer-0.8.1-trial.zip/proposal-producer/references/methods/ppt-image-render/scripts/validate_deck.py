#!/usr/bin/env python3
"""
validate_deck.py — File QA · pptx 结构校验（v2.0 新增，对齐 Anthropic pptx skill 的 validate.py）

输入：
  --pptx       04_output/deck.pptx
  --pages-dir  00_source/       （用于核对页数）
  --out        03_render_report/validate_result.json

检查：
  1. 能被 python-pptx 打开
  2. 宽高 = 12192000 × 6858000 EMU（16:9）
  3. 页数 == 源文件数
  4. 每页仅一张图片，铺满整页（无空白框）
  5. OOXML 基础 schema（未安装 lxml 时跳过）

不做：
  - 检查图片语义（那是 Visual QA 的活）
  - 检查 pptx 里的字体（本 skill 只出图，pptx 里除页脚外无文本框）
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path


REQUIRED_WIDTH_EMU = 12192000   # 16:9 · 1920
REQUIRED_HEIGHT_EMU = 6858000   # 16:9 · 1080


def validate(pptx_path: Path, pages_dir: Path) -> dict:
    checks: dict = {}
    ok = True

    try:
        from pptx import Presentation  # type: ignore
    except ImportError:
        return {"error": "python-pptx not installed", "verdict": "skip"}

    try:
        prs = Presentation(str(pptx_path))
    except Exception as e:
        return {"error": f"cannot open pptx: {e}", "verdict": "fail"}

    # 1. 画布尺寸
    checks["canvas_size_ok"] = (
        prs.slide_width == REQUIRED_WIDTH_EMU
        and prs.slide_height == REQUIRED_HEIGHT_EMU
    )
    if not checks["canvas_size_ok"]:
        ok = False

    # 2. 页数
    src_count = len(list(pages_dir.glob("*.md")))
    slide_count = len(prs.slides)
    checks["page_count_ok"] = (src_count == slide_count)
    checks["source_pages"] = src_count
    checks["deck_pages"] = slide_count
    if not checks["page_count_ok"]:
        ok = False

    # 3. 每页仅一张图片，铺满
    per_slide_issues: list[dict] = []
    for idx, slide in enumerate(prs.slides, start=1):
        pictures = [s for s in slide.shapes if s.shape_type == 13]  # 13 = PICTURE
        issues = []
        if len(pictures) != 1:
            issues.append(f"expected 1 picture, got {len(pictures)}")
        elif pictures:
            pic = pictures[0]
            # 铺满允许 ±0.5% 误差
            if abs(pic.width - prs.slide_width) / prs.slide_width > 0.005:
                issues.append(f"picture width {pic.width} != slide width {prs.slide_width}")
            if abs(pic.height - prs.slide_height) / prs.slide_height > 0.005:
                issues.append(f"picture height {pic.height} != slide height {prs.slide_height}")
        if issues:
            per_slide_issues.append({"slide": idx, "issues": issues})
    checks["all_slides_full_bleed"] = not per_slide_issues
    if per_slide_issues:
        ok = False
    checks["slide_issues"] = per_slide_issues

    return {**checks, "verdict": "pass" if ok else "fail"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pptx", required=True, type=Path)
    ap.add_argument("--pages-dir", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()

    result = validate(args.pptx, args.pages_dir)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[{result.get('verdict', '?').upper()}] File QA · {args.out}")
    return 0 if result.get("verdict") == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
