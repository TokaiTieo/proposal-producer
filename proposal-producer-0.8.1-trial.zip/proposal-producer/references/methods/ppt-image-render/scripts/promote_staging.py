#!/usr/bin/env python3
"""
promote_staging.py — R11 staging 隔离升级（v2.0 脚本化）

输入：
  --staging-dir    04_output/_staging/
  --images-dir     04_output/images/
  --audit-json     03_render_report/audit_result.json
  --validate-json  03_render_report/validate_result.json
  --visual-qa-json 03_render_report/visual_qa.json  （agent 侧写入）
  --log-out        03_render_report/promotion_log.json

规则：
  三层 QA (audit / validate / visual_qa) 全过 → 移动 _staging → images
  任一不过 → 留在 staging，标记失败原因

绝不：
  - 覆盖 images/ 里已有的同名文件（隔离归档要求）
  - 未过 QA 就 promote
"""
from __future__ import annotations
import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path


def load_or_empty(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--staging-dir", required=True, type=Path)
    ap.add_argument("--images-dir", required=True, type=Path)
    ap.add_argument("--audit-json", required=True, type=Path)
    ap.add_argument("--validate-json", required=False, type=Path)  # 未打包 pptx 时可缺
    ap.add_argument("--visual-qa-json", required=True, type=Path)
    ap.add_argument("--log-out", required=True, type=Path)
    args = ap.parse_args()

    audit = load_or_empty(args.audit_json)
    visual = load_or_empty(args.visual_qa_json)
    audit_pass = {r["page"] for r in audit.get("results", []) if r["verdict"] == "pass"}
    visual_pass = {p for p, v in visual.items() if v.get("verdict") == "pass"}

    args.images_dir.mkdir(parents=True, exist_ok=True)

    promoted: list[dict] = []
    stayed: list[dict] = []

    for src in sorted(args.staging_dir.glob("*.png")):
        pid = src.stem.split("_")[0] + "_" + src.stem.split("_")[1] \
            if "_P" in src.stem else src.stem
        # 兼容 L0_P03_信息架构_4k.png 这种命名
        # 简化：取前两段
        parts = src.stem.split("_")
        if len(parts) >= 2 and parts[1].startswith("P"):
            pid = f"{parts[0]}_{parts[1]}"

        ok_audit = pid in audit_pass
        ok_visual = pid in visual_pass

        if ok_audit and ok_visual:
            dst = args.images_dir / src.name
            if dst.exists():
                stayed.append({"page": pid, "reason": f"target exists: {dst}", "src": str(src)})
                continue
            shutil.move(str(src), str(dst))
            promoted.append({
                "page": pid,
                "from": str(src),
                "to": str(dst),
                "at": datetime.now(timezone.utc).isoformat(),
            })
        else:
            stayed.append({
                "page": pid,
                "reason": {
                    "audit_pass": ok_audit,
                    "visual_qa_pass": ok_visual,
                },
                "src": str(src),
            })

    payload = {
        "promoted_count": len(promoted),
        "stayed_count": len(stayed),
        "promoted": promoted,
        "stayed": stayed,
        "at": datetime.now(timezone.utc).isoformat(),
    }
    args.log_out.parent.mkdir(parents=True, exist_ok=True)
    args.log_out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[OK] promoted={len(promoted)}, stayed={len(stayed)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
