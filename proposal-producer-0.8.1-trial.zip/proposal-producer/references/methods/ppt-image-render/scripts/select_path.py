#!/usr/bin/env python3
"""
select_path.py — 双链路选路网关 + v2.2 高密度页自动判定

输入：
  --pages-dir       00_source/ 目录
  --blueprints-dir  05_blueprints/ 目录（可能不存在）
  --out             03_render_report/path_decision.json
  --out-hd-flags    03_render_report/high_density_flags.json  (v2.2 新增)

规则：
  - {page}_zh.png 或 {page}.png 在 blueprints-dir 存在 → B_blueprint
  - 否则                                              → A_three_stage
  - v2.2 新增：每页额外自动判定 high_density: true/false（对应 SKILL.md §2.3）
  - 决策一旦写入，禁止手工 override（真要 override 必须记入 06_changelog/）

v2.2 判定规则（SKILL.md §2.3 五条 · 满足任一 → true）：
  HD-1  正文字符 ≥ 5000 且 ≤ 15000（4K 档 · 密度警戒区）
  HD-2  主流程节点数 ≥ 8   （P10 类信息流程图）  · 通过节点关键词计数近似
  HD-3  子模块/卡片/图标数 ≥ 25 （P7/P12 类多层架构图）
  HD-4  分层横向/纵向切分 ≥ 5 层 （P12 类六层架构图）
  HD-5  出现锁字关键词（必须保留 / 不可删除 / 100% 呈现 / 一字不删 / 蓝本图为事实标准 / 节点内 5-8 行子项）
        或主题词包含（架构图 / 总体架构 / 信息流程 / 承诺列表 / 报价明细 / 数据链路 / 技术底座）

用法：
  python scripts/select_path.py \
      --pages-dir ./00_source \
      --blueprints-dir ./05_blueprints \
      --out ./03_render_report/path_decision.json \
      --out-hd-flags ./03_render_report/high_density_flags.json
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


def page_id_from_source(p: Path) -> str:
    """从 00_source/L0_P03_信息架构.md 提取 'L0_P03'."""
    m = re.match(r"^(L\d+_P\d+)", p.stem)
    return m.group(1) if m else p.stem


def blueprint_exists(page_id: str, bp_dir: Path) -> str | None:
    """返回蓝本图路径（相对），找不到返回 None."""
    if not bp_dir.exists():
        return None
    for suffix in ("_zh.png", ".png", "_zh.jpg", ".jpg"):
        candidate = bp_dir / f"{page_id}{suffix}"
        if candidate.exists():
            return str(candidate)
    return None


# ============ v2.2 新增：high_density 自动判定 ============

LOCK_KEYWORDS = [
    "必须保留", "不可删除", "100% 呈现", "100%呈现",
    "一字不删", "一字不动", "蓝本图为事实标准", "节点内 5-8 行子项",
    "节点内5-8行子项",
]

TOPIC_KEYWORDS = [
    "架构图", "总体架构", "信息流程", "承诺列表", "报价明细",
    "数据链路", "技术底座", "全景图", "六层架构", "五层架构",
]

# 节点近似：编号列表项、markdown 无序/有序列表项、Node/节点显式关键词
NODE_RE = re.compile(
    r"(?m)^\s*(?:[-*+]\s+|\d+\.\s+|Node\s*\d+|节点\s*\d+|"
    r"Step\s*\d+|Card\s*\d+|Layer\s*\d+)"
)
# 卡片/子模块/图标近似：加粗短语、Card N / 子模块 / 图标 词条
CARD_RE = re.compile(
    r"\*\*[^*\n]{2,40}\*\*|Card\s*\d+|Module\s*\d+|"
    r"子模块|图标|Agent\s*\d+|Icon\s*\d+"
)
# 层近似：markdown H2/H3 标题、"层" / "Layer" 显式词、水平分隔线 ---
LAYER_H_RE = re.compile(r"(?m)^(?:##\s+|###\s+)")
LAYER_WORD_RE = re.compile(r"(?:第\s*[一二三四五六七八九十\d]+\s*层|Layer\s*\d+|层\s*[一二三四五六七八九十\d]+)")


def judge_high_density(source_md: str, h1: str) -> tuple[bool, list[str], dict]:
    """
    返回 (is_high_density, hit_signals, metrics)
    hit_signals 记录命中了哪些 HD-x 规则；metrics 是各计数值原始数据。
    """
    body_chars = len(source_md)
    node_count = len(NODE_RE.findall(source_md))
    card_count = len(set(CARD_RE.findall(source_md)))
    layer_count = len(LAYER_H_RE.findall(source_md)) + len(set(LAYER_WORD_RE.findall(source_md)))

    hit_locks = [kw for kw in LOCK_KEYWORDS if kw in source_md]
    hit_topics = [kw for kw in TOPIC_KEYWORDS if kw in h1 or kw in source_md[:400]]

    signals: list[str] = []
    if 5000 <= body_chars <= 15000:
        signals.append(f"HD-1(body_chars={body_chars} in [5000,15000])")
    if node_count >= 8:
        signals.append(f"HD-2(node_count={node_count}>=8)")
    if card_count >= 25:
        signals.append(f"HD-3(card_count={card_count}>=25)")
    if layer_count >= 5:
        signals.append(f"HD-4(layer_count={layer_count}>=5)")
    if hit_locks:
        signals.append(f"HD-5-lock({','.join(hit_locks)})")
    if hit_topics:
        signals.append(f"HD-5-topic({','.join(hit_topics)})")

    metrics = {
        "body_chars": body_chars,
        "node_count": node_count,
        "card_count": card_count,
        "layer_count": layer_count,
        "lock_keywords_hit": hit_locks,
        "topic_keywords_hit": hit_topics,
    }

    return (len(signals) > 0, signals, metrics)


def extract_h1(md: str) -> str:
    for line in md.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip()
    return ""


# ============ end v2.2 新增 ============


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pages-dir", required=True, type=Path)
    ap.add_argument("--blueprints-dir", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--out-hd-flags", required=False, type=Path,
                    help="v2.2 新增 · high_density_flags.json 输出路径。"
                         "缺省 = <out 同级>/high_density_flags.json")
    args = ap.parse_args()

    if not args.pages_dir.exists():
        print(f"[FAIL] pages-dir not found: {args.pages_dir}", file=sys.stderr)
        return 2

    decisions: dict[str, dict] = {}
    hd_flags: dict[str, dict] = {}
    for src in sorted(args.pages_dir.glob("*.md")):
        pid = page_id_from_source(src)
        bp = blueprint_exists(pid, args.blueprints_dir)

        # v2.2 新增：读源文做 high_density 判定
        try:
            source_text = src.read_text(encoding="utf-8")
        except Exception as e:
            print(f"[WARN] cannot read {src}: {e}", file=sys.stderr)
            source_text = ""
        h1 = extract_h1(source_text)
        is_hd, signals, metrics = judge_high_density(source_text, h1)

        decisions[pid] = {
            "source_file": str(src),
            "path_type": "B_blueprint" if bp else "A_three_stage",
            "blueprint": bp,
            "reason": "blueprint image found" if bp else "no blueprint, default to three-stage",
            # v2.2 新增字段（并列于 path_type · build_prompt.py 会读它触发 C 路径）
            "high_density": is_hd,
            "high_density_signals": signals,
        }
        hd_flags[pid] = {
            "high_density": is_hd,
            "signals": signals,
            "metrics": metrics,
            "h1": h1,
        }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    total_hd = sum(1 for d in decisions.values() if d["high_density"])
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "skill_version": "v2.2",
        "total_pages": len(decisions),
        "counts": {
            "A_three_stage": sum(1 for d in decisions.values() if d["path_type"] == "A_three_stage"),
            "B_blueprint":   sum(1 for d in decisions.values() if d["path_type"] == "B_blueprint"),
            "high_density":  total_hd,
        },
        "decisions": decisions,
    }
    args.out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    # v2.2 新增：输出 high_density_flags.json
    hd_path = args.out_hd_flags or (args.out.parent / "high_density_flags.json")
    hd_payload = {
        "generated_at": payload["generated_at"],
        "skill_version": "v2.2",
        "total_pages": len(hd_flags),
        "high_density_count": total_hd,
        "flags": hd_flags,
    }
    hd_path.write_text(json.dumps(hd_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[OK] wrote {args.out} · {payload['total_pages']} pages "
          f"(A={payload['counts']['A_three_stage']}, "
          f"B={payload['counts']['B_blueprint']}, "
          f"HD={total_hd})")
    print(f"[OK] wrote {hd_path} · high_density flags for all pages")
    return 0


if __name__ == "__main__":
    sys.exit(main())
