#!/usr/bin/env python3
"""
init_project.py — 新项目一键建 6 层目录 + 拷贝 style_overlay

用法：
  python scripts/init_project.py --root ./my_new_project --skill ./skills/ppt-image-render

产物：
  my_new_project/
    ├── 00_source/
    ├── 01_style_overlay/
    │   ├── style_overlay_lean.md      ← 从 skill/assets 复制
    │   └── style_overlay_full.md
    ├── 02_render_prompt/
    ├── 03_render_report/
    ├── 04_output/
    │   ├── images/
    │   └── _staging/
    ├── 05_blueprints/
    ├── 06_changelog/
    │   └── project_overrides.md   ← 空模板
    └── README.md                  ← 从 skill 模板生成
"""
from __future__ import annotations
import argparse
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path


LAYERS = [
    "00_source",
    "01_style_overlay",
    "02_render_prompt",
    "03_render_report",
    "04_output/images",
    "04_output/_staging",
    "05_blueprints",
    "06_changelog",
]

OVERRIDES_TEMPLATE = """# 项目级 SOP 偏离清单

> 每一条偏离必须写清楚：偏离了哪条 SOP、为什么、什么时候回归、由谁决策。

## 偏离记录

（暂无。默认全部按 skill v2.0 主线执行。）
"""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    ap.add_argument("--skill", required=True, type=Path, help="ppt-image-render skill 根目录")
    args = ap.parse_args()

    if args.root.exists() and any(args.root.iterdir()):
        print(f"[FAIL] {args.root} not empty, refusing to init", file=sys.stderr)
        return 2

    args.root.mkdir(parents=True, exist_ok=True)
    for layer in LAYERS:
        (args.root / layer).mkdir(parents=True, exist_ok=True)

    # 拷贝 style_overlay
    for name in ("style_overlay.md", "style_overlay_full.md"):
        src = args.skill / "assets" / name
        if src.exists():
            dst_name = "style_overlay_lean.md" if name == "style_overlay.md" else name
            shutil.copy(src, args.root / "01_style_overlay" / dst_name)

    # 项目 changelog 模板
    (args.root / "06_changelog" / "project_overrides.md").write_text(OVERRIDES_TEMPLATE, encoding="utf-8")

    # README
    now = datetime.now(timezone.utc).isoformat()
    (args.root / "README.md").write_text(f"""# {args.root.name}

Created: {now}
Skill: ppt-image-render v2.0 (see {args.skill})

## 5 步主流程（背下来）

1. `scripts/select_path.py` → path_decision.json
2. 目录已建（本脚本已完成）
3. `scripts/build_prompt.py` → 02_render_prompt/*.prompt.md
4. Agent 出图 → 04_output/_staging/
5. `scripts/audit_diff.py` + `scripts/validate_deck.py` → `scripts/promote_staging.py`

详见 skill 主入口 SKILL.md 的 §1–§6。
""", encoding="utf-8")

    print(f"[OK] initialized {args.root}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
