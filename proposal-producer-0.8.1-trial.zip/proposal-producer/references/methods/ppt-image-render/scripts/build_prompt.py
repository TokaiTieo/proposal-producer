#!/usr/bin/env python3
"""
build_prompt.py — render_prompt 拼装 · 严格按 references/prompt-assembly.md
v2.2 patch：新增 C 路径（高密度页六段拼装）+ R9 sandwich hash assert + R-V5 铁闸

输入：
  --pages-dir            00_source/
  --style-overlay        01_style_overlay/style_overlay_lean.md
  --path-decision        03_render_report/path_decision.json  (v2.2 后带 high_density 字段)
  --out-prompt-dir       02_render_prompt/
  --out-diff             03_render_report/diff_report.json
  --hd-max-card-reads    R-V5 铁闸阈值 · 默认 9 · 超过退化为无 quote-lock 模式

动作：
  1. 读每页源文件
  2. strip_display_noise() 清洗（R14.3），记入 diff_report
  3. 按路径拼装：
       A 三段式（v2.0 原文）：style_lean + H1 + 完整源文
       B 蓝本追加（v2.0 原文）：A + 蓝本说明
       C 高密度包（v2.1 语义 · v2.2 落地）：段1 硬约束首段 + A 三段 + 段5 HDG-Pack + 段6 硬约束尾段
          + assert sha256(段1) == sha256(段6)  (R9)
          + assert num_card_reads <= hd_max_card_reads  (R-V5 铁闸)
  4. 长度校验（A/B 路径 > 5% 直接 FAIL；C 路径因 hard_constraints 追加，不套 5% assert）
  5. 写 {page}.prompt.md
  6. 增量更新 diff_report.json（新增 high_density / sandwich_applied /
     hdg_pack_applied / card_reads_count 字段）

绝不：
  - 设 max_chars 截断
  - 提取要点 / 摘要
  - 合并空行 / 改标题层级 / 重排列表
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


# —— R14.3 展示层去思考化 · 允许的清洗清单 ——
DISPLAY_NOISE_PATTERNS = [
    r"^\s*完整原文.*$",
    r"^\s*页面定位.*$",
    r"^\s*(这一章|本页)要让受众明白什么.*$",
    r"^\s*本质是什么.*$",
    r"^\s*Q&A\s*高概率提问预告.*$",
    r"^\s*硬约束清单.*$",
    r"^\s*给模型用.*$",
    r"^\s*段\s*[1-5一二三四五].*$",
]
DISPLAY_NOISE_RE = re.compile("|".join(DISPLAY_NOISE_PATTERNS), re.MULTILINE)

HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
FRONTMATTER_RE = re.compile(r"\A---\n.*?\n---\n", re.DOTALL)


def sha256(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def extract_h1(md: str) -> str:
    for line in md.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip()
    return "(无标题)"


def strip_wrappers_and_noise(md: str) -> tuple[str, list[dict]]:
    """
    返回 (清洗后正文, 记入 diff 的移除记录列表)
    仅移除：HTML 注释块、frontmatter、R14.3 展示层过程性段落
    禁止：删任何非上述范畴的行 / 合并空行 / 改层级
    """
    removed: list[dict] = []

    # 1) frontmatter
    m = FRONTMATTER_RE.match(md)
    if m:
        removed.append({
            "block_type": "metadata_label",
            "content_preview": md[m.start():m.end()][:120],
            "line_range": [1, md[:m.end()].count("\n")],
        })
        md = md[m.end():]

    # 2) HTML 注释块
    for cm in HTML_COMMENT_RE.finditer(md):
        removed.append({
            "block_type": "html_comment",
            "content_preview": cm.group(0)[:120],
            "line_range": [
                md[:cm.start()].count("\n") + 1,
                md[:cm.end()].count("\n") + 1,
            ],
        })
    md = HTML_COMMENT_RE.sub("", md)

    # 3) 展示层过程性段落（整行删除）
    lines = md.splitlines()
    kept = []
    for i, line in enumerate(lines, start=1):
        if DISPLAY_NOISE_RE.match(line):
            removed.append({
                "block_type": "display_noise",
                "content_preview": line.strip()[:120],
                "line_range": [i, i],
            })
        else:
            kept.append(line)
    return "\n".join(kept), removed


def build_three_stage(style_lean: str, h1: str, body: str) -> str:
    return (
        style_lean.rstrip()
        + "\n\n本页主题：" + h1
        + "\n\n以下完整内容须 100% 呈现在图中（一字不删 · 不替换 · 不截断）：\n\n"
        + body
    )


def build_blueprint(prompt_a: str) -> str:
    return prompt_a + (
        "\n\n参考图（蓝本）说明：\n"
        "上传的图片仅用于版式与构图参考，请严格保持其空间布局、区块划分、色带位置。"
        "蓝本上的中/原文字段全部替换为本 prompt 正文，其他视觉元素完全继承。"
    )


# ============ v2.2 新增：C 路径六段拼装 ============

CARD_READS_RE = re.compile(r'^\s*Card\s+\d+\s+(?:title\s+)?reads:\s*".+?"', re.MULTILINE)


def build_hard_constraints(h1: str, source_body: str, path_type: str) -> str:
    """
    构造首尾一致的硬约束清单（段 1 / 段 6）· 内容对应 SKILL.md §4.5 六条。
    首尾必须字字一致 —— 本函数被段 1 / 段 6 各调用一次，只要输入相同，
    输出就相同；build_high_density_prompt() 会 sha256 两份 assert。
    """
    return (
        "【硬约束清单 · sandwich · v2.2 R9 复活】\n"
        f"① 本页主题：{h1}\n"
        f"② 蓝本图为事实标准（仅当走 B 链路时生效；当前 path_type={path_type}）\n"
        "③ 每层每子项文字必须原样渲染 · 禁止意译 · 禁止摘要 · 禁止抽象化替换\n"
        "④ 元素计数硬锁：卡片/节点/层数必须 exactly N（N 见段 5 R-V4）\n"
        "⑤ 字号可降到 7pt · 严禁删词 · 无路可退时 OVERFLOW_FAIL 而非删除\n"
        "⑥ 底部横带原文照抄 · 详见段 5 R-V8\n"
        "⑦ 自检要求：本页产出后必须走 §6.4 逐层字面转写审计"
        "（含 OCR 关键字符串锁 · v2.2 R15d）\n"
    )


def build_hdg_pack(source_body: str) -> str:
    """
    构造 HDG-Pack 段 5（R-V4 / R-V5 / R-V7 / R-V8）· 语义严格对应
    SKILL.md §4.4。这里只生成"模板骨架 + 引导语"，具体元素计数与底部横带
    原文由 agent 侧读源文填入 —— 脚本层不承担语义抽取（否则会引入无审计的
    silent transform · 违反 R6）。
    """
    return (
        "【v2.1 HDG-Pack · 高密度页护栏 · R-V4/R-V5/R-V7/R-V8】\n\n"
        "① R-V4 · 元素计数强制：\n"
        "   对本页所有同类重复元素（Agent 卡 / Node / Layer / Card / Icon）\n"
        "   逐类写 'exactly N cards / N nodes / N layers'；\n"
        "   每处元素计数配一句字号逃生阀：\n"
        "   'if text overflows, shrink font in 1pt steps down to 7pt,\n"
        "    tighten line-height to 1.05; the count of {N} elements\n"
        "    MUST remain exactly {N}.'\n\n"
        "② R-V5 · 结构化列表 + 每行 ≤ 12 词：\n"
        "   同类重复元素必须用编号列表 · 每行 ≤ 12 词 · 只在此段使用\n"
        "   引号 quote-lock 模式（其余段落禁用 · 防 v1.6 密度爆炸复发）：\n"
        '   Card 1 title reads: "..."\n'
        '   Card 2 title reads: "..."\n'
        "   ...\n"
        "   （v2.2 铁闸：Card N reads 模式总条目 ≤ 9 · 超过则本护栏项自动\n"
        "    退化为无 quote-lock 编号列表 · 见 references/patch-v2.2.md）\n\n"
        "③ R-V7 · 字号逃生阀 · 明示不允许删词：\n"
        "   If any text does not fit at the recommended font size, apply\n"
        "   the following in order:\n"
        "   (a) reduce font size in 1pt steps down to 7pt minimum;\n"
        "   (b) tighten line-height to 1.05 minimum;\n"
        "   (c) reduce card inner padding;\n"
        "   (d) elongate card vertically;\n"
        "   (e) split the section into two rows.\n"
        "   Under no acceptable condition remove, paraphrase, or abstract\n"
        "   any word from the source content.\n\n"
        "④ R-V8 · 底部横带 · 二次锁字：\n"
        "   Final render check: any bottom horizontal bar / KPI bar /\n"
        "   pledge bar / commitment bar MUST contain exactly the text\n"
        "   written in the source markdown, verbatim, with no summary,\n"
        "   no substitute sentence, no compliance boilerplate."
    )


def build_high_density_prompt(
    style_lean: str,
    h1: str,
    body: str,
    path_type: str,
    hd_max_card_reads: int,
) -> tuple[str, dict]:
    """
    C 路径六段拼装。返回 (prompt, meta) · meta 记录 sandwich hash 与
    card_reads 计数，会写进 diff_report。

    段序：
      段 1  硬约束清单（首）
      段 2  style_lean
      段 3  本页主题 = H1
      段 4  完整源文
      段 5  HDG-Pack（R-V4/R-V5/R-V7/R-V8）
      段 6  硬约束清单（尾）· 与段 1 字字一致
      段 7  B 蓝本追加（可选 · 仅 B_blueprint 时）

    Assert：
      A · sha256(段 1) == sha256(段 6)  —— R9 sandwich 首尾一致
      B · num_card_reads <= hd_max_card_reads  —— v2.2 R-V5 铁闸
    """
    seg1 = build_hard_constraints(h1, body, path_type)
    seg2 = style_lean.rstrip()
    seg3 = "本页主题：" + h1
    seg4 = (
        "以下完整内容须 100% 呈现在图中（一字不删 · 不替换 · 不截断）：\n\n"
        + body
    )
    seg5 = build_hdg_pack(body)
    seg6 = build_hard_constraints(h1, body, path_type)  # 与 seg1 同函数同输入 → 同输出

    # R9 sandwich hash assert
    h1_hash = sha256(seg1)
    h6_hash = sha256(seg6)
    assert h1_hash == h6_hash, (
        f"R9 sandwich hash mismatch — v2.2 FAIL · "
        f"seg1={h1_hash} seg6={h6_hash}"
    )

    prompt = (
        "## 【v2.2 段 1 · 硬约束清单 · 首】\n"
        + seg1
        + "\n\n## 【段 2 · style_overlay_lean】\n"
        + seg2
        + "\n\n## 【段 3 · 本页主题】\n"
        + seg3
        + "\n\n## 【段 4 · 完整源文】\n"
        + seg4
        + "\n\n## 【v2.1 段 5 · HDG-Pack · R-V4/R-V5/R-V7/R-V8】\n"
        + seg5
        + "\n\n## 【v2.2 段 6 · 硬约束清单 · 尾 · 与段 1 字字一致】\n"
        + seg6
    )

    if path_type == "B_blueprint":
        prompt += (
            "\n\n## 【段 7 · 蓝本追加】\n"
            "上传的图片仅用于版式与构图参考，请严格保持其空间布局、区块划分、色带位置。"
            "蓝本上的中/原文字段全部替换为本 prompt 正文，其他视觉元素完全继承。"
        )

    # v2.2 R-V5 铁闸：Card N reads 模式实际使用条数
    card_reads_hits = CARD_READS_RE.findall(prompt)
    num_card_reads = len(card_reads_hits)
    # 注意：本函数生成的 seg5 是"模板骨架"，只写了 "Card 1 title reads: "..."" 与
    # "Card 2 title reads: "..."" 两条示范；agent 侧后续把示范扩展为实际清单时，
    # 必须重新跑本 assert（推荐做法：把展开后的 prompt 回传 build_prompt.py
    # --check-only 校验一次）。这里先给出"当前 prompt 骨架"的计数，防止未来
    # 有 agent 直接把 30 条 Card N reads 塞进骨架里就交付。
    assert num_card_reads <= hd_max_card_reads, (
        f"R-V5 铁闸触发 · v2.2 FAIL · num_card_reads={num_card_reads} > "
        f"threshold={hd_max_card_reads} · 见 references/patch-v2.2.md HDG 误用条款"
    )

    meta = {
        "sandwich_applied": True,
        "sandwich_hash": h1_hash,
        "hdg_pack_applied": True,
        "card_reads_count": num_card_reads,
        "card_reads_threshold": hd_max_card_reads,
        "segments": ["seg1_head", "seg2_style", "seg3_h1", "seg4_body",
                     "seg5_hdg", "seg6_tail"] + (
            ["seg7_blueprint"] if path_type == "B_blueprint" else []
        ),
    }
    return prompt, meta


# ============ end v2.2 新增 ============


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pages-dir", required=True, type=Path)
    ap.add_argument("--style-overlay", required=True, type=Path)
    ap.add_argument("--path-decision", required=True, type=Path)
    ap.add_argument("--out-prompt-dir", required=True, type=Path)
    ap.add_argument("--out-diff", required=True, type=Path)
    ap.add_argument("--hd-max-card-reads", type=int, default=9,
                    help="v2.2 R-V5 铁闸 · Card N reads 模式最大条数 · 默认 9")
    args = ap.parse_args()

    style_lean = args.style_overlay.read_text(encoding="utf-8")
    decisions = json.loads(args.path_decision.read_text(encoding="utf-8"))["decisions"]

    args.out_prompt_dir.mkdir(parents=True, exist_ok=True)
    files_report: list[dict] = []

    for pid, dec in decisions.items():
        src_path = Path(dec["source_file"])
        source = src_path.read_text(encoding="utf-8")
        cleaned, removed = strip_wrappers_and_noise(source)
        h1 = extract_h1(source)

        # v2.2 新增：判定 high_density（select_path.py 已经写好；老 path_decision
        # 缺字段则回退 False）
        is_hd = bool(dec.get("high_density", False))
        hd_signals = dec.get("high_density_signals", [])

        # 拼装
        c_meta: dict = {
            "sandwich_applied": False,
            "hdg_pack_applied": False,
            "card_reads_count": 0,
            "card_reads_threshold": args.hd_max_card_reads,
        }
        if is_hd:
            # C 路径六段拼装（内部已含 R9 + R-V5 铁闸 assert）
            prompt, c_meta = build_high_density_prompt(
                style_lean, h1, cleaned, dec["path_type"],
                args.hd_max_card_reads,
            )
        else:
            # A / B 路径 · v2.0 原文
            prompt = build_three_stage(style_lean, h1, cleaned)
            if dec["path_type"] == "B_blueprint":
                prompt = build_blueprint(prompt)

            # 长度校验（R5 · 仅 A/B 路径 · C 路径因追加 sandwich 不套此 assert）
            expected = len(style_lean) + len(h1) + 80 + len(cleaned)
            drift = abs(len(prompt) - expected) / max(expected, 1)
            if drift > 0.05 and dec["path_type"] == "A_three_stage":
                print(f"[FAIL] {pid}: prompt length drift {drift:.2%} > 5%",
                      file=sys.stderr)
                return 2

        out_file = args.out_prompt_dir / f"{pid}.prompt.md"
        out_file.write_text(prompt, encoding="utf-8")

        files_report.append({
            "page": pid,
            "source_hash": sha256(source),
            "prompt_hash": sha256(prompt),
            "path_type": dec["path_type"],
            # v2.2 新增
            "high_density": is_hd,
            "high_density_signals": hd_signals,
            "sandwich_applied": c_meta["sandwich_applied"],
            "hdg_pack_applied": c_meta["hdg_pack_applied"],
            "card_reads_count": c_meta["card_reads_count"],
            "card_reads_threshold": c_meta["card_reads_threshold"],
            # 保留 v2.0 字段
            "image_size": "4k" if (len(cleaned) > 5000 or is_hd) else "2k",
            "density_risk": (
                "extreme" if len(cleaned) > 15000
                else "high" if len(cleaned) > 5000 or is_hd
                else "medium" if len(cleaned) > 2000
                else "low"
            ),
            "removed_wrapper_blocks": removed,
            "term_replacements": [],
        })
        if len(cleaned) > 15000:
            print(f"[WARN] {pid}: body chars {len(cleaned)} > 15000, "
                  f"consider vector path (see density-router.md)",
                  file=sys.stderr)

    args.out_diff.parent.mkdir(parents=True, exist_ok=True)
    diff = {
        "project": args.out_diff.parent.parent.name,
        "sop_version": "v2.2",  # v2.2 patch bump
        "build_time": datetime.now(timezone.utc).isoformat(),
        "files": files_report,
        "summary": {
            "total_pages": len(files_report),
            "total_truncations": 0,
            "failed_files": 0,
            "silent_transforms": 0,
            "user_overrides": 0,
            # v2.2 新增
            "high_density_pages": sum(1 for f in files_report if f["high_density"]),
            "sandwich_applied_pages": sum(
                1 for f in files_report if f["sandwich_applied"]
            ),
        },
    }
    args.out_diff.write_text(
        json.dumps(diff, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"[OK] built {len(files_report)} prompts · "
          f"HD={diff['summary']['high_density_pages']} · "
          f"diff_report at {args.out_diff}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
