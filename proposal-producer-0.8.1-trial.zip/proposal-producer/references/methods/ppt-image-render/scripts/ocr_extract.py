#!/usr/bin/env python3
"""
ocr_extract.py — v2.2 新增 · 独立 OCR · 不依赖 LLM 理解层

用途：
  - 为 audit_diff.py 层 0 的"vision LLM ⊕ OCR 交叉"提供 OCR 侧输入。
  - 为 R15d "关键字符串锁"提供硬性判据：VERBATIM 字段 OCR 找不到 → FAIL。

工程边界（重要 · 见 references/patch-v2.2.md 反向意见 C）：
  - OCR 只用于两个用途：
      A · 关键字符串锁（R15d · 高置信）· VERBATIM 字段没识别到 = FAIL
      B · 层 0 交叉的"OCR only"字段（辅助信号 · 不作单方判据）
  - OCR 不作"全图文本底盘"：paddleocr / tesseract 在 gpt-image-2 渲染字体上
    识别率约 60-85% · 直接用 "OCR 没识别到 = MISSING" 会产生大量假 FAIL ·
    最后被 agent 忽略、审计层信任崩塌（v1.6 教训重演）。

输入：
  --images-dir      04_output/_staging/ 目录（含 {page}.png）
  --pages-dir       00_source/ （用来从源文提取 verbatim 字段）
  --out             03_render_report/ocr_extracts.json
  --engine          paddleocr | tesseract | easyocr（默认 paddleocr）
  --lang            识别语种 · 默认 'ch,en'

输出 JSON 形态：
  {
    "engine": "paddleocr",
    "lang": "ch,en",
    "pages": {
      "L0_P10": {
        "image": "04_output/_staging/L0_P10.png",
        "ocr_text": "整页拼接的 OCR 结果 · agent 侧可用 · 但不作判据",
        "ocr_lines": ["逐行 OCR 结果", ...],
        "verbatim_hits": {
            "六大总体架构信息流程图": true,
            "节点内 5-8 行子项": false
        },
        "verbatim_miss": ["节点内 5-8 行子项"]
      }
    }
  }

VERBATIM 字段提取规则（源文中被显式锁字的字符串）：
  1. 加粗 **X** 且长度在 [4, 40] 字符
  2. 源文中出现"必须保留：X"、"原文：X"、"底部金句：X"、"锁字：X" 等模式
     后的短语
  3. 独立成段的双引号包裹字符串 "X"

不识别的字段 = 层 0 R15d 视为 FAIL，agent 必须重出。
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path


VERBATIM_BOLD_RE = re.compile(r"\*\*([^*\n]{4,40})\*\*")
VERBATIM_PREFIX_RE = re.compile(
    r"(?:必须保留|原文|底部金句|锁字|VERBATIM|verbatim)\s*[:：]\s*[\"「\"]?([^\n\"」\"]{4,60})[\"」\"]?"
)
VERBATIM_QUOTED_RE = re.compile(r'^\s*[\"“]([^\n\"”]{4,60})[\"”]\s*$', re.MULTILINE)


def page_id_from_path(p: Path) -> str:
    m = re.match(r"^(L\d+_P\d+)", p.stem)
    return m.group(1) if m else p.stem


def source_for_page(pid: str, pages_dir: Path) -> Path | None:
    for suffix in (".md",):
        cand = pages_dir / f"{pid}{suffix}"
        if cand.exists():
            return cand
    return next(pages_dir.glob(f"{pid}_*.md"), None)


def extract_verbatim_fields(source_md: str) -> list[str]:
    """提取所有 VERBATIM 锁字字段 · 去重、保序。"""
    hits: list[str] = []
    for m in VERBATIM_BOLD_RE.finditer(source_md):
        hits.append(m.group(1).strip())
    for m in VERBATIM_PREFIX_RE.finditer(source_md):
        hits.append(m.group(1).strip())
    for m in VERBATIM_QUOTED_RE.finditer(source_md):
        hits.append(m.group(1).strip())
    # 去重保序
    seen: set[str] = set()
    out: list[str] = []
    for h in hits:
        if h and h not in seen:
            seen.add(h)
            out.append(h)
    return out


# ============ OCR 引擎适配层 ============

def ocr_with_paddleocr(img_path: Path, lang: str) -> tuple[str, list[str]]:
    """paddleocr 引擎 · 需 pip install paddleocr paddlepaddle."""
    try:
        from paddleocr import PaddleOCR  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "paddleocr 未安装 · pip install paddleocr paddlepaddle "
            f"(原始 ImportError: {e})"
        )
    # paddleocr 语种映射：'ch' / 'en' / 'ch,en'（多语种 · 取首个作主语种）
    primary_lang = lang.split(",")[0].strip() or "ch"
    ocr = PaddleOCR(use_angle_cls=True, lang=primary_lang, show_log=False)
    result = ocr.ocr(str(img_path), cls=True)
    lines: list[str] = []
    for page in result or []:
        for det in page or []:
            # det = [box, (text, conf)]
            try:
                text = det[1][0]
                if text:
                    lines.append(text)
            except (IndexError, TypeError):
                continue
    return ("\n".join(lines), lines)


def ocr_with_tesseract(img_path: Path, lang: str) -> tuple[str, list[str]]:
    """tesseract 引擎 · fallback · 精度更低。"""
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "pytesseract/Pillow 未安装 · pip install pytesseract pillow "
            f"+ apt-get install tesseract-ocr tesseract-ocr-chi-sim "
            f"(原始 ImportError: {e})"
        )
    # tesseract lang 用 '+' 分隔 · 'chi_sim+eng'
    lang_map = {"ch": "chi_sim", "en": "eng", "chi_sim": "chi_sim", "eng": "eng"}
    parts = [lang_map.get(x.strip(), x.strip()) for x in lang.split(",")]
    tess_lang = "+".join(parts)
    text = pytesseract.image_to_string(Image.open(img_path), lang=tess_lang)
    lines = [l for l in text.splitlines() if l.strip()]
    return (text, lines)


def ocr_with_easyocr(img_path: Path, lang: str) -> tuple[str, list[str]]:
    """easyocr 引擎 · 中英稳定 · 但首次下载模型较慢。"""
    try:
        import easyocr  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "easyocr 未安装 · pip install easyocr "
            f"(原始 ImportError: {e})"
        )
    lang_list = [l.strip() for l in lang.split(",") if l.strip()]
    # easyocr 语种码：'ch_sim' / 'en'
    lang_map = {"ch": "ch_sim", "chi_sim": "ch_sim", "en": "en", "eng": "en"}
    lang_list = [lang_map.get(l, l) for l in lang_list]
    reader = easyocr.Reader(lang_list, gpu=False)
    results = reader.readtext(str(img_path), detail=0)
    return ("\n".join(results), list(results))


ENGINE_DISPATCH = {
    "paddleocr": ocr_with_paddleocr,
    "tesseract": ocr_with_tesseract,
    "easyocr":   ocr_with_easyocr,
}


def normalize_for_match(s: str) -> str:
    """R15d 匹配时的宽松归一：去空格、全半角、大小写。"""
    if not s:
        return ""
    tbl = str.maketrans({
        "，": ",", "。": ".", "：": ":", "；": ";",
        "！": "!", "？": "?", "（": "(", "）": ")",
        " ": "", "\t": "", "\u3000": "",
    })
    return s.translate(tbl).lower()


def match_verbatim(ocr_text: str, verbatim: str) -> bool:
    """
    宽松包含判定：把源字段与 OCR 全文都归一后做 substring 包含。
    OCR 常见丢字（1-2 字符）在编辑距离 ≤ 20% 时也算命中——留一档容错，
    避免因为 OCR 引擎 15% 误差把明明画出来的字段判成 MISSING。
    """
    if not verbatim:
        return True
    o = normalize_for_match(ocr_text)
    v = normalize_for_match(verbatim)
    if v in o:
        return True
    # 容错：长度 ≥ 6 的字段 · 允许 20% 字符缺失
    if len(v) >= 6:
        # 简易滑窗：v 中连续 80% 字符能在 o 中按顺序找到
        need = max(1, int(len(v) * 0.8))
        idx = 0
        matched = 0
        for ch in v:
            j = o.find(ch, idx)
            if j >= 0:
                matched += 1
                idx = j + 1
        return matched >= need
    return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--images-dir", required=True, type=Path)
    ap.add_argument("--pages-dir", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--engine", default="paddleocr",
                    choices=list(ENGINE_DISPATCH.keys()))
    ap.add_argument("--lang", default="ch,en")
    args = ap.parse_args()

    if not args.images_dir.exists():
        print(f"[FAIL] images-dir not found: {args.images_dir}", file=sys.stderr)
        return 2

    engine_fn = ENGINE_DISPATCH[args.engine]
    pages: dict[str, dict] = {}

    for img in sorted(args.images_dir.glob("*.png")):
        pid = page_id_from_path(img)
        try:
            ocr_text, ocr_lines = engine_fn(img, args.lang)
        except Exception as e:
            print(f"[WARN] {pid}: OCR failed · {type(e).__name__}: {e}",
                  file=sys.stderr)
            ocr_text, ocr_lines = "", []

        src = source_for_page(pid, args.pages_dir)
        if src is None:
            print(f"[WARN] {pid}: source not found in {args.pages_dir}",
                  file=sys.stderr)
            verbatim = []
        else:
            verbatim = extract_verbatim_fields(src.read_text(encoding="utf-8"))

        hits: dict[str, bool] = {}
        miss: list[str] = []
        for v in verbatim:
            ok = match_verbatim(ocr_text, v)
            hits[v] = ok
            if not ok:
                miss.append(v)

        pages[pid] = {
            "image": str(img),
            "ocr_text": ocr_text,
            "ocr_lines": ocr_lines,
            "verbatim_fields": verbatim,
            "verbatim_hits": hits,
            "verbatim_miss": miss,
        }
        status = "OK" if not miss else f"MISS×{len(miss)}"
        print(f"[{status}] {pid} · {len(ocr_lines)} lines · "
              f"verbatim {len(verbatim) - len(miss)}/{len(verbatim)}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps({
        "engine": args.engine,
        "lang": args.lang,
        "total_pages": len(pages),
        "pages": pages,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] wrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
