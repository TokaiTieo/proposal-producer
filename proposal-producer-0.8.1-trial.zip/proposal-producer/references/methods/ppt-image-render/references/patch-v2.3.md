# patch-v2.3 · 内容漂移护栏（Content-Drift Guard）· 高密度页模板化塌缩事故补丁

**日期**：2026-09-07
**触发事故**：《工业大模型方案》v2.5.3 批渲 38 页（gpt-image-2 · 16:9 · style_overlay 首段 + 页面正文 + 尾夹），16/38 页出现**内容漂移**——高密度页被渲染成与正文无关的通用"三大底座 × 六大 Agent"模板页：

- P1_04（咨询方法论 · 双引擎五步）→ 渲染成"能源行业 4 段路径 12 场景"（能源版串场）
- P1_08（FDE 四档 TIER1-4）→ 通用"三大底座+6 Agent"页
- P1_09（五服务包+四交付物）→ 通用"三大底座·六大智能体"页
- P2_02/P2_06/P2_09 → 标题对、框架错（六层堆叠/训推底座/最佳实践方法论全被换掉）
- P3_01（工业金字塔 L0-L4）→ "决策/认知/感知"三层（层数错误）
- P3_02/P3_03/P3_04/P3_05/P3_06（五页完全不同的深度页）→ **全部塌缩成同一个"三大底座×六 Agent"模板**
- 对照组：低密度页（六场景页 P3_07-P3_12 · Ov02/03/04/05/06/07）22 页全部忠实

**根因**：gpt-image-2 在"高密度 + 长正文 + 无蓝本"象限下进入语义再压缩模式，把具体业务内容抽象化为训练分布里的"安全模板"。这与 v1.5-v1.6 记录的"Unified Database → Unified Data Lake"意译、Energy_AI P7/P10/P12/P22/P25 爆版是**同一失效家族的新变种**：不是删元素，而是**整页替换为泛化模板**。

---

## 一 · 与既有规则的关系

- 本补丁**不修改** HDG-Pack 四条护栏（R-V4/R-V5/R-V7/R-V8）的任何定义，而是**扩展其触发条件 + 新增第 5 条护栏 R-V9**。
- 触发条件在 §2.3 基础上**追加两条信号**（见下）。
- 与 v2.2 脚本加固兼容：`select_path.py` 的 `high_density` 判定逻辑需同步追加这两条信号（脚本侧由项目自管）。

## 二 · 触发条件追加（在 §2.3 五条信号之外）

6. **正文含"本页完整业务内容（100% 呈现 · 一字不删）"或等义锁字段落**（《工业大模型方案》v2.5 各页标准头部）
7. **正文中出现 ≥ 6 个编号条目 / 卡片标题 / 分区小标题**（任何形式：1. 2. 3. / ① ② ③ / Layer N / Zone N）

## 三 · 新增护栏 R-V9 · 反模板锁内容（Content Lock）

**动机**：本补丁触发事故显示，仅锁"元素数量"（R-V4）和"每行 ≤12 词"（R-V5）不够——模型可以保留元素个数却把**每个元素的内容**替换成模板句。必须把"这页讲什么"钉死。

**拼装规则**：在高密度页尾夹（R9 段 5）中，R-V4 之前加入：

```
【R-V9 · 内容锁 · Content Lock · 优先级最高】

本页的区块结构、卡片标题、分区名称，必须且只能取自本 prompt 正文中
【本页完整业务内容】段落（或正文各 ## 小节）定义的内容，逐字转写上屏。

Render the EXACT sections, card titles, layer names, and item lists
defined in this prompt's body. Every section heading and card title
that appears in the body MUST appear verbatim on the slide.

严禁（T-FAIL 级）：
- 渲染成通用平台总览 / "三大底座 × 六大 Agent" / "平台能力总览" 等本页正文未定义的模板结构
- 用其他项目 / 其他行业（如能源版、政务版）的内容替换本页正文
- 自行合并 / 改名 / 概括正文中的区块（例如把 "TsFile · IoTDB · Timer 三件套" 概括为 "数据底座"）
- 正文有 N 个一级区块，画面必须恰好 N 个 · 每个的标题逐字一致

If the body content cannot fit, apply R-V7 escape valve (shrink font,
never drop or generalize content). If still impossible, mark
CONTENT_FAIL — do NOT silently substitute a generic template.
```

## 四 · 双源冲突消解（style_overlay vs 页面正文）

本次事故同时暴露：style_overlay 首段与页面正文头部都定义标题/副标时，模型随机听一方。规则明确为：

- **内容**（标题文字、副标文字、区块文字）：以**页面正文**为准
- **样式**（位置、字号、颜色、线长、留白、页脚、空白角）：以 **style_overlay** 为准
- style_overlay 中不得再写与正文冲突的**具体文字内容**；正文头部不得再写与 style_overlay 冲突的**几何/颜色参数**

## 五 · 渲染后最低审计（无脚本环境的降级版 R15）

每页出图后至少做一次 vision 抽查，问句必须是开放式："列出本页全部一级区块标题原文"，然后与正文区块清单逐字比对。**禁止**用"是不是有 6 个卡片？"式封闭问句（Anti-Assumption Register 既有禁令）。
