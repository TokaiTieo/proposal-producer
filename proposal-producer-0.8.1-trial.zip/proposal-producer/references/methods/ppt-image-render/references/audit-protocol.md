---
name: audit-protocol
purpose: 三层 QA 协议 · 对齐 Anthropic pptx skill · v2.1 增补层 0 字面转写审计
inherits_from: v1.0 R6 + v1.2 R10 逐项对账 + Anthropic pptx skill 三层 QA + v2.1 R15
last_updated: 2026-08-31
---

# 三层 QA 协议（v2.1 · 升级为 4 层：Literal / Content / File / Visual）

任何一层不过，图留在 `_staging/`，不 promote。

**v2.1 重要变化**：新增 **层 0 · Literal Transcription Audit（字面转写审计）**作为**每页强制前置** · Content QA 之前必须先跑。

---

## 【v2.1 新增】层 0 · Literal Transcription Audit · 字面转写审计

**这是 v2.1 最重要的 QA 加强**。触发条件：**每页都跑**（不管是否 high_density）。

### 为什么必须做这一步

Energy_AI Kazakhstan v2.3 EN 事故的直接原因就是我（agent）在 v2.0 抽检时只做"结构级抽检"（"右竖条在不在？"）· 而没做"字面级转写"（"逐字转写右竖条的三段短词"）· 结果模型只要看到任何 3×3 结构就答 yes · 每个偷改都被幻觉骗过。

**这个反模式 v1.2 SOP §"反模式 #v1.2-003 · 形式校验冒充内容校验" 早已明文警示**：

> "错误现象：出图后只用 understand_images 看「标题对不对、有没有乱码、布局密不密集」·然后判 'validated as correct' 就归档。
> 典型案例：P19 / P20 v0.5 校验结论均为 'validated as correct'，实际丢失大量结构。
> 根因：校验问题没有点名 prompt 中的硬约束条目，模型自然回答得很顺利。
> 修复：按 R10.3 模板逐条对账，每条给出 ✅ / ⚠️ / ❌ + 证据 + 反例证据。"

v2.0 skill 把 R10.3 交给了 audit_diff.py 脚本 · 但**忽略了 agent 侧 Visual QA 层的同类风险** · 于是我这次在 Visual QA 层用了结构级抽检 · 违反 v1.2 反模式 · 但没触发任何 fail 提示。

v2.1 层 0 就是修这个漏。

### 强制协议

**Step L0.1 · 逐层枚举**

对每一张 staging 图 · agent 必须**先列出**这一页所有 semantic layers（业务输入横带 · 卡片矩阵 · 操作平台层 · 三大底座层 · 底部横带 · 左竖条 · 右竖条 · 左下 logo · 底部页脚 等）。

**Step L0.2 · 逐层字面转写**

对每一层 · 用 `gsk understand_images` 问模型：

```
Literally transcribe every text block in the {LAYER-NAME} of this slide.

Rules for you (the vision model):
  - Do NOT summarise.
  - Do NOT paraphrase.
  - Do NOT say "contains X" or "shows Y" — only transcribe the exact
    characters visible on the slide.
  - If a text block is missing, say the literal string "MISSING".
  - If a text block shows different words than what I list below, say
    the literal string "DIFF" and quote what you actually see.

Expected content for {LAYER-NAME} (from source prompt):
  {enumerate source items verbatim, one per line}

Now transcribe what the slide actually shows in {LAYER-NAME}, item by item.
```

**Step L0.3 · 逐层判定**

对每一层逐项给出：

- ✅ 已落地（字面转写与源 prompt 一字不差）
- ⚠️ 部分落地（转写有小差异 · 如大小写 · 空格 · 或轻微措辞变化）
- ❌ 未落地（MISSING 或 DIFF）
- ❌ 幻觉替换（转写出现源 prompt 没有的通用抽象词 · 如 "Zero-Trust" / "Data Localisation" / "Continuous Evolution"）

**Step L0.4 · 判定失败即触发重跑**

- 任一层有 ❌ 项 → 层 0 FAIL · 该页留 `_staging/` · 触发 §4.4 HDG-Pack / §4.5 R9 首尾夹击 / §4.6 分区出图重跑
- 全 ✅ / 少量 ⚠️（≤ 3 处小差异 · 无 ❌）→ 层 0 PASS · 进入层 1（audit_diff.py 脚本）

### 产物

`03_render_report/literal_transcription_audit.json`：

```json
{
  "page": "L1_P07",
  "audit_time": "2026-08-31T10:00:00Z",
  "layers": [
    {
      "layer_name": "top_business_band",
      "expected_items": ["National energy security...", "Industry regulation...", ...],
      "transcribed_items": ["National energy security...", "Industry regulation...", ...],
      "verdicts": ["✅", "✅", ...],
      "layer_verdict": "pass"
    },
    {
      "layer_name": "three_capability_foundations",
      "expected_items": ["高敏安全域", "工具调用治理", "全链路审计"],
      "transcribed_items": ["Zero-Trust and Identity Management", "Data Security and Privacy Protection", "Operation Audit and Compliance Assurance"],
      "verdicts": ["❌ hallucination", "❌ hallucination", "❌ hallucination"],
      "layer_verdict": "fail"
    }
  ],
  "overall_verdict": "fail",
  "next_action": "apply_hdg_pack_and_rerun"
}
```

### 严禁的假审计（v1.2 R10.4 原文照搬 · v2.1 强制到 agent 侧）

- ❌ "validated as correct"
- ❌ "布局符合预期"
- ❌ "标题清晰"
- ❌ 只问"某某在不在" · 模型看到任何 3×3 就答 yes
- ❌ 不引用具体源 prompt 条目编号
- ❌ 不给反例证据（缺什么 / 缺多少 / 在哪缺）
- ❌ 用"整体判断"代替"逐层判定"

任一命中 = 层 0 FAIL · 必须重做审计。

### 审计模式禁忌明单（Anti-Assumption Register）

以下审计问法**永久禁止**（会被幻觉骗过）：

| ❌ 禁止的问法 | ✅ 正确问法 |
|---|---|
| "右竖条是否存在？" | "逐字转写右竖条的三段短词，如果缺任何一段说 MISSING" |
| "是不是 11 个节点？" | "从左到右逐个报出每个节点的编号和标题" |
| "9 家生态伙伴 logo 全吗？" | "从 3×3 网格逐格报出真实厂商名 · 报出实际显示的每个 logo 内文本" |
| "底部金句在吗？" | "转写底部金句横带的完整文字 · 若与 '{原文}' 不同则报 DIFF" |
| "8 项承诺齐吗？" | "从左到右从上到下报出每张承诺卡的完整标题、Engineering 行、Acceptor 行" |
| "整体版面 OK 吗？" | 按 §4.3 版面契约 5 条逐条判定 · 每条给 ✅/⚠️/❌ + 证据 |

---

## 层 1 · Content QA · 字符级对账（v2.0 原文 · 保留 · 层 0 之后跑）

**工具**：`scripts/audit_diff.py`

**输入**：`{page}.png`（出图）+ `{page}.md`（源文）
**动作**：
1. OCR 抽取图上文字（多模型交叉：gemini-3-flash + gpt-4o-vision）
2. 归一化两侧文本（去空格、去大小写、去标点差异）
3. 字符级 diff
4. 计算漏字率 = `len(source_only_chars) / len(source_chars)`

**通过标准**：
- 漏字率 < 5%
- 无术语替换（source 里的术语必须一字不差出现在图里）
- 数字 100% 保留

**产物**：`03_render_report/audit_result.json`
```json
{
  "page": "L0_P03",
  "miss_rate": 0.021,
  "missing_terms": [],
  "term_drift": [],
  "verdict": "pass"
}
```

不过怎么办：
- 漏字率 5%–10% → 单页重出，同 prompt 试 1 次
- 漏字率 > 10% → 停手，检查是否触发密度门（`density-router.md`）
- 术语替换出现 → 检查是否 R4 授权，未授权直接 raise FAIL

**【v2.1 补充】**：层 1 是 OCR 字符级 diff · 主要抓漏字率 · 但对"抽象化替换"（"高敏安全域" → "Zero-Trust and Identity Management"）不敏感（两者字符集完全不同 · miss_rate 会显示 100% · 但如果替换文本本身合理 · OCR 侧可能仍然通过某些字符匹配报低漏字率）。所以层 0（agent 侧字面转写）**必须前置** · 层 1 只是 backup。

---

## 层 2 · File QA · pptx 结构校验（v2.0 新增，v1.x 完全缺失 · 保留不动）

**工具**：`scripts/validate_deck.py`

**检查项**：
| 检查 | 通过标准 |
|---|---|
| 文件能被 python-pptx 打开 | 无异常 |
| 幻灯片宽高 | 12192000 × 6858000 EMU（16:9） |
| 页数 | == `00_source/` 里的 md 文件数 |
| 每页图片 | 铺满整页，无空白框 |
| 图片分辨率 | ≥ 密度路由要求的最低值 |
| 字体嵌入（如有文本框） | 微软雅黑 |
| OOXML schema | 通过 |

**产物**：`03_render_report/validate_result.json`

参考：Anthropic pptx skill 的 `validate.py`（`--original` baseline 思路可用于 B 路径 diff）

---

## 层 3 · Visual QA · 版面契约检查（v2.0 原文 · 保留不动）

由 agent（不是脚本）逐页看图，对照 `references/prompt-assembly.md` 的**版面契约**：

- [ ] 标题在 `(80, 60)` 附近，字号 28pt，`#145849`，左对齐
- [ ] 标题下横线：起点 `(80, ~100)`，终点 `(1840, ~100)`，`#5FD4C0`
- [ ] 图片/图形距画布边 ≥ 48px
- [ ] 正文全部在 `[80, 140]` – `[1840, 1000]` 安全区内
- [ ] 左下有 `01.AI` 纯文字，14pt，`#666666`
- [ ] 无 Logo、无页码、无版权符
- [ ] 展示层无过程性文字（`页面定位` / `本页要让受众明白什么` / `硬约束清单` 等）

任一项不过 → 单页重出，同时检查 style_overlay_lean 是否被漏掉。

---

## staging → images 升级流程（继承 R11 · v2.0 原文 · v2.1 追加层 0 门禁）

**v2.1 门禁顺序**：层 0 PASS → 层 1 PASS → 层 2 PASS → 层 3 PASS → promote。

**v2.1 关键：层 0 FAIL 时不允许进入层 1**（省 OCR 成本 · 也避免 audit_diff 用 OCR 逃过抽象化替换检测）

四层 QA 全过 → `scripts/promote_staging.py` 升级：

```python
# 伪代码
for page in staging_pages:
    if all_four_qa_layers_passed(page):
        move(f"_staging/{page}.png", f"images/{page}.png")
        log_promotion(page, timestamp, qa_summary)
    else:
        log_stay_in_staging(page, failure_reason)
```

产物：`03_render_report/promotion_log.json`

**禁止直接把 `_staging/` 里的图搬到 `images/`** —— 必须走脚本，脚本会写升级日志，用于事后追责。

---

## diff_report.json 字段（继承 v1.0 schema · v2.1 追加 literal_transcription 字段）

`03_render_report/diff_report.json` 的 schema 在 `assets/diff_report.schema.json`。核心字段：

```json
{
  "project": "Energy_AI_Kazakhstan_v2.3",
  "sop_version": "v2.1",
  "build_time": "2026-08-31T10:00:00Z",
  "files": [
    {
      "page": "L1_P07",
      "source_hash": "sha256:...",
      "prompt_hash": "sha256:...",
      "path_type": "A_three_stage",
      "image_size": "4k",
      "high_density": true,
      "hdg_pack_applied": true,
      "sandwich_applied": true,
      "removed_wrapper_blocks": [
        {"block_type": "html_comment", "content_preview": "<!-- ... -->", "line_range": [12, 18]}
      ],
      "term_replacements": [],
      "literal_transcription": {
        "verdict": "pass",
        "layers_checked": 8,
        "layers_pass": 8,
        "layers_fail": 0
      },
      "audit": {"miss_rate": 0.021, "verdict": "pass"},
      "validate": {"verdict": "pass"},
      "visual_qa": {"verdict": "pass", "checked_by": "agent"}
    }
  ],
  "summary": {
    "total_pages": 25,
    "total_truncations": 0,
    "failed_files": 0,
    "silent_transforms": 0,
    "high_density_pages": 5,
    "sandwich_applied_pages": 5,
    "hdg_pack_applied_pages": 5,
    "section_split_pages": 0
  }
}
```

**硬规则**：
- `total_truncations` 必须 == 0
- `silent_transforms` 必须 == 0
- 任一 > 0 → 整个项目 FAIL，不得交付
- **【v2.1 新增】** 任一页 `literal_transcription.verdict` == "fail" → 该页留 staging · 不 promote
- **【v2.1 新增】** `high_density_pages` > 0 但 `hdg_pack_applied_pages` 或 `sandwich_applied_pages` 少于 `high_density_pages` → 整个项目 FAIL（有高密度页但没套护栏）
