---
name: directory-layout
purpose: 项目目录结构规范，4 层产物物理隔离
inherits_from: v1.0 · 00_目录结构规范.md
last_updated: 2026-08-13
---

# 项目目录结构（4+2 层）

每个 PPT 项目起手必建，脚本自动创建（`scripts/init_project.py` 可选）。

```
项目根/
├── 00_source/                      ← 第 1 层：内容真源
│   └── L{level}_P{page}_{topic}.md     · 用户手写 / 只读
│
├── 01_style_overlay/               ← 第 2 层：样式层
│   ├── style_overlay_full.md           · 给人看（完整版）
│   └── style_overlay_lean.md           · 给模型用（≈380 字符精简版）
│                                       · 全项目共用 1 份，不复制到每页
│
├── 02_render_prompt/               ← 第 3 层：最终 render prompt
│   └── L{level}_P{page}.prompt.md      · build_prompt.py 自动生成
│                                       · = style_lean + H1 + 完整源文
│
├── 03_render_report/               ← 第 4 层：审计报告
│   ├── path_decision.json              · select_path.py 输出
│   ├── diff_report.json                · 每页 transform 记录（R6）
│   ├── density_route.json              · 每页密度分流决策
│   ├── audit_result.json               · Content QA 结果
│   ├── validate_result.json            · File QA 结果
│   └── promotion_log.json              · staging → images 升级记录
│
├── 04_output/                      ← 成品
│   ├── images/                         · 已通过 QA 的正式图
│   ├── _staging/                       · 待审图（R11：先落这，QA 通过才 promote）
│   └── deck.pptx                       · 最终 PPT
│
├── 05_blueprints/                  ← v1.8 新增：蓝本参考图（B 路径）
│   └── L{level}_P{page}_zh.png         · 中文/原版视觉锚
│
└── 06_changelog/                   ← v2.0 新增：项目级微调记录
    └── project_overrides.md            · 本项目对主 SOP 的偏离清单
```

## 4 层隔离硬规则

### 第 1 层 (00_source)
- ✅ 只允许用户手写
- ❌ 禁止任何自动化脚本写入
- ❌ 禁止把样式层混入源文件（反例：把 v3.1 视觉规范复制到每页头部）

### 第 2 层 (01_style_overlay)
- ✅ 全项目共用一份 lean 版
- ✅ full 版给人看（不发给模型）
- ❌ 禁止复制到每页 prompt 里（build_prompt.py 拼装时按引用注入即可）
- ❌ 禁止把"给人看的规则"（如 checklist）混进 lean 版

### 第 3 层 (02_render_prompt)
- ✅ 每页一个独立 `.prompt.md` 文件
- ✅ 严格按 `references/prompt-assembly.md` 的公式拼装
- ❌ 禁止提取要点 / 压缩 / 摘要
- ❌ 禁止设 max_chars 截断

### 第 4 层 (03_render_report)
- ✅ 每次跑出图必须产出全部审计文件
- ✅ 字段严格按 `assets/diff_report.schema.json`
- ❌ 跳过任何审计 = 工程失败

## 命名规范

- 源文件：`L{level}_P{page:02d}_{topic-slug}.md`
  - 例：`L0_P03_信息架构.md`
- Prompt 文件：与源文件同名，扩展名 `.prompt.md`
- 图片：`{source-name}_{size}.png`（例：`L0_P03_信息架构_4k.png`）
- 版本化归档：整个项目根目录带日期戳，如 `H国舆情_L0_2026-08-13_v1.2.4/`

## 归档规则（version freeze）

- 每次交付前把整个项目根目录压缩成 `{project}_v{X.Y.Z}_{date}.zip`
- 落 AI Drive `/交付归档/`
- **禁止**在同一目录里覆盖旧版本（这是 v1.2 R11 隔离归档的延伸）

## 反模式

| 反模式 | 为什么禁止 |
|---|---|
| 样式层注入到源文件头部 | 47 份文件 × 4884 字符 = 22.9 万字符冗余 |
| 混存源文件 + render 文件 | 失去可 diff 性 |
| 跳过 02_render_prompt 直接出图 | 中间产物缺失，失败无法定位 |
| 跳过 03_render_report | 无法证明是否发生 silent transform |
| 覆盖 04_output/_staging/ 旧图 | 违反 R11，失去回滚基线 |
| 手工建目录不用脚本 | 目录名/层级易漂移，跨项目不一致 |
