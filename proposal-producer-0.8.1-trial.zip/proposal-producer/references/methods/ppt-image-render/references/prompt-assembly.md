---
name: prompt-assembly
purpose: render_prompt 拼装规则 · 三段式 + 蓝本路径 + 版面契约 · v2.1 追加 HDG-Pack 与 R9 首尾夹击
inherits_from: v1.0 · 02_render_prompt_拼装规则.md + v1.7 三段式 + v1.8 双链路 + v2.1 补丁
last_updated: 2026-08-31
---

# Render Prompt 拼装规则（v2.1）

本 skill 允许的 prompt 结构：**三段式（A 路径）** 或 **蓝本路径（B 路径）**。**v2.1 高密度页在此之上追加 HDG-Pack + 首尾夹击**。任何其他"创新"结构都要走 `regression-guard.md` 提案。

---

## A · 三段式（默认 · v2.0 保留不动）

### 公式
```
render_prompt
  = [style_overlay_lean]                          （~380 字符，assets/style_overlay.md 精简版）
  + "\n\n本页主题：" + <源文 H1>
  + "\n\n以下完整内容须 100% 呈现在图中（一字不删 · 不替换 · 不截断）：\n\n"
  + [源文完整正文]                                （00_source/*.md，一字不动）
```

### 长度校验
```
expected = len(style_lean) + len(H1) + 80 + len(source_body)
assert abs(len(prompt) - expected) / expected < 0.05, "prompt 长度异常，疑似 silent transform"
```

偏差 > 5% → raise FAIL，不允许"我先看看再决定要不要报告"。

---

## B · 蓝本路径（v1.8 新增 · v2.0 保留不动）

### 何时用
- `05_blueprints/L{...}_zh.png` 存在
- 或用户明确要求"按这张图重绘/翻译/改文案不改版式"
- `select_path.py` 输出 `B_blueprint`

### 公式（在三段式基础上追加）
```
prompt = <A 三段式 prompt>
       + "\n\n参考图（蓝本）说明：\n"
       + "上传的图片仅用于版式与构图参考，请严格保持其空间布局、区块划分、色带位置。\n"
       + "蓝本上的中文（或原语）字段全部替换为本 prompt 正文，其他视觉元素完全继承。\n"

调用参数：
{
  "model": "nano-banana-pro",       # 编辑场景保真度最高
  "query": prompt,
  "image_urls": ["05_blueprints/L{...}_zh.png"],
  "aspect_ratio": "16:9",            # v1.8：不允许 auto
  "image_size": "4k"                 # B 路径固定 4k
}
```

### 蓝本图路径的硬规则
1. 蓝本图必须是**原版最终交付版本**（不是过程稿），像素 ≥ 1920×1080
2. 蓝本图上不允许有"审阅批注"、"红框"、"版本水印"
3. 一页对应一张蓝本，不允许一图多页共用
4. 蓝本换了 → 必须重新出图（不允许"版式没变就复用旧图"）

---

## 【v2.1 新增】C · 高密度页护栏组合（HDG-Pack + R9 首尾夹击）

**触发条件**：`select_path.py` 输出 `high_density: true`（见 SKILL.md §2.3）。

**结构**（在 A 或 B 基础上追加首尾夹击）：

```
render_prompt =

  ┌──【v2.1 段 1 · 硬约束清单 · 首段】─────────────────────┐
  │  ① 蓝本图为事实标准（若走 B 链路）                    │
  │  ② 每层每子项文字必须原样渲染，禁止意译                │
  │  ③ 元素计数：exactly N cards / N nodes / N layers    │
  │  ④ 底部金句原文：{原文照抄}                           │
  │  ⑤ 字号可降到 7pt · 但严禁删词                         │
  │  ⑥ 自检要求：字面转写审计（每层逐字对账）              │
  └────────────────────────────────────────────────────────┘

  ┌──【段 2 · style_overlay_lean · A 三段式头】─────────────┐
  │  {380 字符全局视觉规范}                                │
  └────────────────────────────────────────────────────────┘

  ┌──【段 3 · 本页主题 · A 三段式中】────────────────────────┐
  │  {源文 H1}                                              │
  └────────────────────────────────────────────────────────┘

  ┌──【段 4 · 完整源文 · A 三段式尾】────────────────────────┐
  │  {源文完整正文 · 一字不动}                              │
  └────────────────────────────────────────────────────────┘

  ┌──【v2.1 段 5 · HDG-Pack · R-V4/R-V5/R-V7/R-V8】────────┐
  │  R-V4 · 元素计数（逐层写 exactly N）                    │
  │  R-V5 · 结构化列表（"Card N reads: {原文}"）             │
  │  R-V7 · 字号逃生阀（缩到 7pt · OVERFLOW_FAIL 而不删词） │
  │  R-V8 · 底部横带二次锁字（原文再抄一遍）                 │
  └────────────────────────────────────────────────────────┘

  ┌──【v2.1 段 6 · 硬约束清单 · 尾段 · 与段 1 字字一致】────┐
  │  ① - ⑥ · 与段 1 完全相同                                │
  └────────────────────────────────────────────────────────┘

  ┌──【段 7 · B 蓝本说明】（可选 · 走 B 路径时追加）──────────┐
  │  上传的图片仅用于版式与构图参考...                       │
  └────────────────────────────────────────────────────────┘
```

### 首尾字字一致校验

`scripts/build_prompt.py` v2.1 版本在拼装完后 assert：

```python
assert sha256(段1) == sha256(段6), "R9 sandwich front-tail hash mismatch — v2.1 FAIL"
```

不一致直接 raise FAIL。

### 明确不做的

- **HDG-Pack 只在 `high_density: true` 时启用**。一般页面不启用，避免 v1.6 密度爆炸复发
- HDG-Pack 只复活 R-V4/R-V5/R-V7/R-V8 · 不复活 R-V1/R-V2/R-V3/R-V6（永久作废 · 见 `deprecated.md`）
- HDG-Pack 是**补位**不是**替代** · 三段式 + 蓝本路径 + audit_diff 依然是主线

详见 `high-density-guardrails.md`。

---

## 版面契约（v2.0 · 必须嵌入 style_overlay_lean · 保留不动）

以下 5 条**必须一起进 style_overlay_lean**，缺一条会导致版面漂移。绝对像素基于 1920×1080 画布。

### 1. 标题定位
- 位置：`(x=80, y=60)` 左上锚点
- 字体：微软雅黑 Bold，28pt，`#145849`
- 对齐：左对齐（**禁止居中**，R14.1）
- 双语：中文标题第一行 → 英文副标题第二行，都从 `x=80` 起

### 2. 标题下横线
- 起点 `(80, y_title_bottom + 12)`，终点 `(1840, 同 y)`
- 线宽 1px，颜色 `#5FD4C0`
- 全项目所有页同一位置（视觉指纹的核心）

### 3. 图片/图形留白
- 距画布上下左右 ≥ 48px
- 图与图横向间距 ≥ 32px，纵向 ≥ 24px

### 4. 正文安全区
- 写作区：`x ∈ [80, 1840]`, `y ∈ [140, 1000]`
- 有效画布 1760 × 860
- 任何字符不允许溢出

### 5. 页脚（继承 R14.2）
- 左下 `(x=80, y=1040)` 起：纯文字 `01.AI`，14pt，`#666666`
- 无 Logo、无页码、无版权符

---

## 明确禁止的动作（继承 v1.0 · 保留不动）

| 禁止 | 反例 | 后果 |
|---|---|---|
| 提取要点作"核心内容" | `extract_core_content()` | 段落级删除 |
| 设 max_chars 截断 | `max_chars=3800` | 高密度页砍半 |
| 摘要化 | "用一句话概括" | 数字/术语丢失 |
| Silent 术语替换 | `RAISE → 可问责AI` | 用户不知情 |
| 删"看起来像噪声" | 删 markdown 注释块 | 可能误删正文 |
| 改写句式 | 口语化→工程化 | 改变用户原意 |
| 合并空行 | 相邻空行合并 | 打乱版面节奏 |
| 调整标题层级 | H2→H1 | 打乱结构 |
| 重排列表 | 换顺序 | 改变强调点 |
| 表格转列表 | table→bulleted | 丢失关系 |

---

## 允许的动作（必须记入 diff_report.json · 保留不动）

### 1. 移除工程包装层
- `<!-- ==== -->` 注释块
- `📍 框架定位` 等元数据块
- v1.4 展示层清洗清单（`页面定位` / `本质是什么` / `硬约束清单` / `段1–段5` 等）

必须记入 `diff_report.json.removed_wrapper_blocks: [...]`

### 2. 术语替换（仅授权时）
必须记入 `diff_report.json.term_replacements: [{from, to, reason}]`

---

## Python 参考实现（v2.1 增补 · 伪代码）

```python
def build_render_prompt(page_name: str, path_type: str, is_high_density: bool = False) -> dict:
    source = read_text(f"00_source/{page_name}.md")
    style_lean = read_text("01_style_overlay/style_overlay_lean.md")
    h1 = extract_first_h1(source)
    display_body = strip_display_noise(source)   # v1.4 展示层清洗（可审计）

    # A 三段式（v2.0 原文）
    prompt_a = (
        style_lean
        + "\n\n本页主题：" + h1
        + "\n\n以下完整内容须 100% 呈现在图中"
          "（一字不删 · 不替换 · 不截断）：\n\n"
        + display_body
    )

    # 长度校验
    expected = len(style_lean) + len(h1) + 80 + len(display_body)
    assert abs(len(prompt_a) - expected) / expected < 0.05

    # v2.1: 高密度页追加首尾夹击 + HDG-Pack
    if is_high_density:
        hard_constraints = build_hard_constraints_list(source, h1)  # 首尾一致的清单
        hdg_pack = build_hdg_pack(source)  # R-V4/R-V5/R-V7/R-V8
        prompt = (
            "## 【v2.1 段 1 · 硬约束清单 · 首段】\n" + hard_constraints
            + "\n\n" + prompt_a
            + "\n\n## 【v2.1 段 5 · HDG-Pack · R-V4/R-V5/R-V7/R-V8】\n" + hdg_pack
            + "\n\n## 【v2.1 段 6 · 硬约束清单 · 尾段 · 与段 1 字字一致】\n" + hard_constraints
        )
        # 首尾一致性 assert
        assert hashlib.sha256(hard_constraints.encode()).hexdigest() == \
               hashlib.sha256(hard_constraints.encode()).hexdigest(), "R9 sandwich mismatch"
    else:
        prompt = prompt_a

    # B 路径追加蓝本说明
    args = {
        "query": prompt,
        "aspect_ratio": "16:9",
        "image_size": "4k" if len(source) > 5000 or is_structured(page_name) or is_high_density else "2k",
    }

    if path_type == "B_blueprint":
        args["model"] = "nano-banana-pro"
        args["image_urls"] = [f"05_blueprints/{page_name}_zh.png"]
        args["image_size"] = "4k"
        args["query"] += "\n\n参考图（蓝本）说明：..."
    else:
        args["model"] = "gpt-image-2"

    return args
```

---

## 自检 checklist（v2.1 更新）

拼装完每一页后：

- [ ] `02_render_prompt/{page}.prompt.md` 存在
- [ ] 长度 ≈ 预期公式，偏差 < 5%
- [ ] style_overlay_lean 在首段（或在 v2.1 段 2）
- [ ] "本页主题：..." 在中段
- [ ] 完整源文在尾段，一字未改
- [ ] 若走 B 路径，尾部有蓝本说明段
- [ ] diff_report.json 记录了所有 wrapper 移除
- [ ] 抽 3 页人工 diff 确认
- [ ] **【v2.1】** 若 `high_density: true` · 首段 + 尾段硬约束清单已插入 · 首尾字字一致
- [ ] **【v2.1】** 若 `high_density: true` · HDG-Pack 4 条护栏已插入尾段之前
- [ ] **【v2.1】** diff_report.json `high_density` / `hdg_pack_applied` / `sandwich_applied` 字段已填

---

## R7 参数（v2.0 → v2.1 变化）

原 v2.0：`min_effective_chars_per_page = 400`（少于此值触发"稀薄页"警告）

**v2.1 变化**：
- 一般页面：仍 `min_effective_chars_per_page = 400` · 警告不 FAIL
- **高密度页**：R7 恢复强规则 · 每节点子项 ≥ 5 行 · 每行 ≥ 8 字完整语义 · 违反 FAIL
- 见 `constraints.md` R7 更新
