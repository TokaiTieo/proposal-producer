---
name: patch-v2.2
version: 2.2
purpose: v2.1 → v2.2 增量补丁 · 只补脚本层 · SKILL.md 主体不动
---

# v2.2 Patch · 脚本层加固

## 定位

v2.1 文档层清楚要求"高密度页 = HDG-Pack + 首尾夹击 + 4 层审计"，但脚本层没落到位：`select_path.py` 不判 `high_density`、`build_prompt.py` 无 C 路径、`audit_diff.py` 只 1 层。这就是"文档说一套 · 脚本做一套"的事故源头。

v2.2 只补脚本 · 不动 v2.1 文档语义 · 观察期 2 周后再决定是否 v3.0 全量重写。

## 5 条改动（P0）

**1 · `scripts/select_path.py`** — 按 §2.3 五条自动判 `high_density`：`HD-1` 5000-15000 字符 · `HD-2` node≥8 · `HD-3` card≥25 · `HD-4` layer≥5 · `HD-5` 锁字或主题词。输出 `path_decision.json` 每页带 `high_density` + `signals`；额外输出 `high_density_flags.json`。

**2 · `scripts/build_prompt.py`** — 加 C 路径六段拼装（段1 硬约束首 · 段2 style · 段3 H1 · 段4 源文 · 段5 HDG-Pack · 段6 硬约束尾）。两条 assert：`sha256(段1) == sha256(段6)`（R9 sandwich）· `num_card_reads <= 9`（R-V5 铁闸，超 9 条自动退化为无 quote-lock 编号列表，防 v1.6 R-V2 复活）。HDG-Pack 只出骨架，元素计数与底部横带原文由 agent 侧读源文填入（脚本不做语义抽取 · 否则违反 R6）。

**3 · `scripts/audit_diff.py`** — 升级为 4 层：
- 层 0 · literal-transcription（R15）· vision LLM ⊕ OCR 交叉 · `miss_both` = FAIL（R15d 关键字符串锁）· `llm_only / ocr_only` = WARN
- 层 1 · 字符级 diff · v2.0 原逻辑
- 层 2.5 · 分辨率一致性 · 读 png header 检测退化 1024×1024（gpt-image-2 auto 陷阱）
- 层 3 · 版面契约五条（`--layout-json` · agent 侧输入 · 可选）

**4 · 新增 `scripts/ocr_extract.py`** — paddleocr / tesseract / easyocr 三选一。**只用于**：R15d 关键字符串锁（VERBATIM 硬命中）+ 层 0 OCR 侧输入。**不作**"全图文本底盘"—— OCR 在 gpt-image-2 渲染字体上识别率 60-85%，把"OCR 漏识"当"字段缺失"会造假 FAIL 导致信任崩塌（v1.6 教训重演）。

**5 · `assets/diff_report.schema.json`** — 补 `literal_transcription` 字段（`ocr_only` / `llm_only` / `miss_both` 三个数组）。

## 已收敛的反向意见

- **A · 双 vision 交叉不可行** — gpt-image-2 无 vision 端；gsk understand_images 是同一后端。R15b 落地为 vision LLM ⊕ OCR
- **B · OCR 不当底盘** — 识别率不够，只作 R15d 硬命中 + 层 0 辅助
- **C · git 递归保护押后** — AI Drive 无 `.git`，reguard_trigger 需换 sha256 或 sb-git，等 v3.0
- **D · persona_layer / hdg-on-ramp / SKILL.md 瘦身押后** — 与 A/B/C 路径关系未定义前不落地
- **E · density-router auto 陷阱** — v2.2 通过层 2.5 分辨率校验兜底；文档补注等 v3.0

## 观察期指标（2 周）

每个新项目跑完填 `06_changelog/patch_v2.2_observation.md`：
- `high_density` 判定准确率（人工复核 vs 脚本）
- R9 sandwich assert 触发数
- R-V5 铁闸触发数（>9 条被退化）
- 层 0 `miss_both` FAIL 数、`llm_only / ocr_only` WARN 数
- 层 2.5 分辨率退化拦截数（预期 > 0 才证明 auto 陷阱真存在）
- 2 周内 1 次事故复现 → 触发 v1.7 回归保护三步（`regression-guard.md`）

## 明确押后到 v3.0

- SKILL.md 瘦身到 ≤ 8KB
- `references/hdg-on-ramp.md`（HD 快速入口）
- `references/persona_layer.md`（与 A/B/C 嵌套关系需先定义）
- `scripts/reguard_trigger.py`（存储路径待定）
- `references/density-router.md` auto 陷阱段
- `scripts/four_layer_audit.py`（audit_diff.py 已是入口 · 不重复）

## 回滚

`_legacy/v2.1-original/` 快照 · 覆盖 3 个脚本 + schema 即可 10 分钟回滚。SKILL.md 只在 §9 加一行 patch 引用 · 卸掉即恢复完整 v2.1。
