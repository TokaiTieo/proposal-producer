---
name: density-router
purpose: 按字符密度和结构复杂度决定出图分辨率、模型选择、是否停手
inherits_from: v1.0 · 04_出图路由 + v1.1 二档收敛
last_updated: 2026-08-13
---

# 密度路由（Density Router）

## 主表

| 正文字符 | 是否强结构页 | 分辨率 | 模型（A 路径） | 模型（B 路径） | 备注 |
|---|---|---|---|---|---|
| ≤ 5,000 | 否 | 2k | gpt-image-2 | nano-banana-pro | 常规页 |
| ≤ 5,000 | **是** | 4k | gpt-image-2 | nano-banana-pro | 强制升档 |
| 5,000 – 15,000 | — | 4k | gpt-image-2 | nano-banana-pro | 高密度页 |
| \> 15,000 | — | ❌ 停 | — | — | 走矢量路径，本 skill 不覆盖 |

## 字符数口径

- 统计对象：源文件 markdown 纯文本
- **含**：中文、英文、标点
- **不含**：frontmatter、`<!-- -->` 注释块、样式层引用

Python 实现：
```python
def count_body_chars(source_md: str) -> int:
    text = strip_frontmatter(source_md)
    text = strip_html_comments(text)
    text = strip_style_overlay_refs(text)
    return len(text)
```

## 强结构页判定

只要源文出现以下任一关键词或结构，即视为强结构页：

- 显式结构声明：`区域 A`、`区域 B`、`保持原版`、`100% 继承`、`蓝本`
- 多时序流：波形图、时间轴、三流并列
- 流程/拓扑/架构图：节点+连线密集
- 多区块硬约束：A/B/C/D/E 五区结构
- 附图 100% 复刻要求

## 为什么 5k 是切分点

1. **中文密字页 1k 必糊**：微软雅黑 12pt 以下在 1k 下笔画粘连（这就是 v1.0 三档在 v1.1 被砍到二档的直接原因）
2. **5k 是"一页 PPT 高密度"的经验阈值**：注释/来源/卡片副标题在此密度下开始变小
3. **> 5k 必出现 ≤14px 小字号块**：需要 4k 才能锐利

## 为什么 15k 是硬停点

- 图像模型不是排版引擎
- 4k 输出下 15k 中文字符 = 每字符约 500 px² → 已到清晰度极限
- 25k 字符实测漏字率 > 15%（P26 v1.x 教训）
- 触发此阈值 → agent 必须停手，上报用户，给出选项：
  - 拆图（拆分成 2–3 页）
  - 降密度（业务方精简源文）
  - 改路径（python-pptx 矢量排版）
  - 接受风险（记录到 diff_report `density_risk: extreme`）

## 反模式

- ❌ 用 1k 出中文密字页
- ❌ ≤ 3000 字用 1k（v1.0 旧规则，已作废）
- ❌ 5K–8K 用 2k（v1.0 旧规则，已作废）
- ❌ 强结构页只看字符数
- ❌ > 15K 硬塞图像模型不提醒用户

## 上下游衔接

- 上游：`R5 不得截断`——密度路由不允许"降密度=删字符"
- 下游：`audit-protocol.md`——路由决策必须记入 `03_render_report/density_route.json`
- 审计：`audit_diff.py` 校验 image_size 匹配路由决策

## 版本
- v1.1 · 2026-06-12 · 二档收敛
- v2.0 · 2026-08-13 · 新增 15k 硬停点、B 路径模型选择列
