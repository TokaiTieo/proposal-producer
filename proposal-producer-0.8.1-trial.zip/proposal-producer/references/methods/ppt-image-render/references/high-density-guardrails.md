---
name: high-density-guardrails
purpose: v2.1 新增分册 · 高密度页护栏包（HDG-Pack）· R-V4/R-V5/R-V7/R-V8 受控局部复活规格
inherits_from: v1.6 R-V1–R-V8（部分复活） + v2.0 deprecated.md（部分沿用） + Energy_AI v2.3 EN 事故档案
last_updated: 2026-08-31
---

# 高密度页护栏包 · High-Density Guardrails Pack (HDG-Pack)

## 一、本分册的定位

**这份分册处理一个具体问题**：`gpt-image-2` 4K 单页面对 30+ 元素 / 6+ 分层 / 具体术语密集页时的意译 / 抽象化 / 元素折叠 / 底部横带幻觉替换现象。

**历史脉络**：

- **v1.5**（2026-07-30）：出现"gpt-image-2 把 Unified Database 意译成 Unified Data Lake" · 首次记录
- **v1.6**（2026-07-30 15:07）：为解决上条 · 引入 R-V1 ~ R-V8 共 8 条 prompt 层护栏
- **v1.7**（未确定日期 · 早于 2026-08-13）：v1.6 被判"密度爆炸 40% + 模型补偿性重写 + 审计成本翻倍"三重问题 · 全部作废 · 押注三段式 + 蓝本路径 + audit_diff.py
- **v2.0**（2026-08-13）：把 v1.7 判决写进 skill 骨架 · `references/deprecated.md` 立墓碑
- **Energy_AI v2.3 EN 事故**（2026-08-28 至 2026-08-31）：从头出图 EN 侧 · 蓝本图路径 B 不可用（没有 CN 对应蓝本）· audit_diff.py 未运行 · 结果 5 页高密度页全部爆版 · 现象与 v1.5 → v1.6 触发案例完全一致
- **v2.1**（2026-08-31 · 本分册）：**证据显示 v1.7 押注的两条替代路径（B 蓝本 + audit_diff）在特定场景下均不可用** · 需要 prompt 层护栏作补位 · 但不允许全盘复活 v1.6 · 只受控复活 R-V4/R-V5/R-V7/R-V8 · 保留 v1.7 对 R-V1/R-V2/R-V3/R-V6 的作废判决

**为什么这么做**：v1.7 → v2.0 的判决在**低-中密度页** 是对的（避免密度爆炸）· 但在**高密度页 + 从头出图 + 无蓝本**这个特定象限失效。补丁的正确方向是**按触发条件启用**，而不是全体启用或全体作废。

---

## 二、触发条件（严格 · 一般页面不启用）

页面必须先被 §2.3（SKILL.md）判定 `high_density: true`，才允许套 HDG-Pack。判定条件（满足其一）：

1. 主流程节点数 ≥ 8（P10 类信息流程图）
2. 子模块 / 卡片 / 图标数 ≥ 25（P7/P12 类多层架构图）
3. 分层横向 / 纵向切分 ≥ 5 层（P12 类六层架构图）
4. 出现锁字关键词：`必须保留`、`不可删除`、`100% 呈现`、`一字不删`、`蓝本图为事实标准`、`节点内 5-8 行子项`
5. 页面主题包含："架构图"、"总体架构"、"信息流程"、"承诺列表"、"报价明细"、"数据链路"、"技术底座"

**记录**：触发标志落 `03_render_report/high_density_flags.json`。

---

## 三、HDG-Pack 4 条护栏详细规格

### R-V4 · 元素计数强制（HDG 必选项 1）

**动机**：Energy_AI v2.3 EN P12 底部三层（操作平台 · 三大底座 · 跨网接入底盘）在 4K 下被模型直接折叠成一根深绿窄条。此现象在 v1.6 补丁背景原文即已警示："prompt 里只写 'nine agents' 不含逃生阀时，模型密度爆时会删元素"。

**拼装规则**：

对每一层同类重复元素明写：
```
Render exactly {N} {element-type}, arranged as a {layout} grid.
If any of the {N} elements does not fit at the recommended layout,
apply the escape valve (see R-V7); the count of {N} elements MUST remain exactly {N}.
```

**填空示例**（Energy_AI P12 六层）：

```
Layer 1 (top business band): Render exactly 6 white sub-modules, arranged as a horizontal flat row of equal-width cells.
Layer 2 (ecosystem zone): Render exactly 9 Agent cards (3×3 grid) AND exactly 9 vendor logos (3×3 grid).
Layer 3 (national platform band): Render exactly 1 gold-teal horizontal band.
Layer 4 (Operations Platform card): Render exactly 4 white sub-modules inside the deep-green card.
Layer 5 (Three Foundations): Render exactly 3 deep-green cards side-by-side, each containing exactly 3 white sub-modules.
Layer 6 (bottom access underlay): Render exactly 6 white sub-modules inside the teal-cyan band, plus 1 red caption line.

TOTAL elements to render: 6 + 9 + 9 + 1 + 4 + 3×3 + 6 + 1 = 45 elements. Each layer's element count MUST be exactly as specified above.
```

**反例**（绝对禁止）：
- ❌ "6 sub-modules" · 无逃生阀 · 密度爆时被删
- ❌ "several / multiple / around N" · 模糊数量
- ❌ 不写数量 · 只写"list of sub-modules"

### R-V5 · 结构化列表 + 每行 ≤ 12 词（HDG 必选项 2）

**动机**：Energy_AI v2.3 EN P25 8 承诺被抽象化替换（"Data does not leave the borders" → "Data Localisation"）· 此现象在 v1.6 补丁原文即已警示："散文式长清单在元素数 ≥ 30 时进入语义再压缩模式，开始自主重命名"。

**拼装规则**：

对每一层的具体条目 · 用编号列表 · 每行 ≤ 12 词：

**反模式**：
```
❌ The nine agents include Multilingual Regulation Retrieval and Basis Generation,
   Oil & Gas Risk Forecasting, Heating-Season Supply Assurance, ...
```

**正模式**：
```
✅ Render exactly 9 agent cards as a 3×3 grid, in order left-to-right top-to-bottom:
   Card 1 title reads: "Multilingual Regulation Retrieval and Basis Generation"
   Card 2 title reads: "Oil & Gas Risk Prediction and Pre-Warning"
   Card 3 title reads: "Heating-Season Supply Assurance and Power Load Risk"
   Card 4 title reads: "Energy Permit and Document Intelligent Pre-Review"
   Card 5 title reads: "ESG and Carbon Emission Regulation"
   Card 6 title reads: "Public Service and Enterprise-Affairs Assistant"
   Card 7 title reads: "Investment-Project Progress and Risk Management"
   Card 8 title reads: "Industrial Safety Digital Inspector"
   Card 9 title reads: "Executive Command and Daily Briefing"
```

**关键要素**：
- 每条独立一行
- 每行 ≤ 12 词（避免长句触发语义再压缩）
- 用 `Card N title reads: "..."` 显式指定"这一格显示这句话"
- 双引号包裹目标字面串

**注意 · 与作废的 R-V2 的边界**：

v1.6 R-V2 全篇给所有短语双引号 quote-lock · v1.7 判决"混合标签让模型对整段 prompt 语义解析出错" · 永久作废。

v2.1 R-V5 复活只在**高密度页 · 且只在"元素编号列表"这一处**用双引号 · 不给整个 prompt 每个短语都加引号 · 避免 v1.6 密度爆炸复发。

### R-V7 · 字号逃生阀 · 明示不允许删词（HDG 必选项 3）

**动机**：Energy_AI v2.3 EN P10 节点内 5-8 行子项全丢 · 只留图标 · 因为模型密度爆时找不到"不删词的降级路径" · 于是直接删词。此现象在 v1.5 补丁"禁压缩文案"和 v1.6 补丁 R-V7 都已明确警示。

**拼装规则**：

在高密度页 prompt 结尾 · 显式给模型一条"字号可降 · 词不可删"的降级路径：

```
【字号逃生阀 · Font Escape Valve】

If any text does not fit at the recommended font size, apply the following
in order (each step MUST be attempted before the next):

  (a) reduce font size in 1pt steps down to 7pt minimum
  (b) tighten line-height to 1.05 minimum
  (c) reduce card inner padding
  (d) elongate card vertically (grow downward, not shrink text)
  (e) split the section into two rows

Under no acceptable condition remove, paraphrase, abstract, or shorten any word.
If none of (a)-(e) succeeds, mark this page as OVERFLOW_FAIL — do NOT silently
drop content. The count of items in each layer MUST remain exactly the number
specified in R-V4.
```

**为什么"OVERFLOW_FAIL"是关键**：模型在无路可退时会默认选择"删词"作最后手段 · R-V7 明确切断这条路 · 让模型选择"报错而不是删词" · 这条错就会在字面转写审计（R15）中暴露。

### R-V8 · 底部横带 · 二次锁字（HDG 必选项 4）

**动机**：Energy_AI v2.3 EN P7 底部金句被幻觉替换成 "Key Conclusion: Build 1 Platform..." · P22 底部金句丢失 · P25 底部金色横带被幻觉替换 · 三处不同底部横带均出问题。此现象在 v1.6 补丁 R-V8 原文警示："底部金句条极易被 gpt-image-2 替换成无关合规文本"。

**拼装规则**：

在 prompt 结尾 · 把底部横带原文再重复一遍：

```
【底部横带二次锁字 · Bottom-Bar Verbatim Lock】

Final render check: the bottom horizontal bar (deep-teal #145849, full page width,
height ~5% of canvas) contains EXACTLY ONE line of text reading verbatim:

    "{ORIGINAL BOTTOM BAR TEXT · CHARACTER-BY-CHARACTER FROM SOURCE}"

This bar contains:
  - no summary
  - no substitute sentence like "Key Conclusion: ..."
  - no generic phrasing like "Build 1 Platform · Strengthen 3 Foundations"
  - no additional lines below or above

If the recommended font at the standard bar height does not fit,
apply R-V7 escape valve. Do NOT rewrite the sentence.
```

**填空示例**（Energy_AI P7）：

```
Final render check: the bottom horizontal bar contains EXACTLY ONE line of text
reading verbatim:

    "Energy AI Kazakhstan = Kazakhstan sovereign-cloud backstop
     + Six-layer main-flow penetration
     + Kazakhstan legal-compliance pass-through
     + Unified intelligent capability serving the Ministry of Energy /
       Samruk-Kazyna / the five core pillars."
```

**触发范围**：不只底部金句 · 任何以下形式的横带都套用 R-V8：
- 底部金句横带（`#145849` 深绿底 · 白字）
- 承诺横带（P25 类型 · 黑底 · 金色描边）
- KPI 横带（M3/M9/M10+ 三节点）
- 金色总结横带（P25 底部）
- 顶部治理总线（P10 类）
- 底部资源供给总线（P10 类）

---

## 四、HDG-Pack 组合装配位置

在 SKILL.md §4.5 R9 首尾夹击的**尾段（段 5）**里 · 依次编号列出这 4 条护栏。示例：

```
【v2.1 HDG-Pack · 高密度页护栏 · R-V4/R-V5/R-V7/R-V8】

高密度页硬约束清单（首尾夹击 · 尾段 · 与首段字字一致）：

① R-V4 · 元素计数：
   Layer 1 = 6 sub-modules · Layer 2 = 9 Agent + 9 logo · Layer 3 = 1 band
   Layer 4 = 4 sub-modules · Layer 5 = 3 cards × 3 sub-modules = 9
   Layer 6 = 6 sub-modules + 1 caption
   TOTAL = 45 elements · MUST render exactly this count

② R-V5 · 结构化列表 + 每行 ≤ 12 词：
   Agent Card 1-9 titles as verbatim quoted list (see body above)
   Vendor Card 1-9 names as verbatim quoted list (see body above)

③ R-V7 · 字号逃生阀（缩到 7pt · 不删词 · OVERFLOW_FAIL）
   （原文照抄 §三 R-V7）

④ R-V8 · 底部横带二次锁字：
   "{原文一字不改}"
```

---

## 五、HDG-Pack 不做什么（明确边界）

以下**不属于**HDG-Pack · 请勿混淆：

1. **R-V1（`<text>` 标签包裹）· 永久作废** —— v1.7 判决 "混合标签让模型对整段 prompt 语义解析出错"
2. **R-V2（全篇 quote-lock 双引号）· 永久作废** —— v1.7 判决 "过度锁字触发模型补偿性重写"
3. **R-V3（全正向表述 · 禁 do NOT）· 永久作废** —— 实测 do NOT 在负向约束场景仍必要（如禁 Key Conclusion 幻觉横条）· v1.7 全面禁 do NOT 反而消灭了必要的负向锁字
4. **R-V6（空间锚"上/中/下"位置词）· 永久作废** —— v2.0 R14 版面契约用**绝对像素**代替了空间锚 · 已过时

**HDG-Pack 只复活 R-V4/R-V5/R-V7/R-V8 这 4 条**。任何试图恢复其余 4 条的动作 · 走 `regression-guard.md` 三步治理。

---

## 六、HDG-Pack 效果验证 · A/B 样本

**触发案例样本**（v2.1 打补丁前 · 未应用 HDG-Pack）：

| 页 | v2.0 三段式实测结果 | 应用 R-V 哪条能救 |
|---|---|---|
| P7 · 三大底座 6 子模块 | 被抽象化替换（"Zero-Trust and Identity Management"）| R-V4 元素计数 + R-V5 结构化列表 |
| P10 · 11 节点子项 | 全丢 · 只剩图标 | R-V5 编号列表每行 ≤ 12 词 + R-V7 字号逃生阀 |
| P10 · 8 治理动作词 | 红虚线还在 · 文字丢失 | R-V8 底部横带二次锁字（治理总线同类）|
| P12 · 下半页三层 | 整层折叠成一根深绿窄条 | R-V4 元素计数 + R-V7 字号逃生阀 |
| P22 · Gantt 条内 | 空条 · 阶段内容没进条内 | R-V5 编号列表 |
| P22 · 底部金句 | 缺失 | R-V8 底部横带二次锁字 |
| P25 · 4 主权卡业务点 | 被抽象化（"Build local energy AI talent"）| R-V4 + R-V5 |
| P25 · 底部金色横带 | 幻觉替换成 "Eight Engineering Pledges..." | R-V8 底部横带二次锁字 |

**6 处 8 类** 全部命中 R-V4/R-V5/R-V7/R-V8 · 无一命中已作废的 R-V1/R-V2/R-V3/R-V6 · 证明 v2.1 的部分复活策略正确。

---

## 七、加载纪律

- SKILL.md §4.4 提示"细节见 high-density-guardrails.md"时 · agent 必须**打开本文件全读一遍** · 不允许跳过
- 高密度页的 `02_render_prompt/{page}.prompt.md` 尾部**必须**包含 HDG-Pack 4 条完整规格 · 缺任一条 = 拼装 FAIL · build_prompt.py v2.1 版本会自动 assert 校验

---

**End of high-density-guardrails.md · v2.1 · 2026-08-31**
