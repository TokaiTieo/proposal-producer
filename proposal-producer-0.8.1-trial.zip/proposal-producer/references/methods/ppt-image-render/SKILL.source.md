---
name: ppt-image-render
version: 2.4.1
description: |
  Image-generated PPT engineering skill. Each slide is rendered as ONE full 16:9 image via gpt-image-2 (or nano-banana-pro for edits), then packed into a .pptx via python-pptx. Use this skill for L0/L1 executive decks where visual quality > editability, and where every character in the source markdown must appear on the slide (no silent transform).
  DO NOT use for: (a) decks that must remain fully editable in PowerPoint (use frontend-slides / native pptxgenjs instead); (b) pages exceeding ~15,000 characters of body text (image models drop characters; escalate to python-pptx vector path); (c) simple mechanical .pptx edits on an existing file (use python-pptx directly, not this skill).
authors: [工程视角协作者 + AI 协作者]
last_verified: 2026-08-31
supersedes: /_SOP_PPT工程链路_v1.0/*  (8 patches v1.0→v1.8) + skill v2.0 (2026-08-13)
license_note: internal-use
---

# PPT · Image-Rendered Deck Skill (v2.1)

> **入口原则**：本文件是唯一入口，agent / 人 只需要读这一份。所有细节按需 JiT (just-in-time) 读 `references/*.md`，动作层按需调 `scripts/*.py`。
>
> **v2.1 相对 v2.0 的变化（2026-08-31 · Energy_AI Kazakhstan v2.3 EN 出图事故驱动的补丁）**：
> 1. **§4.4 高密度页护栏包**：定位为 v1.6 R-V4/R-V5/R-V7/R-V8 的**受控局部复活**（不复活 R-V1/R-V2/R-V3/R-V6 · 那 4 条是过度锁字主犯）。触发条件严格限定，避免 v1.6 的密度爆炸复发
> 2. **§4.5 硬约束首尾夹击（R9 复活）**：v2.0 把 v1.2 R9 隐性降级为"三段式天然是 sandwich"，实测证据显示三段式（style+H1+源文）**不是**R9 意义上的硬约束首尾夹击，故复活
> 3. **§4.6 分区出图（Section Split）**：新增高密度页兜底机制，元素数 > 25 或分层数 ≥ 6 层的页面允许拆上/下半页分别出图后 python-pptx 拼合
> 4. **§5.1 A 路径高密度页模型评估**：新增 "gpt-image-2 4K 高密度页 · 建议同时用 nano-banana-pro 出对照版" 的双模型 A/B 建议（不强制）
> 5. **§6.4 强制字面转写审计（Literal-Transcription Audit）**：QA 层 1 前置一道 agent 侧审计，问"逐字转写每层每子项文字"而不是"某某在不在"。这次 Energy P7/P10/P12/P22/P25 全部因为跳过这一步而 pass 了 v2.0 的结构级抽检
> 6. **§7 强制规则表更新**：R7 / R9 从 ⚠️降级 改为 ✅有效（部分触发）；新增 R15 强制字面转写审计 + R16 分区出图兜底
> 7. **references/high-density-guardrails.md 新增分册**：v2.1 高密度页护栏详细规格
> 8. **references/deprecated.md 增补 v2.0 教训**：登记 v2.0 → v2.1 事故档案，防止未来 agent 再重蹈覆辙
> 9. **v2.0 全部内容完整保留** —— v2.1 是 v2.0 的严格超集，没有一行 v2.0 内容被删除或简化
>
> **v2.0 相对 v1.0-v1.8 的核心变化**（v2.0 原文 · 保留不动）：
> 1. 8 份补丁流水账 → 一份主入口 + 7 份分册 + 5 个脚本
> 2. 版面一致性契约（标题 / 留白 / 分隔线）从"隐式默契"→ 显式规则 + 脚本自检
> 3. v1.6 R-V1–R-V8 显式作废（见 `references/deprecated.md`）
> 4. 补 File QA 层（`scripts/validate_deck.py`），对齐 Anthropic pptx skill 的三层 QA
> 5. 双链路选路从"藏在补丁里的判断"→ `scripts/select_path.py` 卡口

---

## 0 · 什么时候用这份 skill · 什么时候不用

| 情况 | 用不用 | 备注 |
|---|---|---|
| L0 / L1 高层汇报 PPT，视觉一致 > 可编辑 | ✅ 用 | 主战场 |
| 每页需要精确复刻蓝本图（如中文原版→英文重绘） | ✅ 用（蓝本路径） | 见 §3 双链路 |
| 用户要求"整包 markdown 一字不漏上屏" | ✅ 用 | 见 R1–R6 |
| 用户需要在 PPT 里现场编辑文本 | ❌ 别用 | 让 slides agent 走原生 pptxgenjs 路径 |
| 页面正文 > 15,000 字符 | ❌ 别用 | 图像模型必漏字，走 python-pptx 矢量 |
| 只是把一张已有 .pptx 里的第 3 页文字改一下 | ❌ 别用 | 直接 python-pptx 编辑，别再走全套 |
| Word 文档 / Excel 报表 / 纯 HTML slides | ❌ 别用 | 完全不对口 |

---

## 1 · 5 步主流程（背下来）

```
Step 1 · 场景识别 + 路径选路 → scripts/select_path.py
Step 2 · 目录初始化                → 4 层物理隔离（见 references/directory-layout.md）
Step 3 · 拼装 render prompt        → scripts/build_prompt.py（三段式 或 蓝本路径）
                                     · v2.1：高密度页额外套 §4.4 护栏包 + §4.5 首尾夹击
Step 4 · 分辨率路由 + 出图         → 2k / 4k · gpt-image-2 · 每页 → _staging/
                                     · v2.1：高密度页可选双模型 A/B 或分区出图（§4.6）
Step 5 · 三层 QA → 归档 → 打包     → literal-transcription audit + audit_diff.py
                                     + validate_deck.py + promote_staging.py
```

每一步的**准入条件**和**产物形式**在下面的 §2–§6，细节展开在 `references/`。

---

## 2 · Step 1：场景识别 + 路径选路

### 2.1 判断走哪条链路

**双链路（v1.8 沉淀）**：

| 链路 | 触发条件 | 输入 | 输出 |
|---|---|---|---|
| **A · 三段式** | 无中文/蓝本参考图 | 源 markdown + 全局 style_overlay | render_prompt 文本 → gpt-image-2 出图 |
| **B · 蓝本图路径** | 已有 4K 中文/原版图作为视觉锚 | 源 markdown + 蓝本 PNG + style_overlay | render_prompt + `image_urls: [蓝本]` → gpt-image-2 翻译重绘 |

**选路脚本**：`python scripts/select_path.py --pages-dir 00_source/ --blueprints-dir 05_blueprints/`
→ 输出 `03_render_report/path_decision.json`，形如：
```json
{"P01": "A_three_stage", "P02": "B_blueprint", "P03": "A_three_stage", ...}
```

**手动决策不允许**——脚本判定为 B 却手工走 A（或反之）= 违反 v1.8。

### 2.2 复杂度识别（可选自检）

- 页面正文字符数 ≤ 5,000 且非"强结构页" → 2k 出图
- 5,000 < 正文 ≤ 15,000 或强结构页（多区块 / 多时序流 / 附图 100% 复刻）→ 4k
- \> 15,000 → **停手**，走矢量路径（本 skill 不覆盖）

规则细节见 `references/density-router.md`（原 04_出图路由）。

### 2.3 【v2.1 新增】高密度页额外识别

即便 body-chars 落在 5,000 – 15,000 4K 档，如果同时满足下列**任一**"高密度信号"，必须在 `path_decision.json` 标 `high_density: true`，触发 §4.4 护栏包 + §4.5 首尾夹击 + §6.4 强制字面转写审计：

- 主流程节点数 ≥ 8（P10 类信息流程图）
- 子模块 / 卡片 / 图标数 ≥ 25（P7/P12 类多层架构图）
- 分层横向 / 纵向切分 ≥ 5 层（P12 类六层架构图）
- 出现"锁字关键词"：`必须保留`、`不可删除`、`100% 呈现`、`一字不删`、`蓝本图为事实标准`、`节点内 5-8 行子项`
- 页面主题包含："架构图"、"总体架构"、"信息流程"、"承诺列表"、"报价明细"、"数据链路"、"技术底座"

**触发标志留档**：`03_render_report/high_density_flags.json`。

---

## 3 · Step 2：目录结构初始化

每个项目起手必须建这套目录（v1.0 的 4 层产物物理隔离，v2.0 补 2 层）：

```
项目根/
├── 00_source/              ← 用户源 markdown（只读，任何脚本不得写入）
├── 01_style_overlay/       ← 全局视觉规范（本 skill 内置一版 assets/style_overlay.md）
├── 02_render_prompt/       ← build_prompt.py 输出，每页一个 .prompt.md
├── 03_render_report/       ← 审计层：diff_report.json / density_route.json / path_decision.json
├── 04_output/
│   ├── images/             ← 单页 PNG
│   ├── _staging/           ← v1.2 R11：待审图先落这里，通过 audit_diff 才 promote
│   └── deck.pptx           ← 最终成品
├── 05_blueprints/          ← v1.8：蓝本参考图（走 B 路径时）
└── 06_changelog/           ← 本项目 SOP 微调记录（区别于 skill 主线 CHANGELOG）
```

**4 层隔离硬规则**（v1.0 沉淀，不可绕过）：
- 00_source 只允许人手工写，脚本一律不动
- 01_style_overlay 全项目共用一份，不复制到每页
- 02_render_prompt 每页独立文件，不合并
- 03_render_report 缺失 = 工程失败，禁止交付

详见 `references/directory-layout.md`。

---

## 4 · Step 3：Prompt 拼装（本 skill 最核心的一环）

### 4.1 三段式（A 链路 · 默认）

```
render_prompt =
    [style_overlay_精简版]      (~380 字符, 来自 assets/style_overlay.md)
  + "\n\n本页主题："              + 源文 H1
  + "\n\n以下完整内容须 100% 呈现在图中（一字不删 · 不替换 · 不截断）：\n\n"
  + [源文完整正文]              (来自 00_source/*.md，一字不动)
```

**长度校验**：拼装完后 `abs(len - expected) / expected < 5%`，否则 raise FAIL。

### 4.2 蓝本路径（B 链路）

三段式基础上追加：
```
image_urls: ["05_blueprints/P##_zh.png"]
aspect_ratio: "16:9"        (v1.8：不允许 auto，防止输出 1024×1024)
```

Prompt 尾部追加一句："以上蓝本仅作为版式与构图参考，文字内容以本 prompt 的完整正文为准，蓝本上的中文字段全部替换为本 prompt 的英文/中文正文。"

### 4.3 版面一致性契约（关键）

**这一节直接对应视觉一致性问题**。所有 prompt 拼装时，`style_overlay` 段落必须包含以下**版面锚点**，image model 才会稳定输出：

**① 标题一致性**
- Line-1 主标题（中文）：位置 (x=80, y=60) · 28pt Bold · 颜色 `#145849` 深青绿 · 左对齐 · 微软雅黑 / Noto Sans SC · 行高 1.2
- Line-2 中文子标题：位置 (x=80, y=95) · 14pt Regular · 颜色 `#5A6E68` 灰绿 · 左对齐 · 一行 ≤ 30 字 · **禁止英文混排** · **禁止中英双语并列**
- 禁止：居中、右对齐、跨两行折行、字号浮动、多个中文标题堆叠、英文短句副标行
- 标题区黑名单：页码/编号（P01/Part N 等）、版本号（v2.x）、括号包裹的过程性说明、prompt 元注释（如 `(No GPT)`）

**② 标题下方装饰金分隔线**
- 从 (80, 115) 到 (280, 115) · **固定长度 200px** · 线宽 1px · 颜色 `#C8A24A` 装饰金
- 距标题底部约 12px
- 全项目所有页**同位置、同长度、同颜色**（一致性契约 · 每页强制保留）

**③ 图片/图形留白**
- 页面内所有图片、图形、卡片区块的**最小外边距**：距画布上下左右都 ≥ 60px
- 图与图之间横向间距 ≥ 32px，纵向 ≥ 24px
- 图片必须完整可见，不允许"贴到画布边缘"

**④ 正文安全区**
- 正文写作区域：`x=80 ~ x=1840`（左右各留 80px），`y=150 ~ y=940`（顶部让给主标+子标+装饰金线三行；底部让给金句横带与 01.AI 页脚）
- 底部金句横带（如有）：`y=980 ~ y=1020` · 深青绿背景 · 白字加粗 16-18pt · 内容照抄源文一句
- 正文任何字符不允许出现在安全区外

**⑤ 页脚与空白角**
- 左下角仅纯文字 `01.AI`，14pt，`#666666`，位置 (80, 1040)；无图形 Logo、无页码、无版权符；禁止 hashtag / URL / QR
- **右上角完全空白** · **右下角完全空白**：不允许任何装饰元素、徽标、印章、二维码

**⑥ 命名硬约束（上屏文字级 · 每页无例外）**
- 平台层唯一写法：**工业 AI 操作平台**（禁：工业智能体统一入口 / 统一 AI 助手 / 国家 Energy AI 操作系统 / 工业智能 AI 平台）
- 组织主体：**零一万物**（中）/ **01.AI**（英/角标）（禁：01 万物 / 北京 01 万物 / 01AI）
- 通用大模型三家：**DeepSeek · Kimi · 千问**（禁：GPT / OpenAI / 添加任何第 4 家）
- Agent 数量：**exactly 6**（禁：9 / 6-12 弹性）

**⑥.5 字体族硬锁（v2.4.1 新增 · style_overlay 首行必现 · 每页无例外）**

**动机**：v2.4 之前 §4.3 ① 只锁死了中文字体族（Noto Sans SC / 微软雅黑），**未锁死数字和英文的字体族**。gpt-image-2 在不指定字体族时会在宋体 / 黑体 / 圆体 / 卡通体之间自由漂——即使原生分辨率下每个字符像素充足，混排本身也会"看着糊"（跨页字重、字距、抗锯齿曲线不一致 → 视觉指纹漂移）。中文糊已现（原生 1672×941 上 12pt 中文约 10px 高，见 §5.2 物理下限），数字次之，英文最抗压但也非免疫——一旦字号被 R-V7 逃生阀压到 8-9pt，英文同样会糊。

**硬锁规范**（style_overlay 精简版首行 MUST 包含）：

```
Fonts (hard-locked, all pages):
- Chinese text: Noto Sans SC or Microsoft YaHei; NEVER 宋体 / 圆体 / 卡通体 / 手写体
- Digits & English: Inter (fallback: IBM Plex Sans); NEVER Times / Comic Sans / serif
- Code / monospace: JetBrains Mono or Consolas (only inside code blocks)
- Font-weight lock: titles 700 (Bold); body 400 (Regular); notes 300 (Light)
- Anti-aliasing: subpixel on all text; NEVER pixelated / bitmap-style
```

**反模式**（AP 追加）：
- ❌ style_overlay 只指定"微软雅黑"不指定英文/数字字体族 → 模型在 Helvetica / Times / Arial / 未知无衬线间随机切
- ❌ 让模型"自选合适字体" → 高密度页会切成 8-9pt 手写风 · 一定糊
- ❌ 中英混排段落只写中文字体族 → 英文段位继承宋体等衬线体 · 数字尤其难看

**⑦ 色板锚点**
- primary `#145849` · gold `#C8A24A` · note `#5A6E68` · stroke `#E9D8A6` · alert `#D46A2C`（仅限告警语义）· background `#FCFAF6` · body 深灰绿 `#2E3A36`（**严禁纯黑 #000000**）
- 禁色：蓝 / 紫 / 粉 / 霓虹 / 卡通风（暖橙 `#D46A2C` 为唯一告警色）

**这七条一起构成"视觉指纹"**，必须整体嵌入 style_overlay 精简版（见 `assets/style_overlay.md`）。任何一条被删都会导致跨页版面漂移——这是 v1.4 之前反复踩坑的地方，用绝对像素锁死。

拼装规则细节见 `references/prompt-assembly.md`。

**【v2.3 补充 · 内容漂移护栏】**：高密度页 / 正文含"100% 呈现"锁字段 / 正文 ≥6 个编号条目页，除本节样式契约外，必须追加 `references/patch-v2.3.md` 的 **R-V9 内容锁 + R-V7 字号逃生阀** 尾夹——内容以页面正文为准（逐字转写），样式以本节/style_overlay 为准；严禁把具体业务页塌缩成通用模板页（"三大底座 × 六大 Agent"类）。触发条件与 R-V9 全文见 `references/patch-v2.3.md`。

### 4.4 【v2.1 新增】高密度页护栏包（HDG-Pack · v1.6 R-V4/R-V5/R-V7/R-V8 受控复活）

**只在 §2.3 判定 `high_density: true` 的页面触发。** 一般页面**不**启用，避免 v1.6 密度爆炸复发。

**为什么复活这 4 条 · 为什么不复活其余 4 条**：

Energy_AI Kazakhstan v2.3 EN 出图事故（2026-08-28 至 2026-08-31）实证如下：v2.0 的三段式 + 4K 在高密度页（P7/P10/P12/P22/P25）下依然会出现具体子项被抽象化替换、下半页整层折叠、底部金句被幻觉替换、Gantt 条内空等现象。这些现象**恰好对应 v1.6 补丁 R-V4/R-V5/R-V7/R-V8 的初始设计目标**。故在此**局部复活**这 4 条，保留 v1.7 作废 R-V1/R-V2/R-V3/R-V6 的判断（那 4 条是过度锁字主犯 · 见 deprecated.md）。

- **R-V4 · 元素计数强制**（HDG-Pack 必选项 1）
  - 对同类重复元素（Agent 卡、Node、Layer）必须写"exactly N cards / nodes / layers"
  - 每处元素计数**必须配一句字号逃生阀**："if text overflows, shrink font in 1pt steps down to 7pt, tighten line-height to 1.05; the count of {N} elements must remain exactly {N}"
  - 反例（v1.6 已封杀）：只写"9 agents"（模型密度爆时会删元素）

- **R-V5 · 结构化列表 + 每行 ≤ 12 词**（HDG-Pack 必选项 2）
  - Agent 名、Node 名、Layer 名、Pledge 名等**必须**用编号列表 + 每行 ≤ 12 词
  - 反模式（v1.6 已封杀）：散文式"The nine agents include A, B, C, and D..."
  - 正模式：
    ```
    Render exactly 9 agent cards as a 3×3 grid, in order left-to-right top-to-bottom:
    Card 1 title reads: "Multilingual Regulation Retrieval & Basis Generation"
    Card 2 title reads: "Oil & Gas Risk Prediction and Pre-Warning"
    ...
    ```

- **R-V7 · 字号逃生阀 · 明示不允许删词**（HDG-Pack 必选项 3）
  - 在高密度页 prompt 结尾添加：
    ```
    If any text does not fit at the recommended font size, apply the following in order:
    (a) reduce font size in 1pt steps down to 7pt minimum;
    (b) tighten line-height to 1.05 minimum;
    (c) reduce card inner padding;
    (d) elongate card vertically;
    (e) split the section into two rows.
    Under no acceptable condition remove, paraphrase, or abstract any word from the source content.
    ```

- **R-V8 · 底部横带 · 二次锁字**（HDG-Pack 必选项 4）
  - 底部金句 / 底部横带 / 承诺横带 / KPI 横带 等极易被 gpt-image-2 幻觉替换
  - **必须在 prompt 结尾再重复一遍原文**：
    ```
    Final render check: the bottom horizontal bar (deep-teal #145849, full width, ~5% page height)
    contains exactly one line of text reading verbatim:
    "{原文}"
    This bar contains no other text, no summary, no substitute sentence.
    ```

**HDG-Pack 拼装位置**：追加在三段式 prompt 尾部（B 链路则追加在蓝本说明之后），单独段落，标题固定为 `## 【v2.1 HDG-Pack · 高密度页护栏 · R-V4/R-V5/R-V7/R-V8】`。

**明确不复活的**：R-V1（`<text>` 标签包裹）· R-V2（quote-lock 双引号）· R-V3（全正向表述）· R-V6（空间锚"上/中/下"位置词）。理由：这 4 条是 v1.6 补丁密度爆炸和模型补偿性重写的主犯 · 保留作废（详见 `references/deprecated.md`）。

**详细规格**：见 `references/high-density-guardrails.md`（v2.1 新增分册）。

### 4.5 【v2.1 新增】硬约束首尾夹击（R9 复活）

**v2.0 隐性把 v1.2 R9 归到"三段式天然是 sandwich"**（`references/constraints.md` 原文）。**实测证据显示这句话不成立**：三段式（style_lean + H1 + 完整源文）在 R9 意义上**不是**硬约束首尾夹击 · 完整源文尾部没有硬约束浓缩清单 · 图像模型对 prompt 中段注意力低导致的失忆问题依然存在。

**v2.1 R9 复活规则**：

**触发条件**（满足其一）：
1. `high_density: true`（见 §2.3）
2. Prompt 总长度 ≥ 8,000 字符
3. 出现锁字关键词（`必须保留`、`不可删除`、`100% 呈现` 等，同 v1.2 R9.1）

**拼装结构**（在三段式基础上追加首尾清单）：

```
┌──────────────────────────────────────────────┐
│ 段 1 · 硬约束清单 · 首段（v2.1 R9 复活）      │  ← 追加
│   ① 蓝本图为事实标准（若走 B 链路）           │
│   ② 每层每子项文字必须原样渲染，禁止意译       │
│   ③ 元素计数：exactly N cards / N nodes 等   │
│   ④ 底部金句原文（照抄进清单）                │
│   ⑤ 自检要求：字面转写审计（§6.4）            │
├──────────────────────────────────────────────┤
│ 段 2 · style_overlay 精简版（原三段式 头）    │
├──────────────────────────────────────────────┤
│ 段 3 · 本页主题（原三段式 中）                 │
├──────────────────────────────────────────────┤
│ 段 4 · 完整源文（原三段式 尾）                 │
├──────────────────────────────────────────────┤
│ 段 5 · 硬约束清单 · 尾段（与段 1 字字一致）   │  ← 追加
└──────────────────────────────────────────────┘
```

**首尾字字一致校验**：`scripts/build_prompt.py` v2.1 版本增加 `sandwich_check(front, tail) == True` 断言，不一致 raise FAIL。

**为什么"字字一致"是关键**：v1.2 R9 明确要求"首尾两份必须字字一致，便于 diff 校验"。任何"顺手改一下更通顺"的行为都会破坏 diff 能力。

### 4.6 【v2.1 新增】分区出图（Section Split · 兜底机制）

**触发条件**（`high_density: true` 且以下任一）：
- 分层横向切分 ≥ 6 层（超过 gpt-image-2 4K 单页信息容量）
- 主流程节点数 ≥ 12（P10 类超密流程图）
- 元素总数 > 40（子模块 + 图标 + logo + 卡片）

**流程**：
1. 把源文按"结构自然缝"切分成上/下两半（或左/右）
2. 每半单独走一次 4.4 + 4.5 拼装 · 分别出图落 `_staging/{page}_top.png` / `{page}_bottom.png`
3. 每半单独跑 §6.4 字面转写审计
4. 通过后用 python-pptx 拼合：一张空白 slide · 上下各贴一张图（或左右）· 拼合位置按结构缝对齐 · 最终 `04_output/images/{page}.png` 是 python-pptx 生成的合成图（而不是模型一次出的）

**归档**：`03_render_report/section_split_log.json` 记录切分点和拼合位置。

**为什么不默认启用分区出图**：切分会引入拼合缝 · 视觉不如一次出图统一 · 只有一次出图确实爆版时才作兜底。**分区出图是最后一道防线，不是首选**。

---

## 5 · Step 4：出图 · 分辨率路由

| 正文字符 | 分辨率 | 模型 | 备注 |
|---|---|---|---|
| ≤ 5,000 且非强结构页 | 2k | gpt-image-2 | 走 A 路径不带参考图 |
| 5,000 < ~ ≤ 15,000 或强结构页 | 4k | gpt-image-2 | B 路径必 4k |
| > 15,000 | ❌ 停 | — | 不走本 skill |

**执行**（伪代码，实际调 image_generation 工具）：
```python
for page in pages_to_render:
    prompt = read(f"02_render_prompt/{page}.prompt.md")
    size = "4k" if page.chars > 5000 or page.is_structured else "2k"
    args = {"query": prompt, "aspect_ratio": "16:9", "image_size": size}
    if path_decision[page] == "B_blueprint":
        args["image_urls"] = [f"05_blueprints/{page}_zh.png"]
        args["model"] = "nano-banana-pro"   # 编辑场景保真度更高
    else:
        args["model"] = "gpt-image-2"       # 文字渲染更稳
    img = image_generation(**args)
    save(img, f"04_output/_staging/{page}.png")   # 先落 staging
```

**staging 隔离**（继承 v1.2 R11）：出图先落 `_staging/`，通过 QA 才 promote 到 `images/`。这样返工时可以定位到"哪一版失败"，而不是覆盖旧图。

### 5.1 【v2.1 新增】A 路径高密度页 · 双模型 A/B 建议（不强制）

**背景**：v1.6 补丁的产生案例就是 gpt-image-2 4K 在 30+ 元素页面意译（原文见 SOP_v1.5_to_v1.6 §背景）。v2.0 作废 v1.6 但没升级 A 路径的默认模型 · Energy_AI v2.3 EN 事故复现同一现象。

**v2.1 建议（不强制）**：`high_density: true` 且 A 路径的页面 · 可以同时用 `gpt-image-2` 和 `nano-banana-pro` 各出一版 · 由 agent 侧字面转写审计（§6.4）挑更好的作 promote 版本。落 `_staging/{page}_gpt.png` + `_staging/{page}_nb.png`。

**why 不强制**：双模型出图翻一倍成本 · 且 `nano-banana-pro` 在纯文本渲染上不一定强于 `gpt-image-2`（后者是官方 flagship for text）。此建议是"用户 opt-in"路径。

### 5.2 · 【C 方案锐化】渲后清晰度处理（gpt-image-2 4K 默认后处理）· 2026-09-08 加入

**背景**：`gpt-image-2` 原生最大分辨率 1672×941 · Lanczos 3× 放大到 5016×2823 后文字边缘轻微模糊 · 密度高的页（1+3+N 架构 / 五层生态 / 六层技术栈 / 服务目录）尤其明显。**C 方案 = Lanczos 3× + PIL UnsharpMask** · 2026-09-08 在 v2.9_slim P1-P10 实测 · 文字锐度显著提升 · 无 ringing 伪影 · 单页成本 +2s。

**触发方式**（agent 侧识别，任一命中即执行）：
- 用户任何自然语句里出现"**锐化**"两个字 + `C 方案 / UnsharpMask / 更清晰 / 出锐化版 / 渲完锐化`任一信号词
- 用户命名"**C 方案**"或"**清晰度提升**"
- 默认策略：**A 路径 gpt-image-2 4K 出图 · 全部默认走 C 方案后处理**（除非用户明说"不锐化"或"要原图"）

**参数（gpt-image-2 → Lanczos 3× 5016×2823 专用参数 · 不要用于其他模型）**：
```python
from PIL import Image, ImageFilter
img = Image.open(raw_png)                        # gpt-image-2 原生 1672×941
w, h = img.size
up = img.resize((w*3, h*3), Image.LANCZOS)       # → 5016×2823
sharp = up.filter(ImageFilter.UnsharpMask(
    radius=1.5, percent=180, threshold=2))       # 文字边缘强化
sharp.save(f'_sharp/{page}_4k_sharp.png', 'PNG')
```

**输出目录约定**：`<version>/_sharp/<page>_4k_sharp.png` · 与原 4K 版并存（不覆盖）· AI Drive 同结构落地。

**硬约束（禁止踩的坑）**：
1. **不要对同一张图 C 方案跑两次** · UnsharpMask 是不可逆边缘增强 · 二次锐化必然出现白色描边 ringing 伪影
2. **不要用于非 gpt-image-2 模型** · `nano-banana-2` / `Seedream Pro` 原生分辨率更高 · 这套参数会过锐 · 若需锐化改用 `radius=1.0, percent=120, threshold=1`
3. **锐化不能救"缺内容"** · 主标丢失 / sandwich 失效 / checklist 大面积漏项这类问题必须重渲修 prompt · 任何后处理无解
4. **不要放弃保留原 4K 未锐化版** · 用户可能要对比 · 或要在下游再叠 AI 超分（Real-ESRGAN / swin2sr）

**why 只锐化不 AI 超分**：本 sandbox 无 GPU · Real-ESRGAN CPU 单张 5-15 分钟 · 10 张即 1-2h · 且原图不清的小字 AI 超分也补不回来（只是内插）。真要 AI 超分请手动走 Genspark AI Image 的官方 upscaler。

**审计对话锚点**（用户 2026-09-08 15:49 明确要求把此口令固化进 skill · 不新增版本号 · 在当前最新版本上加）。

---

### 5.3 · 【v2.4.1 新增】清晰度物理下限说明 · 为什么锐化不是永恒解

**动机**：2026-09-08 17:00 与另一 agent 的复盘对账（详见本节末对话锚点）。那位 agent 声称 v2.9_slim 的 3840×2160 输出是 `image_size='4k'` 参数带来的"native 4K 出图" · 并把这个当成"文字清晰"的第一因子。经工程视角研判**推翻**：gpt-image-2 原生最大 1672×941 是模型硬约束，任何看似 3840×2160 的输出要么来自 Lanczos 3× 后处理（本 skill §5.2 C 方案，可控），要么来自 gsk 平台/脚本侧的隐式 upscale（多为 bilinear，反而更烂——是"糊 4K"）。**不能把参数当成机制** · 也**不能指望后处理无限救场**。

**字符可读像素下限（Nyquist–Shannon 采样定理意义）**：

| 语种 | 平均笔画数 | 最小可读像素 | 为什么这个下限 |
|---|---|---|---|
| 中文 | 15-20 | ≥ 12×12 px | 每笔至少 2px 采样 · 少于此值抗锯齿糊成一团 |
| 数字 | 3-6 | ≥ 8×8 px | 0/6/8/9 内部有环形 · 需要 2px 分辨环内环外 |
| 英文（小写）| 2-4 | ≥ 6×6 px | i / j / l 只需一根竖笔 · 但 a / e / o 有内环 |
| 英文（大写）| 3-5 | ≥ 7×7 px | 相当于 x-height 6px + ascender 1px |

**原生 1672×941 上 12pt 字符的实际像素高度**：

- 12pt 在 96dpi 下约 16px 高 · gpt-image-2 内部渲染像素密度 ≈ 62 dpi（1672px / 27" 参考视口）· 折算后：
  - 中文：约 10-11 px 高 · **已经在临界线以下** · 先糊
  - 数字：约 10 px 高 · **次之** · 先出现 0/6/8/9 环状糊
  - 英文小写：约 8 px 高 · **最抗压** · 但也在临界
  - 英文大写：约 10 px 高 · 情况介于中文和小写之间

**推论 · 未来什么时候英文也会糊**：

1. 字号缩到 10pt · 且未走 §5.2 Lanczos 锐化 → 英文小写可读度 ≈ 6-7 px · 已经踩线
2. 高密度页触发 R-V7 逃生阀 · 字号被压到 8-9pt → 英文与中文一起糊
3. Prompt 内元素数暴涨至 50+ · 单元素可用像素被稀释 → 无论何种语言都糊

**根治路径优先级**（从上到下）：

1. **【第一顺位 · 治本】§4.6 分区出图（Section Split）** · 元素数 > 40 或分层 ≥ 6 时强制拆页 · 让单字符可用像素回到 ≥ 12×12 · 这是**唯一能凭空提高字符像素密度**的手段
2. **【第二顺位 · 治标】§5.2 C 方案 Lanczos 3× + UnsharpMask** · 只对"字符本身已有足够像素但边缘毛"的情况有效 · **对"字符像素本身不够"的情况无解**（内插不出模型没渲的笔画）
3. **【第三顺位 · 视觉指纹稳定】§4.3 ⑥.5 字体族硬锁** · 不能救糊 · 但能救"跨页混排看着糊" · 是**必要非充分**条件

**明确不做的事**：

- ❌ 不显式依赖任何"image_size='4k' 就 native 4K 出图"的说法 · 该参数在 gpt-image-2 上**大概率是 gsk 平台侧的隐式 upscale** · 不是模型原生 · 拿它当机制会导致后续 agent 放弃后处理
- ❌ 不写"prompt ≤ 7K tokens"或"head 2000 + tail 500 注意力 3-5×"这类**过度精确的数字**（false precision）· 定性正确（长 prompt 尾部服从度下降）· 但**具体数字来源不明** · 不写入 skill 契约
- ❌ 不把锐化当成万能解 · 见 §5.2 硬约束 3

**审计对话锚点**（用户 2026-09-08 17:00 明确要求把物理下限说明沉淀进 skill · 起因：另一 agent 用 v2.9_slim 目录名里的 "4k" + 8.6× 像素密度倍数论证"分辨率是清晰度第一因子" · 经对账推翻其"4K native"前提 · 保留其"数字/中文先糊 · 未来英文也可能糊"的物理观察 · 只写科学能站得住脚的部分）。

---

## 6 · Step 5：三层 QA + 归档 + 打包

### 6.1 三层 QA（对齐 Anthropic pptx skill）

| 层 | 工具 | 检查什么 | 通过标准 |
|---|---|---|---|
| **Content QA** | `scripts/audit_diff.py` | 源文字符 vs 视觉转写 diff | 字符差异率 < 5% |
| **File QA** | `scripts/validate_deck.py` | pptx 结构 / 16:9 / 页数 / 分辨率 | 全部 pass |
| **Visual QA** | agent 逐页看图 | 版面契约（标题/横线/留白/页脚） | 无漂移 |

### 6.2 归档规则

- QA 全过 → `promote_staging.py` 从 `_staging/` 升到 `images/`，同时写 `03_render_report/promotion_log.json`
- QA 不过 → 留在 `_staging/`，标红失败原因，返工重出（不允许覆盖）

### 6.3 打包 pptx

用 python-pptx，`slide_layouts[6]` 空白版，图片铺满 `12192000 × 6858000 EMU`（16:9）。
不重新排版、不加文字框——所有内容都在图里。

### 6.4 【v2.1 新增】强制字面转写审计（Literal-Transcription Audit）· 层 1 前置

**这是 v2.1 最重要的一条 QA 加强**。Energy_AI Kazakhstan v2.3 EN 事故的直接原因就是我（agent）在 v2.0 抽检时只问了"某某在不在"（结构级抽检 · v1.6 补丁 A-1 明确指出会被幻觉骗过），没做"逐字转写每层每子项"（字面级审计）。

**v2.1 强制规则**：

**触发条件**：**每页都跑**（不管 high_density 与否）。层 1（Content QA · audit_diff.py）之前必须先跑字面转写审计。

**动作**（agent 侧执行 · 不是脚本自动）：
1. 对每一层（业务输入横带 / 卡片矩阵 / 底座层 / 底部横带 等）**逐一**用 `gsk understand_images` 问模型：
   ```
   Literally transcribe every text block in the {LAYER-NAME} of this slide.
   Do NOT summarise. Do NOT paraphrase. Do NOT say "contains X". Only transcribe
   the exact characters visible. If a text block is missing, say "MISSING".
   ```
2. 把逐字转写结果与源 prompt 对应段落做**字符级 diff**
3. 任一层 miss_rate > 5% 或出现术语替换 → 判 FAIL · 该页留 `_staging/` · 触发 §4.4/§4.5/§4.6 补丁重跑
4. 全层通过 → 才允许进入层 1 audit_diff.py（自动脚本）

**禁止的假审计**（v1.2 R10.4 原文照搬）：
- ❌ "validated as correct"
- ❌ "布局符合预期"
- ❌ "标题清晰"
- ❌ 只问"某某在不在" · 模型看到任何 3×3 就答 yes
- ❌ 不引用具体源 prompt 条目编号
- ❌ 不给反例证据（缺什么 / 缺多少 / 在哪缺）

任一命中 = 字面转写审计 FAIL · 必须重做审计。

**产物**：`03_render_report/literal_transcription_audit.json`，逐层逐子项对账结果。

**详细协议**：见 `references/audit-protocol.md` §"层 0 · Literal Transcription Audit"（v2.1 追加）。

### 6.5 【v2.1 新增】审计模式禁忌明单（Anti-Assumption Register）

以下审计问法**永久禁止**（会被幻觉骗过）：

| ❌ 禁止的问法 | ✅ 正确问法 |
|---|---|
| "右竖条是否存在？" | "逐字转写右竖条的三段短词，如果缺任何一段说 MISSING" |
| "是不是 11 个节点？" | "从左到右逐个报出每个节点的编号和标题" |
| "9 家生态伙伴 logo 全吗？" | "从 3×3 网格逐格报出真实厂商名 · 报出实际显示的每个 logo 内文本" |
| "底部金句在吗？" | "转写底部金句横带的完整文字 · 若与 '{原文}' 不同则报 DIFF" |
| "8 项承诺齐吗？" | "从左到右从上到下报出每张承诺卡的完整标题、Engineering 行、Acceptor 行" |
| "整体版面 OK 吗？" | 按 §4.3 版面契约 5 条逐条判定 · 每条给 ✅/⚠️/❌ + 证据 |

**背景来源**：v1.2 SOP §"反模式 #v1.2-003 · 形式校验冒充内容校验" 已明文警示 · v2.0 未把此警示落到脚本或强制流程中 · v2.1 补齐。

---

## 7 · 强制规则总表（R1–R16）· 一等公民

| # | 规则 | 版本 | 状态 |
|---|---|---|---|
| R1 | 不得删减任何正文行 | v1.0 | ✅ 有效 |
| R2 | 不得压缩列表为摘要 | v1.0 | ✅ 有效 |
| R3 | 不得省略数字/术语/标签/卡片标题 | v1.0 | ✅ 有效 |
| R4 | 不得术语替换（授权+diff_report 例外） | v1.0 | ✅ 有效 |
| R5 | 不得截断（超模型上限 raise FAIL） | v1.0 | ✅ 有效 |
| R6 | 任何 transform 显式记录到 diff_report | v1.0 | ✅ 有效 |
| R7 | 信息密度下限（防"稀薄"页） | v1.1 | ✅ **v2.1 恢复为强规则**（v2.0 曾降级为参数 · 但对高密度页失效） |
| R8 | 蓝本锚定（B 路径的锚点契约） | v1.2 | ✅ 有效 |
| R9 | 硬约束首尾夹击（sandwich） | v1.2 | ✅ **v2.1 复活**（v2.0 曾降级 · 见 §4.5） |
| R10 | 逐项对账（Content QA 的前身） | v1.2 | ✅ 有效，脚本化为 audit_diff.py + v2.1 §6.4 强制前置 |
| R11 | 待确认隔离归档（staging） | v1.2 | ✅ 有效，脚本化为 promote_staging.py |
| R12 | 防代理改写（v1.3 加固） | v1.3 | ✅ 有效 |
| R13 | 质疑用户 + 深度思考 proposal | v1.4 | ✅ **最高层元原则** |
| R14 | 版面一致性契约（标题/横线/留白/页脚/展示层去思考化） | v1.4 + v2.0 强化 | ✅ **最高层元原则** |
| **R15** | **强制字面转写审计** | **v2.1 新增** | ✅ **每页必跑** · 见 §6.4 |
| **R16** | **分区出图兜底** | **v2.1 新增** | ✅ 触发条件严格 · 见 §4.6 |
| R-V1~R-V8 | v1.6 正向锁字/quote-lock/元素计数等 | v1.6 | ⚠️ **部分复活**：R-V4/R-V5/R-V7/R-V8 在高密度页局部复活（v2.1 §4.4）· R-V1/R-V2/R-V3/R-V6 永久作废（v1.7 判定） |

**R13 + R14 是元原则**——它们不管产物，管的是"AI 该不该动手 / 该不该按用户说的做"。任何 proposal 冲突时优先。

**R15 + R16 是 v2.1 新增的一等公民**——它们不是可选建议 · 是必须执行的强规则。跳过 R15 = 工程失败 · 触发 R16 条件但没走分区出图也 = 工程失败。

---

## 8 · 反模式速查（背熟）

1. ❌ 自定 `max_chars` 截断 → 违反 R5
2. ❌ 样式规范塞每页头部 → 违反 4 层隔离
3. ❌ 先"提取要点"再发模型 → 违反 R1
4. ❌ Silent 术语替换 → 违反 R4 + R6
5. ❌ 冒充"模型有 XX 字符上限" → 违反 R5
6. ❌ 跳过 diff_report → 违反 R6
7. ❌ 失败第 3 次还重试 → HL-2 停止规则
8. ❌ > 15K 字符硬塞图像模型 → 违反 R8 密度门
9. ❌ v1.6 R-V1/R-V2/R-V3/R-V6 那套（`<text>` 标签 · quote-lock · 全正向 · 空间锚）→ 已作废 · 见 deprecated.md
10. ❌ 手动决策路径 A vs B → 违反 v1.8 选路脚本卡口
11. ❌ 覆盖 `_staging/` 旧图 → 违反 R11
12. ❌ 标题居中或字号浮动 → 违反 R14.1（视觉指纹漂移）
13. **❌ 【v2.1 新增】用"某某在不在"式抽检代替字面转写审计** → 违反 R15（见 §6.5 禁忌明单）
14. **❌ 【v2.1 新增】高密度页跳过 HDG-Pack 或首尾夹击** → 违反 R7 + R9
15. **❌ 【v2.1 新增】4K + gpt-image-2 一次搞定就交付高密度页** → 未走 §5.1 双模型评估或 §4.6 分区出图兜底
16. **❌ 【v2.1 新增】结构级抽检 "9 家 logo 全吗？"** → 违反 §6.5 Anti-Assumption Register

完整反模式清单见 `references/anti-patterns.md`。

---

## 9 · Just-in-Time 加载指引（给 agent 看）

**永远先读本 SKILL.md 完整版**。以下场景才需要打开对应分册：

| 场景 | 打开哪份 |
|---|---|
| 建目录、决定放哪个文件 | `references/directory-layout.md` |
| 具体拼 prompt、公式校验、v1.4 展示层清洗 | `references/prompt-assembly.md` |
| 密度门临界、强结构页判定 | `references/density-router.md` |
| Content/File/Visual QA 具体判定标准 | `references/audit-protocol.md` |
| **高密度页护栏包（R-V4/R-V5/R-V7/R-V8 复活规格）** | **`references/high-density-guardrails.md`（v2.1 新增）** |
| 想改 SKILL.md 本身 | `references/regression-guard.md`（v1.7 沉淀，改前必读） |
| 有人质疑"R7 / R9 / R-V 是不是还生效" | `references/deprecated.md`（v2.1 有增补） |
| 想避免踩坑 | `references/anti-patterns.md` |
| **v2.2 脚本层加固细节**（select_path 高密度自动判定 / build_prompt C 路径 sandwich+R-V5 铁闸 / audit_diff 4 层 QA / ocr_extract R15d 关键字符串锁） | **`references/patch-v2.2.md`（v2.2 · 2026-09-05）** |

**加载纪律**（对齐 mgechev/skills-best-practices）：
- SKILL.md 本身 < 500 行 → v2.1 略超 · 但结构清晰 · 可容忍
- references/ 各分册按需 JiT 加载 → 满足
- 子目录只允许 1 层深 → 满足
- 每份分册有独立的 frontmatter + purpose → 施工规范

---

## 10 · 未来演进：谁能改这份 SOP？

**改动的层级**：
- **架构层**（4 层隔离、双链路、5 步主流程、R1–R6、R13、R14、R15、R16）→ 改动必须走 v1.7 回归保护三步：问卷 + A/B 样本 + 回滚开关（见 `references/regression-guard.md`）
- **参数层**（分辨率阈值、字号、留白像素、正向锁字词表、高密度触发阈值）→ 允许项目级 override，但必须写入 `06_changelog/` 项目目录
- **反模式层**（新增禁止项）→ 追加到 `references/anti-patterns.md`，不需要跑回归保护

**任何试图删除 R13/R14/R15/R16 的动作**：直接拒绝。这些是过去 8 版补丁 + Energy_AI v2.3 EN 事故最贵的教训 · 删除等于让翻车重演。

---

## 11 · 【v2.4 新增】Agent 协作契约层（Agent Compliance Contract · ACC）

> **触发事故**：2026-09-08 · 矿业大模型方案 Wave 6/7 全量渲染（v1.1→v1.2） · agent（Claude）**只读 SKILL.md 首页 · 未打开 references/ 与 scripts/ 全套** · 自造 v1.2_patcher.py 替代 build_prompt.py · 用 gsk understand_images 替代 audit_diff.py · **6 个 skill/scripts/ 全跳过** · 事后合规率仅 8/16。虽然功能等价（R15/R9/HDG-Pack 都做了），但字面契约被绕开——skill 从 v1.8 到 v2.2 沉淀的**脚本卡口**全部失效。用户判定"精神合规、字面违规 = 协作契约违约"。
>
> v2.4 §11 就是把这道口子从"agent 自觉"升级为"skill 强制流程" · 与 R13/R14/R15/R16 同为**元原则**。

### 11.1 · 定位

**这不是新的产物层规则** · 也不管 prompt / 出图 / 审计。**这管的是 agent 在整个 skill 生命周期里的 6 个卡口动作** · 保证 "skill 说的" == "agent 做的"。

任何试图跳过本节任一条 · 视为**协作契约违约** · 与"删了 diff_report"、"用 max_chars 截断"同级严重。

### 11.2 · 5 条硬机制

#### 机制 1 · Skill 加载必须"下钻到底"（Full-Load Rule）

**触发时机**：用户或系统指名一个 skill 时（"用 skill X"、"按你那个 skill 的做法"、"skill 里的规则"）。

**agent 第一批动作 MUST**：

```bash
# Step A · 列出 skill 全部资产
gsk aidrive ls --path "/skills/<name>/"
gsk aidrive ls --path "/skills/<name>/references/"
gsk aidrive ls --path "/skills/<name>/scripts/"
gsk aidrive ls --path "/skills/<name>/assets/"

# Step B · 下载全部 references/*.md + scripts/*.py + assets/*
#         到 sandbox 工作目录 · 一份不漏
gsk aidrive download "/skills/<name>/<each-file>" "./<local-path>"

# Step C · Read 全部下载文件 · 一份都不允许"按标题猜内容"
```

**禁止**：
- ❌ 只读 SKILL.md（首页）就下场
- ❌ 假设 scripts/ 里的脚本"我知道它做什么"（skill v1.8 → v2.2 的脚本包含反 v1.6 教训的历次补丁 · 不 Read 无法知道）
- ❌ 声称 references/ 是"辅助资料"（skill 契约明写"references 分册按需 JiT 加载" · JiT 不等于跳过 · 触发条件命中就必须打开）

**产出契约**：Step C 之后 · agent 必须在**回复用户的第一条消息**里输出**"我理解到的契约清单"** · 覆盖：

1. 6 步或 5 步主流程的**每一步**（Step 1 用什么脚本 / Step 2 建什么目录 / ...）
2. R1-R16 中在**本次任务**会触发的条目（哪几条 · 为什么）
3. 强制产物清单（path_decision.json / literal_transcription.json / promotion_log.json / diff_report.json 等）
4. 硬约束（"不允许手动选路"、"不允许覆盖 staging 旧图"、"sha256 首尾字字一致"...）

**用户回"确认"之后**才能进入 Step D 动手。用户不确认 = 加载不完成 = 不允许动手。

#### 机制 2 · 契约对账表 · 事前而不是事后（Pre-Execution Reconciliation）

**触发时机**：机制 1 加载完成后 · 动手之前。

**agent MUST 输出一张表**（Markdown 表 · 直接贴回复里）：

| skill 要求 | 我打算怎么做 | 是否用 skill 脚本 | 若不用 · 为什么 |
|---|---|---|---|
| Step 1 · 选路 | `python scripts/select_path.py --pages-dir ...` | ✅ | — |
| Step 3 · 拼装 | `python scripts/build_prompt.py --hd-max-card-reads 9 ...` | ✅ | — |
| Step 5 · 层 0 审计 | agent 侧 `gsk understand_images` 逐字段问 · 落 literal_transcription.json | ✅（这是 skill 明写的 agent 侧动作） | — |
| Step 5 · 层 1 OCR | `python scripts/ocr_extract.py --engine paddleocr` | ✅ | — |
| Step 5 · 层 1 diff | `python scripts/audit_diff.py --literal-json ... --ocr-json ...` | ✅ | — |
| Step 5 · promote | `python scripts/promote_staging.py` | ✅ | — |

**红色高亮规则**：任何"是否用 skill 脚本 = ❌"的行 · agent MUST 用 **⚠️ 红色警示 emoji** 标记 · 并在第 4 列写详细理由。用户看完批准 · 才能开始 · **用户不批准 = 提案作废 · 必须回改成 ✅**。

**禁止**：
- ❌ 表格出现在动手之后（那叫复盘 · 不叫对账）
- ❌ 表格缺任一列
- ❌ "自写脚本因为更贴合本项目"直接通过 · 必须获显式批准

#### 机制 3 · "自造轮子"触发强制暂停（Wheel-Reinvention Halt）

**触发时机**：agent 准备写的代码 · **功能重合于 skill/scripts/ 任何一个已存在脚本**。

**判定"功能重合"**：
- 干同一件事（选路 / 拼装 prompt / 审计 diff / 升级 staging / 校验 pptx / 抽 OCR）· 即使实现语言/框架不同
- 输入输出结构大体一致（读同一批文件 · 写等价的 JSON / prompt）
- 目标产物名与 skill 契约要求的产物名一致或近义

**触发后 agent MUST 立即暂停 · 输出**：

```
【机制 3 · 自造轮子暂停】

我打算写：<自写脚本名>.py · 干这件事：<描述>
skill 已有：scripts/<existing>.py · 干这件事：<描述>

差异 / 我认为需要自写的原因：
  A · <理由 1>
  B · <理由 2>

替代方案 · 我推荐的（默认）：直接用 scripts/<existing>.py · 因为 <护住哪些历次教训>

请授权：
  [1] 用 skill 脚本（推荐）
  [2] 授权我自写 · 承担脚本无历次教训回归保护的风险
  [3] 你手动 override · 请写下 override 理由
```

**用户回复前** · agent 不允许动手写任何代码。**无用户在场**时（自动化运行） · **默认 fallback 到 [1]** · 不允许自主选 [2]。

**记录**：无论用户选 [1]/[2]/[3] · agent MUST 把这次问答落到 `06_changelog/wheel_halt_{timestamp}.md` · 供事后复盘。

#### 机制 4 · 每步落 skill 契约要求的 log（Log-Completeness Gate）

**触发时机**：每完成一个 skill Step。

**产物齐全性作为交付前检查项** · 缺一个不能报"完成"。skill v2.4 定义的**必备产物清单**：

| Step | 必备产物 | 位置 | 校验方式 |
|---|---|---|---|
| Step 1 · 选路 | `path_decision.json` + `high_density_flags.json` | `03_render_report/` | 文件存在 + 每页一条决策记录 |
| Step 3 · 拼装 | `{page}.prompt.md`（每页一个）+ `diff_report.json`（初版） | `02_render_prompt/` + `03_render_report/` | 文件数 == 页数 · sandwich hash pass |
| Step 4 · 出图 | `{page}.png` in `_staging/`（每页一张 · 或 C 路径两半张） | `04_output/_staging/` | 分辨率检查（layer 2.5） |
| Step 5 · 层 0 | `literal_transcription.json` | `03_render_report/` | pages 覆盖率 == 页数 |
| Step 5 · 层 1 OCR | `ocr_extracts.json` | `03_render_report/` | pages 覆盖率 == 页数 · verbatim_hits 计算完成 |
| Step 5 · 层 1 diff | `audit_result.json` | `03_render_report/` | 4 层字段齐全 |
| Step 5 · promote | `promotion_log.json` | `03_render_report/` | promoted + stayed 计数 == 页数 |
| Step 5 · 汇总 | `diff_report.json`（最终版 · 按 `assets/diff_report.schema.json`） | `03_render_report/` | schema 校验通过 |

**diff_report.json 字段 MUST 匹配 `assets/diff_report.schema.json`**（v2.2 补 `literal_transcription` 字段 · v2.4 追加 `agent_compliance` 段 · 见 11.6）· agent 自造 schema = 违规。

**禁止**：
- ❌ "log 会补上" · "log 是次要产物" · "先给你看结果再补 log"
- ❌ log 里字段缺失 · 用 null 填充
- ❌ 用其他文件名代替（比如 `my_diff.json` 代替 `diff_report.json`）

#### 机制 5 · 交付前"skill 合规审计"作为最后一道闸（Compliance Gate at Delivery）

**触发时机**：交付前 · 强制。

**agent MUST 在交付信里显式输出下面这张表** · 每行三个字段之一：

```
【skill 合规审计 · v2.4】

Step 1  select_path.py         [跑了 / 没跑 · 原因]
Step 3  build_prompt.py        [跑了 / 没跑 · 原因]
Step 4  出图                   [做了 / 没做 · 原因]
Step 5  R15 层 0 字面转写审计   [做了 / 没做 · 原因]
Step 5  ocr_extract.py         [跑了 / 没跑 · 原因]
Step 5  audit_diff.py          [跑了 / 没跑 · 原因]
Step 5  promote_staging.py     [跑了 / 没跑 · 原因]
Step 6  validate_deck.py       [跑了 / 没跑 · 原因（未打包 pptx 时写 "N/A · 未到打包步"）]

产物齐全性（机制 4）：
  ☐ path_decision.json         ☐ high_density_flags.json
  ☐ literal_transcription.json ☐ ocr_extracts.json
  ☐ audit_result.json          ☐ promotion_log.json
  ☐ diff_report.json（按 schema） ☐ {page}.prompt.md × N
  ☐ {page}.png × N             ☐ {page}.png 在 images/ · 已 promote

契约对账表（机制 2）：附本次任务的对账表引用 · 或复贴一次
自造轮子记录（机制 3）：本次共 N 次触发 · 决策为 [1/2/3]
```

**任何"没跑"** MUST 附一句人话理由（不允许"暂缓"、"下次做"这种）。

**任何"做了"** MUST 附证据链接（本地路径 · 用 backtick 包裹）· 让用户一键 open 就能看到。

**用户选 A · 全跑**（本次矿业方案任务用户明示） → 上表**每一项都必须是 "跑了 / 做了"** · 任一 "没跑 / 没做" = **交付信 FAIL** · 不允许提交 · 补做完再交付。

### 11.3 · 与其他规则的关系

- **§11 与 R13-R16 并列** · 是**元原则** · 优先级高于 R1-R12 产物层规则
- **§11 冲突处理**：11.1 全加载 与 11.3 自造轮子不构成冲突（先全加载 · 才能判断轮子重合）；11.2 对账表 与 11.4 log 齐全是**互补**（对账表事前、log 事后）；11.5 合规审计闸是**最后一道兜底** · 前 4 条都跑了 · 它自然 PASS
- **§11 与 R6（任何 transform 记 diff_report）关系**：R6 管**产物层**的 transform 归档；§11 管**协作层**的动作归档 · 两者一起构成"skill 全链路可审计"

### 11.4 · 反模式（Anti-Patterns）

以下动作**永久禁止** · 命中即协作契约违约：

| ❌ 反模式 | 违反哪一条 | 事故案例 |
|---|---|---|
| 只读 SKILL.md 首页就下场 | 机制 1（全加载） | 2026-09-08 矿业 Wave 7 · 未打开 references/audit-protocol.md · 违反 R15 完整协议 |
| 自造 patcher / audit / prompt-builder 替代 skill 脚本 · 不问用户 | 机制 3（自造轮子） | 同上 · v1.2_patcher.py 替代 build_prompt.py · 6 个脚本全跳过 |
| 交付信里不提"哪些没跑" | 机制 5（合规审计闸） | 同上 · 用户追问才交底 · 最伤信任 |
| diff_report.json 用自造 schema | 机制 4（log 齐全） | 同上 · 未按 `assets/diff_report.schema.json` |
| "功能等价可以替代" | 机制 3 元原则 · **skill 契约要"跑那个脚本" · 不是"做等价的事"** | 同上 |
| 用"用户没明说要跑 X 脚本"做替代理由 | 元原则 · **skill 契约是默认合规基线 · 不需要用户逐条重申** | 同上 |

### 11.5 · Override 路径（用户明示允许时）

**唯一允许绕过 §11 任一机制的方式**：用户在**本次任务开始时**明示 override · 例如：
- "本轮先不跑 audit_diff · 我只要出图看效果"
- "skip 机制 1 · 你直接开始"

override MUST：
1. 用户主动提出 · 不允许 agent 引导
2. 落到 `06_changelog/user_override_{timestamp}.md` · 记录 override 范围 + 用户原话
3. 交付信"合规审计闸"表格里 · 对应行写 `override by user · <原话>` · 不允许写"跑了"或"没跑"

### 11.6 · diff_report.json v2.4 补丁 · agent_compliance 段

在既有 schema（`assets/diff_report.schema.json`）**顶层**追加：

```json
{
  ...,
  "agent_compliance": {
    "skill_version": "v2.4",
    "full_load_done": true,
    "reconciliation_table_url": "06_changelog/reconciliation_{timestamp}.md",
    "wheel_halts": [
      {"timestamp": "...", "proposed": "...", "existing": "scripts/...",
       "user_choice": 1, "reason": "..."}
    ],
    "logs_completeness": {
      "path_decision.json": true,
      "high_density_flags.json": true,
      "literal_transcription.json": true,
      "ocr_extracts.json": true,
      "audit_result.json": true,
      "promotion_log.json": true
    },
    "compliance_gate_verdict": "pass",
    "user_overrides": []
  }
}
```

`compliance_gate_verdict != "pass"` = 项目 FAIL · 不允许交付。

---

**End of SKILL.md · 2026-09-08 · v2.4.1**

> **v2.4.1 patch note（2026-09-08 17:05）**：SKILL.md §1-§4.2 / §4.4-§5.1 / §6-§11 一字未动。v2.4.1 只做两处**增量追加**：
> 1. **§4.3 追加 ⑥.5 字体族硬锁**：数字与英文字体族显式锁到 Inter（fallback IBM Plex Sans）· 补 v2.4 之前只锁中文字体族的洞
> 2. **§5.2 之后追加 §5.3 清晰度物理下限说明**：Nyquist 意义下每语种最小可读像素表 + 原生 1672×941 上 12pt 字符实测像素折算 + 根治路径三顺位（治本 = 分区出图 · 治标 = C 方案锐化 · 视觉指纹 = 字体族硬锁）
>
> 触发事故：2026-09-08 17:00 与另一 agent 复盘对账 · 那位 agent 用 v2.9_slim 目录名里的 "4k" 论证"image_size='4k' 是 native 4K 出图" · 经工程视角研判**推翻**该前提（gpt-image-2 原生最大 1672×941 · 见 §5.2 · 3840×2160 输出大概率是 gsk 平台或脚本侧隐式 upscale）· 但保留其**科学正确的部分**：字符可读像素下限、字体族不锁死跨页会漂、数字/中文先糊未来英文也会糊。**未采纳的说法**：prompt ≤ 7K 硬约束、head 2000 + tail 500 tokens 注意力 3-5× 这类过度精确的数字（false precision）· 咱们 R9 首尾夹击定性表述已够。
>
> frontmatter version 2.4 → 2.4.1。**无脚本层变更** · 无 references/ 变更 · 无 assets/ 变更。回滚路径：`_legacy/v2.4-original/`（本次上传前的完整 v2.4 快照，须先归档）。观察期 2 周 · 期间任何一次"字体族没锁死导致跨页视觉指纹漂移"事件 → 触发 v1.7 回归保护三步。

> **v2.4 patch note（2026-09-08）**：SKILL.md §1-§10 一字未动。v2.4 只在**末尾追加 §11 Agent 协作契约层（ACC · 5 条硬机制）**+ frontmatter version 2.2 → 2.4（跳过 2.3 · 因 patch-v2.3 已存在于 references/ 处理内容漂移护栏）。触发事故：2026-09-08 矿业大模型方案 Wave 6/7 agent 只读 SKILL.md 首页 · 6 个 skill/scripts/ 全跳过 · 合规率仅 8/16。回滚路径：`_legacy/v2.2-original/`（本次上传前的完整 v2.2 快照）。观察期 2 周 · 期间任何一次"agent 又绕开 skill 脚本"事件 → 触发 v1.7 回归保护三步。

> **v2.2 patch note（2026-09-05）**：SKILL.md 主体一字未动。v2.2 只加固 `scripts/`（select_path 加 `high_density` 自动判定 · build_prompt 加 C 路径六段拼装 + R9 sandwich hash assert + R-V5 铁闸 · audit_diff 升级为 4 层 QA · 新增 `scripts/ocr_extract.py`）+ `assets/diff_report.schema.json` 补 `literal_transcription` 字段。细节见 `references/patch-v2.2.md`。观察期 2 周后再决定是否 v3.0 全量重写。回滚路径：`_legacy/v2.1-original/`。
