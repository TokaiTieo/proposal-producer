# Style Overlay · 精简版（≈460 字符，给模型用）

> 拼装 render_prompt 时把本文件作为首段注入。全项目共用一份，禁止复制到每页。

---

Canvas: 1920×1080, 16:9, background #FCFAF6 (warm off-white; never pure white).
Palette: primary #145849, accent #2DBFA8, stroke #E9D8A6, gold #C8A24A, body #2E3A36, note #5A6E68, alert #D46A2C (warnings only).
Font: 微软雅黑 / Noto Sans SC throughout; digits & English use Inter.

Title block (every page, no exceptions):
- Line-1 main title: Chinese only, (x=80, y=60), 28pt Bold #145849, left-aligned. Never center, never resize.
- Line-2 subtitle: Chinese only, (x=80, y=95), 14pt Regular #5A6E68, one line ≤ 30 chars. No English words, no zh+EN pairing.
- Line-3 gold rule: 1px solid #C8A24A, from (80,115) to (280,115) — fixed 200px, identical on every page.
- Title area must not contain page codes, version numbers (v2.x), parenthetical process notes, or English taglines.

Naming lock (on-screen text): platform = "工业 AI 操作平台"; company = "零一万物" (zh) / "01.AI" (en); base-LLM trio = "DeepSeek · Kimi · 千问"; exactly 6 agents. Forbidden: 统一入口 / Energy AI 操作系统 / 01 万物 / GPT / OpenAI / agent count 9.

Footer: plain text "01.AI" only, 14pt #666666, at (x=80, y=1040). No logo, no page number, no hashtag/URL/QR.
Top-right and bottom-right corners stay completely empty (no ornaments, no seals, no QR).

Body safe zone: x∈[80,1840], y∈[150,940]. All body text strictly inside.
Bottom gold quote band (if any): y=980–1020, deep-green background, white bold 16–18pt.

Image/figure margins: ≥60px from canvas edge; ≥32px between figures horizontally, ≥24px vertically.

Style: glass-morphism translucent cards, 1px #E9D8A6 stroke, 4–8% teal shadow. Info-dense but restrained. No decorative flourishes.

Forbidden colors: blue/purple/pink/neon/cartoon/vaporwave; pure black #000000 is forbidden for text — use #2E3A36.
Forbidden on-screen text: `完整原文`, `页面定位`, `本页要让受众明白什么`, `本质是什么`, `Q&A高概率提问预告`, `硬约束清单`, `给模型用`, `段1-段5`, prompt meta-comments such as `(No GPT)` — none may appear on the slide.
