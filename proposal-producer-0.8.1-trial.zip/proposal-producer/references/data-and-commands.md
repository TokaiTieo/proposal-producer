# 数据与命令

选择任务所用 Python 环境，准备 `requirements.txt` 的组件。下文以 `PYTHON`、`HELPER`、`RUN` 表示解释器、`scripts/proposal.py` 和任务位置。

```sh
PYTHON HELPER validate --workdir RUN
PYTHON HELPER doctor --workdir RUN
PYTHON HELPER init --workdir RUN --producer ACTUAL_INSTANCE_ID --kind quote
PYTHON HELPER handoff --workdir RUN
PYTHON HELPER sow-build --workdir RUN --producer ACTUAL_INSTANCE_ID --destination NEW_SOW_CANDIDATE
PYTHON HELPER proposal-brief --workdir RUN
# Read the actual SOW and method file, apply the method and author the shared argument and chapter plan.
PYTHON HELPER proposal-record --workdir RUN --producer ACTUAL_INSTANCE_ID
PYTHON HELPER model-check --workdir RUN
PYTHON HELPER document-plan-check --workdir RUN
PYTHON HELPER calculate --workdir RUN
PYTHON HELPER production-check --workdir RUN
PYTHON HELPER packet --workdir RUN
PYTHON HELPER approve --workdir RUN --actor ACTUAL_APPROVER --evidence ACTUAL_REPLY_LOCATION
PYTHON HELPER build --workdir RUN --destination NEW_CANDIDATE
PYTHON HELPER export --workdir RUN --file NEW_CANDIDATE/render-manifest.json
PYTHON HELPER document-check --workdir RUN
PYTHON HELPER register --workdir RUN --role ROLE --file ACTUAL_FILE
PYTHON HELPER review --workdir RUN --reviewer ACTUAL_REVIEWER --report ACTUAL_REPORT --result RESULT
PYTHON HELPER quality-init --workdir RUN --reviewer ACTUAL_REVIEWER
PYTHON HELPER checks-init --workdir RUN
PYTHON HELPER projection-check --workdir RUN
PYTHON HELPER check --workdir RUN
PYTHON HELPER release --workdir RUN
PYTHON HELPER status --workdir RUN
```

初始化创建书面 Proposal 的默认交付组合、SOW 章节、阶段记录、共同底稿、story map、文档章节计划及任务风格配置。先制作实际 SOW，再根据方法交接完成 Proposal 写作。填写有效要求、决定范围、项目事实和正确文档元数据，生成当前交接。章节引用共同单元，投影记录客户文件的章节／页码位置。字段、枚举和命令由契约及 Schema 定义。

`production-check` 核对共同论证及适用制作计划，记录内部制作状态。`packet` 输出关键内容确认包；`approve` 登记真实确认及证据位置，沿用已有有效确认。普通排版不增加业务审批节点。

`build` 在新候选目录生成原生 Word，`export` 使用实际 Office 引擎导出 PDF、更新自动目录并记录分页和渲染。`document-check` 核对 A4、样式、目录、页码、元数据及源稿与 PDF 对应关系；仍需查看全部页面。每次候选使用新目录，失败版本保留。

`register` 登记实际文件，`review` 登记已完成的独立报告，`quality-init` 创建整体商业论证与各载体表达的评价记录。`checks-init` 创建适用 C/K/V/S 检查，由真实检查者填写位置、测量与证据。`check` 重新核对当前版本，`release` 满足条件后生成本地放行清单；增加 `--destination` 可复制所选文件，实际发送仍按已有授权执行。

修改共同论证、正式事实或实际客户文字后更新业务判断；修改素材或版式后更新对应文档表达与导出证据。`status` 显示失效范围。脚本检查可观察的结构、计算和证据，实际身份与商业判断由真实执行和复核负责。

## 独立 SOW

先使用 `sow-build` 制作上游 SOW；`init --sow-required` 只选择将它一并交付客户。对应 PDF 由用户选择后登记。SOW 使用独立稳定章节，具体方法见 [交付物派生](artifacts.md)。交付形态检查会核对选配标志及原始要求。

## 可选汇报版

用户明确要求时使用 `init --presentation-requested`，也可在书面 Proposal 完成后登记用户选择并更新交付角色。该分支创建 `presentation-plan.json` 与 `calibration.json`，并加载 [汇报版表达](presentation-design.md) 和 [视觉制作](visual-production.md)。先运行 `presentation-brief` 并读取实际 Proposal，编排页计划后运行 `presentation-record --producer ACTUAL_INSTANCE_ID`。读取 [包内 ppt-image-render](ppt-image-render.md)，运行 `presentation-image-prepare --destination NEW_IMAGE_JOB --actor ACTUAL_ACTOR --evidence EXISTING_CHOICE_LOCATION`；可用 `--file BLUEPRINTS_JSON` 提供逐页蓝本路径和哈希。使用包内原脚本实际审计并晋级图片，登记图片及对象区域后更新 presentation-record。适配器支持关键页试制；完成内部校准及 production-check 后运行 `presentation-build --destination NEW_DECK_CANDIDATE`，再 export。该载体使用 `policy.json#/optional_presentation` 的专用阈值。

## 迁移与评测

旧任务用 `migrate --destination NEW_WORKDIR --producer ACTUAL_INSTANCE_ID` 显式迁移到原目录之外的新副本。保留旧数据、授权证据及原始评价，按差异补齐当前模型。有效授权继续沿用，原始评价不改写成当前版本通过。

`eval-freeze --file SOURCES --destination NEW_FREEZE` 固定完整有效指令、资料、规则和 Skill 快照；复制冻结任务到独立工作位置后制作。`eval-result` 保存原始产物和独立原判，`eval-compare` 核对比较口径。字段见对应 Schema，方法见 [评测](evaluation.md)。真实客户旧新稿配对仍留空，合成回归与独立本地试用分别记录。

`project.data_files` 只登记明确参与制作的 JSON 与本地 Schema，运行日志不作为底稿。需要阅读视图时用 `render --file RUN/content-base.json`；修改返回权威 JSON。

客户可见性、必要披露、图表引用及正文两层检查见 [客户内容边界](client-content.md)。
