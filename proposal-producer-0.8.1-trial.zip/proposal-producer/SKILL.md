---
name: proposal-producer
description: 先制作 SOW，再按内置商业论证与提案方法写成说明项目价值及决策请求的 A4 Proposal DOCX 和 PDF；用户选择后从 Proposal 制作 PPT。用于商机合作、方案报价和产品立项提案或模板归纳。
---

# Proposal Producer

按 SOW → 书面 Proposal → 用户所选 PPT 制作，默认客户交付为可编辑 Proposal DOCX 与对应 PDF。

先读 [制作方法](references/workflow.md)、[阶段交接](references/production-chain.md)、[客户内容边界](references/client-content.md) 和 [数据与命令](references/data-and-commands.md)。整理当前有效要求及项目事实，先生成实际 SOW。类型、字段、阈值和检查项从 JSON 契约及 Schema 读取。

读取实际 SOW 和本 Skill 内置的 [商业论证与提案方法](references/methods/business-case-and-proposal.source.md)。该方法已集成在本包中，直接结合原始 brief、客户背景及证据，写入 [共同论证](references/proposal-model.md) 和章节计划，再按 [书面制作](references/document-production.md) 生成文档、实际导出并查看全部页面。沿用有效授权和原有内容确认，普通写作排版连续完成。

按需要加载独立分支：

- **SOW**：始终先制作；是否一并交付客户由 `sow_required` 选择。工作约定及交付关系见 [交付物派生](references/artifacts.md)。
- **可选汇报版**：用户明确选择后，读取实际 Proposal，生成汇报版交接，按 [汇报版表达](references/presentation-design.md) 提炼页面，并使用包内 [ppt-image-render](references/ppt-image-render.md) 制作整页图像 PPT。完整原文、脚本、参考与样式资源随包安装，无需另装该 skill。页面计划与内部校准只服务该选配载体。
- **模板维护**：读 [模板维护](references/template-maintenance.md)，盘点并确认新增或调整规则。
- **独立试用／版本比较**：读 [评测](references/evaluation.md)，固定完整有效输入与规则，先保存原始产物及独立原判，再比较。
- **宿主门禁／治理**：分别读 [执行集成](references/enforcement.md)、[可选治理](references/optional-governance.md)。

编写正文前，按客户内容边界将来源状态转换为依据、商务条件或验证安排，制作记录留在内部；逐单元登记内容类别。客户正文展开商业主张和决定所需条件。生成器只读取客户投影，来源、题注和页眉页脚各自承担明确用途。

独立检查者对实际交付文件分别完成六项编辑检查，逐一处置扫描疑点和上下文发现。已判定的内部制作内容及过度防御必须修改；必要商务内容的误报按原文、位置及具体必要性纠正。复核绑定当前文件与图中文字证据，确认违规残留和待判定疑点均为零，再沿用 `check`、`release` 与既有授权交付。独立 SOW 不替代 Proposal，程序扫描通过不替代实际商业与表达判断。
